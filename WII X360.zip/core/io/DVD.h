#pragma once
#include <cstdint>

namespace DVD {
    bool Init(const char* path);
    int HandleCommand(void* buffer);
    bool Read(uint64_t offset, uint32_t size, void* out);
}