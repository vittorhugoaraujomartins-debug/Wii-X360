#include "DVD.h"
#include <cstdio>

static FILE* dvdFile = nullptr;

namespace DVD {

bool Init(const char* path) {
    dvdFile = fopen(path, "rb");
    return dvdFile != nullptr;
}

bool Read(uint64_t offset, uint32_t size, void* out) {
    if (!dvdFile) return false;

    fseek(dvdFile, (long)offset, SEEK_SET);
    fread(out, 1, size, dvdFile);
    return true;
}

int HandleCommand(void* buffer) {
    // comando fake: sempre sucesso
    return 0;
}

}