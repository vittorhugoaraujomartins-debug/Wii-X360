#pragma once
#include <cstdint>
#include <vector>

namespace WiiX360 {

    enum class MemoryRegion {
        ROM,
        MODELS,
        TEXTURES,
        GAME_DATA,
        JIT_CACHE,
        HEAP
    };

    struct MemoryBlock {
        uint8_t* base;
        uint32_t size;
    };

    class MemoryManager {
    public:
        static bool Initialize();
        static void Shutdown();

        static MemoryBlock GetRegion(MemoryRegion region);

        static uint8_t* AllocateFromHeap(uint32_t size);
        static void ResetHeap();

    private:
        static bool AllocateRegions();

        static uint8_t* g_memoryBase;
        static uint32_t g_memorySize;

        static MemoryBlock g_rom;
        static MemoryBlock g_models;
        static MemoryBlock g_textures;
        static MemoryBlock g_gameData;
        static MemoryBlock g_jitCache;
        static MemoryBlock g_heap;

        static uint32_t g_heapOffset;
    };

}