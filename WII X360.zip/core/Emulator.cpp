
#include "Emulator.h"
#include <cstdio>

bool Emulator::Init() {
    running = true;
    printf("Wii Emulator (Xbox 360 native CPU/GPU) init\n");
    return true;
}

void Emulator::Step() {
    // HLE approach:
    // Wii logic mapped directly to Xbox 360 Xenon CPU
}

void Emulator::Shutdown() {
    running = false;
    printf("Shutdown\n");
}

bool Emulator::Running() const {
    return running;
}
