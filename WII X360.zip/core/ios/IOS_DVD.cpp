#include "IOS_DVD.h"
#include <cstring>

enum {
    DVD_READ = 0x71,
    DVD_SEEK = 0x72
};

IOS_DVD::IOS_DVD() {}

int IOS_DVD::Ioctl(uint32_t cmd, void* in, uint32_t, void* out, uint32_t outSize) {
    switch (cmd) {
    case DVD_READ:
        // Simula leitura de disco
        memset(out, 0, outSize);
        return 0;

    case DVD_SEEK:
        return 0;
    }
    return -1;
}