#pragma once
#include <cstdint>

struct IPCCommand {
    uint32_t cmd;
    uint32_t arg0;
    uint32_t arg1;
    uint32_t arg2;
};