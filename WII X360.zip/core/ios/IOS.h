#pragma once
#include <cstdint>

namespace IOS {
    void Init();
    int HandleIPC(uint32_t command, void* buffer);
}

#pragma once
#include <cstdint>
#include <string>

namespace IOS {

enum IOSCommand {
    IOS_OPEN  = 0x01,
    IOS_CLOSE = 0x02,
    IOS_READ  = 0x03,
    IOS_WRITE = 0x04,
    IOS_IOCTL = 0x06
};

void Init();
int  Open(const std::string& device);
int  Close(int fd);
int  Ioctl(int fd, uint32_t cmd, void* in, uint32_t inSize, void* out, uint32_t outSize);
void Update();

}