#include "IOS.h"
#include "../io/DVD.h"

namespace IOS {

void Init() {
    // IOS fake inicializado
}

int HandleIPC(uint32_t command, void* buffer) {
    switch (command) {

    case 0x01: // DVD command
        return DVD::HandleCommand(buffer);

    default:
        // comando desconhecido, mas não travar
        return 0;
    }
}

}


#include "IOS.h"
#include "IOS_Device.h"
#include <map>

namespace IOS {

static int nextFD = 1;
static std::map<int, IOSDevice*> devices;

void Init() {
    IOSDevice::RegisterDevices();
}

int Open(const std::string& device) {
    IOSDevice* dev = IOSDevice::OpenDevice(device);
    if (!dev) return -1;

    int fd = nextFD++;
    devices[fd] = dev;
    return fd;
}

int Close(int fd) {
    if (!devices.count(fd)) return -1;
    delete devices[fd];
    devices.erase(fd);
    return 0;
}

int Ioctl(int fd, uint32_t cmd, void* in, uint32_t inSize, void* out, uint32_t outSize) {
    if (!devices.count(fd)) return -1;
    return devices[fd]->Ioctl(cmd, in, inSize, out, outSize);
}

void Update() {
    // IOS roda em background no Wii
}

}