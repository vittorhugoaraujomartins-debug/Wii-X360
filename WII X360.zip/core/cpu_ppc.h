#pragma once
void PPC_CPU_Init();
void PPC_CPU_Run();
