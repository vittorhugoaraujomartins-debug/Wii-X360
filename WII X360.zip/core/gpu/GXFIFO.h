#pragma once
#include <cstdint>
#include <vector>

namespace GXFIFO {

    enum GXCommand : uint8_t {
        GX_CMD_NOP        = 0x00,
        GX_CMD_LOAD_CP    = 0x08,
        GX_CMD_LOAD_XF    = 0x10,
        GX_CMD_DRAW      = 0x80,
    };

    struct FIFOState {
        std::vector<uint8_t> buffer;
        uint32_t read_ptr;
        uint32_t write_ptr;
    };

    void Init(uint32_t size);
    void Reset();

    void Write8(uint8_t value);
    void Write32(uint32_t value);

    void Execute();

}

#pragma once
#include <cstdint>
#include <vector>

class GXFIFO {
public:
    void WriteU32(uint32_t v);
    void WriteFloat(float v);
    void Execute();

private:
    std::vector<uint32_t> buffer;
};