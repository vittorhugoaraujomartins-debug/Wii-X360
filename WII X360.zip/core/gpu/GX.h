
#pragma once
#include <cstdint>

namespace GX
{
    enum PrimitiveType
    {
        GX_POINTS = 0,
        GX_LINES,
        GX_TRIANGLES,
        GX_TRIANGLE_STRIP
    };

    struct GXState
    {
        bool depthTest;
        bool alphaTest;
        bool cullFace;
        bool textureEnabled;

        uint32_t vertexStride;
        uint32_t indexStride;
    };

    void Init();
    void Shutdown();

    void SetState(const GXState& state);

    void LoadVertexBuffer(const void* data, uint32_t size);
    void LoadIndexBuffer(const void* data, uint32_t size);

    void Draw(PrimitiveType prim, uint32_t count);
}

#pragma once

void GX_Init();
void GX_Draw();

#pragma once
#include <cstdint>

namespace GX {

    void Init();
    void WriteCommand8(uint8_t v);
    void WriteCommand32(uint32_t v);
    void Flush();

}

#pragma once
#include <cstdint>
#include "GX_FIFO.h"

namespace GX {

void Init();
void SetViewport(float x, float y, float w, float h);
void Begin(uint8_t prim);
void Position3f(float x, float y, float z);
void Color4f(float r, float g, float b, float a);
void End();

}