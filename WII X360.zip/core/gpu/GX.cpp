
#include "GX.h"
#include "XenosGPU.h"
#include <cstring>

namespace GX
{
    static GXState g_state;
    static const void* g_vertexData = nullptr;
    static uint32_t g_vertexSize = 0;
    static const void* g_indexData = nullptr;
    static uint32_t g_indexSize = 0;

    void Init()
    {
        memset(&g_state, 0, sizeof(GXState));
        XenosGPU::Init();
    }

    void Shutdown()
    {
        XenosGPU::Shutdown();
    }

    void SetState(const GXState& state)
    {
        g_state = state;
        XenosGPU::ApplyGXState(state);
    }

    void LoadVertexBuffer(const void* data, uint32_t size)
    {
        g_vertexData = data;
        g_vertexSize = size;
        XenosGPU::UploadVertexBuffer(data, size);
    }

    void LoadIndexBuffer(const void* data, uint32_t size)
    {
        g_indexData = data;
        g_indexSize = size;
        XenosGPU::UploadIndexBuffer(data, size);
    }

    void Draw(PrimitiveType prim, uint32_t count)
    {
        XenosGPU::DrawPrimitive(prim, count);
    }
}

#include "GX.h"
#include "XenosGPU.h"

void GX_Init()
{
    XenosGPU_Init();
}

void GX_Draw()
{
    XenosGPU_Render();
}

void GX::PushCommand(u32 cmd);
void GX::ProcessFIFO();


#include "GX.h"
#include "GXFIFO.h"

namespace GX {

    void Init() {
        GXFIFO::Init(1024 * 1024); // 1MB FIFO
    }

    void WriteCommand8(uint8_t v) {
        GXFIFO::Write8(v);
    }

    void WriteCommand32(uint32_t v) {
        GXFIFO::Write32(v);
    }

    void Flush() {
        GXFIFO::Execute();
    }

}

#include "GX.h"

static GXFIFO fifo;

namespace GX {

void Init() {}

void SetViewport(float x, float y, float w, float h) {
    fifo.WriteU32(0x10000000);
    fifo.WriteFloat(x);
    fifo.WriteFloat(y);
    fifo.WriteFloat(w);
    fifo.WriteFloat(h);
}

void Begin(uint8_t prim) {
    fifo.WriteU32(0x20000000 | prim);
}

void Position3f(float x, float y, float z) {
    fifo.WriteFloat(x);
    fifo.WriteFloat(y);
    fifo.WriteFloat(z);
}

void Color4f(float r, float g, float b, float a) {
    fifo.WriteFloat(r);
    fifo.WriteFloat(g);
    fifo.WriteFloat(b);
    fifo.WriteFloat(a);
}

void End() {
    fifo.Execute();
}

}