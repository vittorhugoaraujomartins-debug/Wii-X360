
#include "XenonCPU.h"

namespace WiiCPU {

void XenonCPU::Initialize() {
    cpu.Reset();
}

void XenonCPU::RunFrame() {
    // Aproximadamente ciclos de CPU do Wii por frame
    // Wii ~ 729 MHz → ~12 milhões por frame (60 FPS)
    cpu.Run(12000000);
}

void XenonCPU::Shutdown() {
    // Nada por enquanto
}

}