
#include "PowerPC.h"

namespace WiiCPU {

void PowerPC::Reset() {
    pc = 0x80000000;
    for (int i = 0; i < 32; i++) {
        gpr[i] = 0;
        fpr[i] = 0.0;
    }
}

uint32_t PowerPC::GetPC() const {
    return pc;
}

void PowerPC::SetPC(uint32_t value) {
    pc = value;
}

void PowerPC::Run(uint32_t cycles) {
    for (uint32_t i = 0; i < cycles; i++) {
        Step();
    }
}

void PowerPC::Step() {
    // Placeholder de fetch real (virá do memory manager)
    uint32_t opcode = 0x60000000; // NOP PPC
    ExecuteInstruction(opcode);
    pc += 4;
}

void PowerPC::ExecuteInstruction(uint32_t opcode) {
    // Implementação mínima real de PPC
    // Opcode 0x60000000 = NOP
    if (opcode == 0x60000000) {
        return;
    }

    // Base para futuras instruções:
    uint32_t primary = opcode >> 26;

    switch (primary) {
        default:
            // instrução não implementada
            break;
    }
}

}