
#pragma once
#include <cstdint>

namespace WiiCPU {

class PowerPC {
public:
    void Reset();
    void Step();
    void Run(uint32_t cycles);

    uint32_t GetPC() const;
    void SetPC(uint32_t pc);

private:
    uint32_t pc;
    uint32_t gpr[32];   // General Purpose Registers
    double   fpr[32];   // Floating Point Registers

    void ExecuteInstruction(uint32_t opcode);
};

}