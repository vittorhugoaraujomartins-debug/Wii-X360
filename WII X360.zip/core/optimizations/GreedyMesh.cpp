#include "Optimizations.hpp"

// Stub funcional (não quebra pipeline)
void GreedyMesh_Build()
{
    // Aqui futuramente você pode unir vértices iguais
    // Agora só garante compatibilidade
}