#include "Occlusion.h"

bool Occlusion::IsVisible(const BoundingBox& box, const Frustum& frustum) {
    for (int i = 0; i < 6; i++) {
        if (frustum.planes[i].Distance(box.center) < -box.radius)
            return false;
    }
    return true;
}