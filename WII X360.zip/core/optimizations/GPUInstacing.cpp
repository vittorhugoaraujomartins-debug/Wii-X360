#include "Optimizations.hpp"

static int g_InstanceCount = 0;

void GPUInstancing_Submit()
{
    if (g_InstanceCount > MAX_INSTANCES)
        g_InstanceCount = MAX_INSTANCES;

    // Aqui futuramente entra instancing real do Xenos
}

#include "Instancing.h"

void Instancing::Submit(const Mesh& mesh, const std::vector<Matrix>& transforms) {
    if (transforms.empty()) return;

    XenosGPU::DrawInstanced(
        mesh.vertexBuffer,
        mesh.indexBuffer,
        transforms.data(),
        transforms.size()
    );
}