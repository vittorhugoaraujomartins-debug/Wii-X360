
#include "cpu_ppc.h"
void PPC_CPU_Init(){}
void PPC_CPU_Run(){}
