
#include "core/Emulator.h"

int main() {
    Emulator emu;
    if (!emu.Init())
        return -1;

    while (emu.IsRunning()) {
        emu.Step();
    }

    emu.Shutdown();
    return 0;

{
  

#include "memory/MemoryManager.h"

using namespace WiiX360;

int main() {
    if (!MemoryManager::Initialize())
        return -1;

    // LoadWiiRom("game.iso");

    // Emulador roda aqui

    MemoryManager::Shutdown();
    return 0;
}



#include "memory/ram_manager.h"

using namespace WiiX360;

void InitEmulator() {
    
    RamManager::Init();
}