#include "Optimizations.hpp"

// Occlusion extremamente simples (rápido no Xenon)
bool Occlusion_Test(const BoundingBox& box)
{
    // Se estiver fora da tela básica (fake frustum)
    if (box.maxZ < 0.1f)
        return false;

    return true;
}