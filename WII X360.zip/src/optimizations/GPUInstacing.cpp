#include "Optimizations.hpp"

static int g_InstanceCount = 0;

void GPUInstancing_Submit()
{
    if (g_InstanceCount > MAX_INSTANCES)
        g_InstanceCount = MAX_INSTANCES;

    // Aqui futuramente entra instancing real do Xenos
}