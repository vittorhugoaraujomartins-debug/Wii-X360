#include "Optimizations.hpp"

void LOD_Update(LODObject* obj, float cameraDistance)
{
    if (cameraDistance < 15.0f)
        obj->lodLevel = 0; // full
    else if (cameraDistance < 40.0f)
        obj->lodLevel = 1; // medium
    else
        obj->lodLevel = 2; // low
}