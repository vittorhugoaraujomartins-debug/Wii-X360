#pragma once
#include <stdint.h>

namespace WiiX360 {

struct RamBlock {
    uint8_t* base;
    uint32_t size;
};

class RamManager {
public:
    static bool Init();
    static RamBlock GetCpuRam();
    static RamBlock GetCpuCache();
    static RamBlock GetGpuRam();
    static RamBlock GetGpuCache();
    static RamBlock GetSyncBuffer();
    static void Shutdown();

private:
    static uint8_t* ramBase;
};

}