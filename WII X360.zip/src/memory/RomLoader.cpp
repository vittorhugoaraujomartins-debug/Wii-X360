#include "MemoryManager.h"
#include <cstdio>
#include <cstring>

using namespace WiiX360;

bool LoadWiiRom(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f)
        return false;

    MemoryBlock rom = MemoryManager::GetRegion(MemoryRegion::ROM);

    fseek(f, 0, SEEK_END);
    uint32_t size = ftell(f);
    rewind(f);

    if (size > rom.size) {
        fclose(f);
        return false;
    }

    fread(rom.base, 1, size, f);
    fclose(f);

    return true;
}