#include "MemoryManager.h"
#include <cstdlib>
#include <cstring>

using namespace WiiX360;

uint8_t* MemoryManager::g_memoryBase = nullptr;
uint32_t MemoryManager::g_memorySize = 0;

MemoryBlock MemoryManager::g_rom{};
MemoryBlock MemoryManager::g_models{};
MemoryBlock MemoryManager::g_textures{};
MemoryBlock MemoryManager::g_gameData{};
MemoryBlock MemoryManager::g_jitCache{};
MemoryBlock MemoryManager::g_heap{};

uint32_t MemoryManager::g_heapOffset = 0;

static constexpr uint32_t MB = 1024 * 1024;

bool MemoryManager::Initialize() {
    g_memorySize = 2 * 1024 * MB; // 2GB virtual
    g_memoryBase = (uint8_t*)malloc(g_memorySize);

    if (!g_memoryBase)
        return false;

    memset(g_memoryBase, 0, g_memorySize);
    return AllocateRegions();
}

void MemoryManager::Shutdown() {
    if (g_memoryBase) {
        free(g_memoryBase);
        g_memoryBase = nullptr;
    }
}

bool MemoryManager::AllocateRegions() {
    uint32_t offset = 0;

    g_rom = { g_memoryBase + offset, 2048 * MB };
    offset += g_rom.size;

    g_models = { g_memoryBase + offset, 512 * MB };
    offset += g_models.size;

    g_textures = { g_memoryBase + offset, 384 * MB };
    offset += g_textures.size;

    g_gameData = { g_memoryBase + offset, 256 * MB };
    offset += g_gameData.size;

    g_jitCache = { g_memoryBase + offset, 256 * MB };
    offset += g_jitCache.size;

    g_heap = { g_memoryBase + offset, g_memorySize - offset };
    g_heapOffset = 0;

    return true;
}

MemoryBlock MemoryManager::GetRegion(MemoryRegion region) {
    switch (region) {
    case MemoryRegion::ROM: return g_rom;
    case MemoryRegion::MODELS: return g_models;
    case MemoryRegion::TEXTURES: return g_textures;
    case MemoryRegion::GAME_DATA: return g_gameData;
    case MemoryRegion::JIT_CACHE: return g_jitCache;
    case MemoryRegion::HEAP: return g_heap;
    default: return {};
    }
}

uint8_t* MemoryManager::AllocateFromHeap(uint32_t size) {
    if (g_heapOffset + size > g_heap.size)
        return nullptr;

    uint8_t* ptr = g_heap.base + g_heapOffset;
    g_heapOffset += size;
    return ptr;
}

void MemoryManager::ResetHeap() {
    g_heapOffset = 0;
}


#include <string.h>
#include <stdint.h>

#define CPU_RAM_SIZE (256 * 1024 * 1024)
#define GPU_RAM_SIZE (128 * 1024 * 1024)

static uint8_t* g_CPU_RAM;
static uint8_t* g_GPU_RAM;

void RAM_Init()
{
    g_CPU_RAM = (uint8_t*)malloc(CPU_RAM_SIZE);
    g_GPU_RAM = (uint8_t*)malloc(GPU_RAM_SIZE);

    memset(g_CPU_RAM, 0, CPU_RAM_SIZE);
    memset(g_GPU_RAM, 0, GPU_RAM_SIZE);
}