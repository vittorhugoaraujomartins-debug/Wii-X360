#include "IPC.h"
#include "IOS.h"

int SendIPC(IPCCommand* ipc) {
    return IOS::HandleIPC(ipc->cmd, ipc);
}