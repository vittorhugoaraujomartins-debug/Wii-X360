#include "IOS.h"
#include "../io/DVD.h"

namespace IOS {

void Init() {
    // IOS fake inicializado
}

int HandleIPC(uint32_t command, void* buffer) {
    switch (command) {

    case 0x01: // DVD command
        return DVD::HandleCommand(buffer);

    default:
        // comando desconhecido, mas não travar
        return 0;
    }
}

}