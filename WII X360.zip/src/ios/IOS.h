#pragma once
#include <cstdint>

namespace IOS {
    void Init();
    int HandleIPC(uint32_t command, void* buffer);
}