
#include "XenosGPU.h"
#include <xtl.h>
#include <xgraphics.h>

static IDirect3DDevice9* g_device = nullptr;
static IDirect3DVertexBuffer9* g_vb = nullptr;
static IDirect3DIndexBuffer9* g_ib = nullptr;

namespace XenosGPU
{
    void Init()
    {
        g_device = Direct3D_GetDevice();
    }

    void Shutdown()
    {
        if (g_vb) { g_vb->Release(); g_vb = nullptr; }
        if (g_ib) { g_ib->Release(); g_ib = nullptr; }
    }

    void ApplyGXState(const GX::GXState& state)
    {
        if (!g_device) return;

        g_device->SetRenderState(D3DRS_ZENABLE, state.depthTest);
        g_device->SetRenderState(D3DRS_ALPHATESTENABLE, state.alphaTest);
        g_device->SetRenderState(D3DRS_CULLMODE,
            state.cullFace ? D3DCULL_CCW : D3DCULL_NONE);
    }

    void UploadVertexBuffer(const void* data, uint32_t size)
    {
        if (!g_device) return;

        if (g_vb) g_vb->Release();

        g_device->CreateVertexBuffer(
            size,
            0,
            0,
            D3DPOOL_DEFAULT,
            &g_vb,
            nullptr
        );

        void* dst;
        g_vb->Lock(0, size, &dst, 0);
        memcpy(dst, data, size);
        g_vb->Unlock();

        g_device->SetStreamSource(0, g_vb, 0, sizeof(float) * 8);
    }

    void UploadIndexBuffer(const void* data, uint32_t size)
    {
        if (!g_device) return;

        if (g_ib) g_ib->Release();

        g_device->CreateIndexBuffer(
            size,
            0,
            D3DFMT_INDEX16,
            D3DPOOL_DEFAULT,
            &g_ib,
            nullptr
        );

        void* dst;
        g_ib->Lock(0, size, &dst, 0);
        memcpy(dst, data, size);
        g_ib->Unlock();

        g_device->SetIndices(g_ib);
    }

    void DrawPrimitive(GX::PrimitiveType prim, uint32_t count)
    {
        if (!g_device) return;

        D3DPRIMITIVETYPE type = D3DPT_TRIANGLELIST;

        switch (prim)
        {
        case GX::GX_POINTS: type = D3DPT_POINTLIST; break;
        case GX::GX_LINES: type = D3DPT_LINELIST; break;
        case GX::GX_TRIANGLES: type = D3DPT_TRIANGLELIST; break;
        case GX::GX_TRIANGLE_STRIP: type = D3DPT_TRIANGLESTRIP; break;
        }

        g_device->DrawIndexedPrimitive(
            type,
            0,
            0,
            count,
            0,
            count / 3
        );
    }
}


#include "XenosGPU.h"

// Render básico, sem efeitos pesados
void XenosGPU_Init()
{
    // Inicialização fake segura
}

void XenosGPU_Render()
{
    // Aqui entra o pipeline real futuramente
}


#include "XenosGPU.h"

namespace XenosGPU {

    void SetCommandProcessor(uint32_t, uint32_t) {
        // Stub realista (CP cacheável depois)
    }

    void SetTransformUnit(uint32_t, uint32_t) {
        // Stub realista (XF cacheável)
    }

    void DrawPrimitive(uint32_t prim, uint32_t count) {
        // Aqui futuramente:
        // - Vertex fetch
        // - Index buffer
        // - Instancing
        // - Culling
        (void)prim;
        (void)count;
    }

}