#include "GXFIFO.h"
#include "XenosGPU.h"
#include <cstring>

namespace GXFIFO {

    static FIFOState fifo;

    void Init(uint32_t size) {
        fifo.buffer.resize(size);
        fifo.read_ptr = 0;
        fifo.write_ptr = 0;
    }

    void Reset() {
        fifo.read_ptr = 0;
        fifo.write_ptr = 0;
    }

    void Write8(uint8_t value) {
        fifo.buffer[fifo.write_ptr++] = value;
    }

    void Write32(uint32_t value) {
        std::memcpy(&fifo.buffer[fifo.write_ptr], &value, 4);
        fifo.write_ptr += 4;
    }

    static uint8_t Read8() {
        return fifo.buffer[fifo.read_ptr++];
    }

    static uint32_t Read32() {
        uint32_t v;
        std::memcpy(&v, &fifo.buffer[fifo.read_ptr], 4);
        fifo.read_ptr += 4;
        return v;
    }

    void Execute() {
        while (fifo.read_ptr < fifo.write_ptr) {

            uint8_t cmd = Read8();

            switch (cmd) {

                case GX_CMD_NOP:
                    break;

                case GX_CMD_LOAD_CP: {
                    uint32_t reg = Read32();
                    uint32_t val = Read32();
                    XenosGPU::SetCommandProcessor(reg, val);
                    break;
                }

                case GX_CMD_LOAD_XF: {
                    uint32_t reg = Read32();
                    uint32_t val = Read32();
                    XenosGPU::SetTransformUnit(reg, val);
                    break;
                }

                case GX_CMD_DRAW: {
                    uint32_t prim = Read32();
                    uint32_t count = Read32();
                    XenosGPU::DrawPrimitive(prim, count);
                    break;
                }

                default:
                    // Comando desconhecido → ignora
                    break;
            }
        }

        Reset();
    }

}