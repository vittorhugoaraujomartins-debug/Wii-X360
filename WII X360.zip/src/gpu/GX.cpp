
#include "GX.h"
#include "XenosGPU.h"
#include <cstring>

namespace GX
{
    static GXState g_state;
    static const void* g_vertexData = nullptr;
    static uint32_t g_vertexSize = 0;
    static const void* g_indexData = nullptr;
    static uint32_t g_indexSize = 0;

    void Init()
    {
        memset(&g_state, 0, sizeof(GXState));
        XenosGPU::Init();
    }

    void Shutdown()
    {
        XenosGPU::Shutdown();
    }

    void SetState(const GXState& state)
    {
        g_state = state;
        XenosGPU::ApplyGXState(state);
    }

    void LoadVertexBuffer(const void* data, uint32_t size)
    {
        g_vertexData = data;
        g_vertexSize = size;
        XenosGPU::UploadVertexBuffer(data, size);
    }

    void LoadIndexBuffer(const void* data, uint32_t size)
    {
        g_indexData = data;
        g_indexSize = size;
        XenosGPU::UploadIndexBuffer(data, size);
    }

    void Draw(PrimitiveType prim, uint32_t count)
    {
        XenosGPU::DrawPrimitive(prim, count);
    }
}

#include "GX.h"
#include "XenosGPU.h"

void GX_Init()
{
    XenosGPU_Init();
}

void GX_Draw()
{
    XenosGPU_Render();
}

void GX::PushCommand(u32 cmd);
void GX::ProcessFIFO();


#include "GX.h"
#include "GXFIFO.h"

namespace GX {

    void Init() {
        GXFIFO::Init(1024 * 1024); // 1MB FIFO
    }

    void WriteCommand8(uint8_t v) {
        GXFIFO::Write8(v);
    }

    void WriteCommand32(uint32_t v) {
        GXFIFO::Write32(v);
    }

    void Flush() {
        GXFIFO::Execute();
    }

}