
#pragma once
#include <cstdint>
#include "GX.h"

namespace XenosGPU
{
    void Init();
    void Shutdown();

    void ApplyGXState(const GX::GXState& state);

    void UploadVertexBuffer(const void* data, uint32_t size);
    void UploadIndexBuffer(const void* data, uint32_t size);

    void DrawPrimitive(GX::PrimitiveType prim, uint32_t count);
}


#pragma once

void XenosGPU_Init();
void XenosGPU_Render();

#pragma once
#include <cstdint>

namespace XenosGPU {

    void SetCommandProcessor(uint32_t reg, uint32_t value);
    void SetTransformUnit(uint32_t reg, uint32_t value);
    void DrawPrimitive(uint32_t prim, uint32_t count);

}