#pragma once
#include <cstdint>
#include <unordered_map>
#include <vector>

typedef void (*JitFunc)();

struct PPCBlock {
    uint32_t start_pc;
    uint32_t end_pc;
    JitFunc  func;
};

class PPCJIT {
public:
    PPCJIT();
    ~PPCJIT();

    JitFunc GetOrCompile(uint32_t pc);
    void Invalidate(uint32_t pc);
    void Reset();

private:
    PPCBlock CompileBlock(uint32_t pc);
    void EmitInstruction(uint32_t opcode);

    std::unordered_map<uint32_t, PPCBlock> block_cache;
};