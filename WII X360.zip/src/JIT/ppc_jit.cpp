#include "ppc_jit.h"
#include <cstring>

// Simulação simples de buffer de código JIT
static uint8_t jit_buffer[1024 * 1024];
static size_t  jit_offset = 0;

PPCJIT::PPCJIT() {
    jit_offset = 0;
}

PPCJIT::~PPCJIT() {
    Reset();
}

void PPCJIT::Reset() {
    block_cache.clear();
    jit_offset = 0;
}

void PPCJIT::Invalidate(uint32_t pc) {
    block_cache.erase(pc);
}

JitFunc PPCJIT::GetOrCompile(uint32_t pc) {
    auto it = block_cache.find(pc);
    if (it != block_cache.end()) {
        return it->second.func;
    }

    PPCBlock block = CompileBlock(pc);
    block_cache[pc] = block;
    return block.func;
}

PPCBlock PPCJIT::CompileBlock(uint32_t pc) {
    PPCBlock block{};
    block.start_pc = pc;

    uint8_t* code_start = &jit_buffer[jit_offset];

    uint32_t current_pc = pc;
    int instr_count = 0;

    // Limite seguro de bloco
    while (instr_count < 32) {
        uint32_t opcode = *(uint32_t*)current_pc;
        EmitInstruction(opcode);

        current_pc += 4;
        instr_count++;

        // Branch simples → encerra bloco
        if ((opcode & 0x48000000) == 0x48000000)
            break;
    }

    // Retorno PPC
    *(uint32_t*)(&jit_buffer[jit_offset]) = 0x4E800020; // blr
    jit_offset += 4;

    block.end_pc = current_pc;
    block.func = (JitFunc)code_start;
    return block;
}

void PPCJIT::EmitInstruction(uint32_t opcode) {
    // FAST PATH: instruções comuns são copiadas direto
    // Isso funciona porque Wii e X360 são PPC

    *(uint32_t*)(&jit_buffer[jit_offset]) = opcode;
    jit_offset += 4;
}