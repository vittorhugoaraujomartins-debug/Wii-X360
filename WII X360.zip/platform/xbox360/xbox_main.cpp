
#include "../../core/cpu_ppc.h"
#include "../../video/gx_wrapper.h"
#include <xtl.h>
int main(){
    PPC_CPU_Init();
    GX_Init();
    for(;;){
        PPC_CPU_Run();
        GX_Submit();
        XSleep(1);
    }
    return 0;
}
