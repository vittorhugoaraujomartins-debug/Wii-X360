
#include "gx_wrapper.h"
void GX_Init(){}
void GX_Submit(){}
