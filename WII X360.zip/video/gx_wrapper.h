#pragma once
void GX_Init();
void GX_Submit();
