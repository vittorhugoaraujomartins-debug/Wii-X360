#include <xtl.h>
#include <xgraphics.h>
#include <thread>
#include <chrono>

#include "MemoryManager.h"
#include "ram_manager.h"
#include "XenonCPU.h"
#include "ppc_jit.h"
#include "IOS.h"
#include "GX.h"
#include "GXFIFO.h"
#include "XenosGPU.h"
#include "optimizations/OptimizationManager.h"

WiiCPU::XenonCPU cpu;
PPCJIT jit;
bool g_running = true;

void CPUThread() {
    while (g_running) {
        cpu.RunFrame();
        std::this_thread::sleep_for(std::chrono::milliseconds(0));
    }
}

void GPUThread() {
    while (g_running) {
        if (GXFIFO::HasCommands()) {
            OptimizationManager::BeginFrame();
            GXFIFO::Execute();
            GX_Draw();
            OptimizationManager::EndFrame();
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
}

void IOSThread() {
    while (g_running) {
        IOS::Update();
        std::this_thread::sleep_for(std::chrono::milliseconds(4));
    }
}

bool InitEmulator() {
    if (!WiiX360::MemoryManager::Initialize()) return false;
    if (!WiiX360::RamManager::Init()) return false;

    cpu.Initialize();
    jit.Reset();
    IOS::Init();
    GX::Init();
    XenosGPU::Init();
    OptimizationManager::Init();
    OptimizationManager::PreRenderLoad();
    return true;
}

void ShutdownEmulator() {
    g_running = false;
    OptimizationManager::Shutdown();
    GX::Shutdown();
    IOS::Shutdown();
    XenosGPU::Shutdown();
    WiiX360::RamManager::Shutdown();
    WiiX360::MemoryManager::Shutdown();
}

void main() {
    if (!InitEmulator()) return;

    std::thread cpuThread(CPUThread);
    std::thread gpuThread(GPUThread);
    std::thread iosThread(IOSThread);

    while (true) {
        XVideoWaitForVBlank();
        XINPUT_STATE state;
        if (XInputGetState(0, &state) == ERROR_SUCCESS) {
            if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_BACK) &&
                (state.Gamepad.wButtons & XINPUT_GAMEPAD_START)) break;
        }
    }

    ShutdownEmulator();
    cpuThread.join();
    gpuThread.join();
    iosThread.join();
}
