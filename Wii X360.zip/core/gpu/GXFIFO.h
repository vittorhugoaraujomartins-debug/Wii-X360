#pragma once
#include <cstdint>
#include <vector>
#include "XenosGPU.h"

namespace GXFIFO {

enum GXCommand : uint32_t {
    GX_CMD_NOP      = 0x00,
    GX_CMD_LOAD_CP  = 0x08,
    GX_CMD_LOAD_XF  = 0x10,
    GX_CMD_DRAW     = 0x80
};

class FIFO {
public:
    void Init(uint32_t sizeBytes = 1024 * 1024);
    void Reset();

    void WriteU32(uint32_t v);
    void WriteFloat(float v);

    void Execute();

private:
    std::vector<uint32_t> buffer;
    uint32_t read_ptr = 0;

    bool HasData(uint32_t count) const;
    uint32_t Read32();
};

extern FIFO g_fifo;

} // namespace GXFIFO

