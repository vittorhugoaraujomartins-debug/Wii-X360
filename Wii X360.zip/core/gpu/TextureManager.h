#pragma once
#include <xgraphics.h>
#include <cstdint>

namespace TextureManager {

// Inicializa sistema de texturas
bool Init(IDirect3DDevice9* device);

// Libera tudo
void Shutdown();

// Cria textura RGBA simples
IDirect3DTexture9* CreateTexture2D(
    uint32_t width,
    uint32_t height,
    const void* rgbaData
);

// Ativa textura no slot 0
void Bind(IDirect3DTexture9* tex);

// Desativa textura
void Unbind();

}