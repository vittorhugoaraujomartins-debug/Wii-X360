#pragma once
#include <cstdint>
#include <vector>
#include "XenosGPU.h"

namespace GX {

void Init();
void Shutdown();

void SetState(const GXState& state);

void Begin(PrimitiveType prim);
void Position3f(float x, float y, float z);
void Color4f(float r, float g, float b, float a);
void End();

void Flush();

// Draw direto (atalho)
void Draw(PrimitiveType prim, uint32_t count);
void DrawIndexed(PrimitiveType prim, uint32_t count, uint32_t indexCount);

// Textura
void LoadTexture(const void* data, uint32_t w, uint32_t h);

}


#include <queue>

namespace GX {
    extern std::queue<GXCommand> CommandQueue;

    inline void Submit(const GXCommand& cmd) {
        CommandQueue.push(cmd);
    }
}