#pragma once
#include <xgraphics.h>

namespace PixelShader {

// Inicializa pixel shader básico
bool Init(IDirect3DDevice9* device);

// Ativa pixel shader
void Bind();

// Desativa pixel shader
void Unbind();

// Libera recursos
void Shutdown();

}
