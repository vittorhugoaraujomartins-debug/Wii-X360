#include "cpu_interrupts.h"
#include "cpu_state.h"
static PPCInterrupt pending=INT_NONE;
void CPUInterrupts::Raise(PPCInterrupt t){pending=t;}
void CPUInterrupts::Handle(){
 if(pending==INT_NONE)return;
 gCPU.LR=gCPU.PC;
 switch(pending){
  case INT_EXTERNAL:gCPU.PC=0x500;break;
  case INT_SYSTEM_CALL:gCPU.PC=0xC00;break;
  case INT_PROGRAM:gCPU.PC=0x700;break;
  case INT_FP_EXCEPTION:gCPU.PC=0x800;break;
  case INT_TIMER:gCPU.PC=0x900;break;
  default:break;
 }
 pending=INT_NONE;
}
