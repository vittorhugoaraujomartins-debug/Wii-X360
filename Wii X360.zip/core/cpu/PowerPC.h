#pragma once
#include <cstdint>

namespace WiiCPU {

using JitFunc = void(*)();

class PowerPC {
public:
    void Reset();
    void Step();

    uint32_t GetPC() const { return pc; }
    void SetPC(uint32_t v) { pc = v; }

    // Debug / helpers
    bool IsNOP(uint32_t opcode) const;
    bool IsBranch(uint32_t opcode) const;

private:
    uint32_t pc = 0;
    uint32_t gpr[32]{};
    double   fpr[32]{};

    void ExecuteInstruction(uint32_t opcode);
};

void RaiseException(uint32_t vector);

}
