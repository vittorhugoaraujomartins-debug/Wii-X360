#pragma once
enum PPCInterrupt{INT_NONE,INT_EXTERNAL,INT_SYSTEM_CALL,INT_PROGRAM,INT_FP_EXCEPTION,INT_TIMER};
namespace CPUInterrupts{void Raise(PPCInterrupt t);void Handle();}
