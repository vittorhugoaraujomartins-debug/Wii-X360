#pragma once

namespace Scheduler {
    inline void Step() {
        // Stub – futuramente threads reais
    }
}