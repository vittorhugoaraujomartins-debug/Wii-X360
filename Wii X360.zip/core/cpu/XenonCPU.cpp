#include "XenonCPU.h"

namespace WiiCPU {

void XenonCPU::Initialize() {
    cpu.Reset();
}

void XenonCPU::RunFrame() {

    // Wii ~ 729 MHz
    // Aproximação segura: ~12 milhões de instruções/frame (60 FPS)
    const uint32_t instructionsPerFrame = 12000000;

    for (uint32_t i = 0; i < instructionsPerFrame; i++) {
        cpu.Step();
    }
}

void XenonCPU::Shutdown() {
    // Futuro: flush JIT, salvar estado
}

}