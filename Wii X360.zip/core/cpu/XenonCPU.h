#pragma once
#include "PowerPC.h"

namespace WiiCPU {

class XenonCPU {
public:
    void Initialize();
    void RunFrame();
    void Shutdown();

private:
    PowerPC cpu;
};

}