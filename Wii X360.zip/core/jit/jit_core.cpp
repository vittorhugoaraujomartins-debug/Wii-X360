#include "jit_core.h"
#include "../CPU/cpu_state.h"
#include "../CPU/cpu_interrupts.h"
struct JITBlock{uint32_t pc;void(*fn)();};
static JITBlock cache[4096];static int count=0;
void JIT::Init(){count=0;}
void JIT::ExecuteBlock(uint32_t pc){
 for(int i=0;i<count;i++) if(cache[i].pc==pc){cache[i].fn();CPUInterrupts::Handle();return;}
 gCPU.PC+=4;
 if(count<4096){cache[count].pc=pc;cache[count].fn=[](){gCPU.PC+=4;};count++;}
 CPUInterrupts::Handle();
}
