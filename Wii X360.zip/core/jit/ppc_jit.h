#pragma once
#include <cstdint>
#include <unordered_map>

typedef void (*JitFunc)();

struct PPCBlock {
    uint32_t start_pc;
    uint32_t end_pc;
    JitFunc  func;
};

class PPCJIT {
public:
    PPCJIT();
    ~PPCJIT();

    JitFunc GetOrCompile(uint32_t pc);

    // Invalidação
    void Invalidate(uint32_t pc);
    void InvalidateRange(uint32_t start, uint32_t size);

    void Flush();

private:
    PPCBlock CompileBlock(uint32_t pc);
    void EmitInstruction(uint32_t opcode);

    std::unordered_map<uint32_t, PPCBlock> block_cache;

    uint8_t* jit_buffer;
    size_t   jit_offset;
    size_t   jit_size;
};