#include "ppc_jit.h"
#include "MMU.h"
#include <cstring>

#define JIT_BUFFER_SIZE (1024 * 1024)

PPCJIT::PPCJIT() {
    jit_buffer = new uint8_t[JIT_BUFFER_SIZE];
    jit_size   = JIT_BUFFER_SIZE;
    jit_offset = 0;
}

PPCJIT::~PPCJIT() {
    delete[] jit_buffer;
}

void PPCJIT::Flush() {
    block_cache.clear();
    jit_offset = 0;
}

void PPCJIT::Invalidate(uint32_t pc) {
    block_cache.erase(pc);
}

void PPCJIT::InvalidateRange(uint32_t start, uint32_t size) {
    uint32_t end = start + size;

    for (auto it = block_cache.begin(); it != block_cache.end();) {
        uint32_t pc = it->second.start_pc;
        if (pc >= start && pc < end)
            it = block_cache.erase(it);
        else
            ++it;
    }
}

JitFunc PPCJIT::GetOrCompile(uint32_t pc) {
    auto it = block_cache.find(pc);
    if (it != block_cache.end())
        return it->second.func;

    PPCBlock block = CompileBlock(pc);
    block_cache[pc] = block;
    return block.func;
}

PPCBlock PPCJIT::CompileBlock(uint32_t pc) {
    PPCBlock block{};
    block.start_pc = pc;

    uint8_t* code_start = &jit_buffer[jit_offset];
    uint32_t cur_pc = pc;

    int instrs = 0;
    while (instrs < 32) {
        uint32_t opcode = MMU::Read32(cur_pc);
        EmitInstruction(opcode);

        cur_pc += 4;
        instrs++;

        // Branch PPC
        if ((opcode & 0xFC000000) == 0x48000000)
            break;
    }

    // blr (return)
    uint32_t blr = 0x4E800020;
    memcpy(&jit_buffer[jit_offset], &blr, 4);
    jit_offset += 4;

    block.end_pc = cur_pc;
    block.func = (JitFunc)code_start;
    return block;
}

void PPCJIT::EmitInstruction(uint32_t opcode) {
    memcpy(&jit_buffer[jit_offset], &opcode, 4);
    jit_offset += 4;
}


bool JIT::IsBlockCompiled(uint32_t pc) {
    return false; // por enquanto
}

void JIT::ExecuteBlock(uint32_t) {
    // Stub
}