#pragma once
#include <cstdint>

namespace GXVertex {

struct Vertex {
    float x, y, z;
    float nx, ny, nz;
    float u, v;
    uint32_t color;
};

void Init();
void Shutdown();
void ApplyLayout();

}