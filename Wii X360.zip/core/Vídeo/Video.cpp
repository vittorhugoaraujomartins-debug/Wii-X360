void Video::Draw() {
    // HLE: draw call genérico
    // Futuro: mapear buffers reais
}

void Video::Clear() {
    // Limpa framebuffer
}

void Video::Present() {
    // Apresenta o framebuffer
}

