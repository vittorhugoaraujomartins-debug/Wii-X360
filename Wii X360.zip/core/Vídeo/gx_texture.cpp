#include "gx_texture.h"
#include <xgraphics.h>
#include <vector>
#include <cstring>

namespace {

struct CachedTexture {
    uint32_t addr;
    uint32_t width;
    uint32_t height;
    uint32_t format;
    IDirect3DTexture9* tex;
};

static IDirect3DTexture9* g_slots[8] = {};
static std::vector<CachedTexture> g_cache;

IDirect3DTexture9* FindCached(uint32_t addr) {
    for (auto& c : g_cache)
        if (c.addr == addr)
            return c.tex;
    return nullptr;
}

}

namespace GXTexture {

void Init() {
    memset(g_slots, 0, sizeof(g_slots));
    g_cache.clear();
}

void Shutdown() {
    for (auto& c : g_cache)
        if (c.tex) c.tex->Release();
    g_cache.clear();
}

void BindTexture(uint32_t slot, const Texture& tex) {
    if (slot >= 8) return;

    IDirect3DDevice9* dev = Direct3D_GetDevice();
    if (!dev) return;

    // 🔹 tenta cache
    IDirect3DTexture9* d3dTex = FindCached(tex.addr);

    if (!d3dTex) {
        // cria nova
        dev->CreateTexture(
            tex.width,
            tex.height,
            1,
            0,
            D3DFMT_A8R8G8B8,
            D3DPOOL_DEFAULT,
            &d3dTex,
            nullptr
        );

        // upload
        D3DLOCKED_RECT r;
        d3dTex->LockRect(0, &r, nullptr, 0);

        uint8_t* dst = (uint8_t*)r.pBits;
        uint8_t* src = (uint8_t*)tex.data;

        for (uint32_t y = 0; y < tex.height; y++) {
            memcpy(dst, src, tex.width * 4);
            dst += r.Pitch;
            src += tex.width * 4;
        }

        d3dTex->UnlockRect(0);

        g_cache.push_back({
            tex.addr,
            tex.width,
            tex.height,
            tex.format,
            d3dTex
        });
    }

    g_slots[slot] = d3dTex;
    dev->SetTexture(slot, d3dTex);
}

void InvalidateTexture(uint32_t addr) {
    for (auto it = g_cache.begin(); it != g_cache.end();) {
        if (it->addr == addr) {
            it->tex->Release();
            it = g_cache.erase(it);
        } else {
            ++it;
        }
    }
}

}
