#pragma once
#include <cstdint>

namespace GXXF {

// índices GX simulados
enum XFMatrixSlot {
    XF_WORLD = 0,
    XF_VIEW  = 1,
    XF_PROJ  = 2
};

void LoadMatrix(uint32_t index, const float* mtx);
void Apply();

}