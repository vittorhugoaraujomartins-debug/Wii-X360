#include <xgraphics.h>

void GX_ApplyTEV() {
    IDirect3DDevice9* dev = Direct3D_GetDevice();
    if (!dev) return;

    dev->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);
    dev->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    dev->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);

    dev->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);
}