#pragma once
#include <cstdint>

struct IDirect3DTexture9;

namespace GXTexture {

struct Texture {
    uint32_t width;
    uint32_t height;
    uint32_t format;
    uint32_t addr;   // endereço na RAM do Wii
    void*    data;
};

void Init();
void Shutdown();
void BindTexture(uint32_t slot, const Texture& tex);
void InvalidateTexture(uint32_t addr);

}
