#pragma once
#include <vector>
#include <cstdint>

struct GXVertex {
    float x, y, z;
};

void OptimizeGreedyMesh(std::vector<GXVertex>& vertices);
