#pragma once
#include "IOS_Device.h"

class IOS_FS : public IOSDevice {
public:
    int Ioctl(int request, void* buffer) override {
        // Responde sucesso genérico
        return 0;
    }
};


namespace IOSFS {
    void Init();
    int Open(const char* path);
    int Read(int fd, void* buffer, int size);
    int Close(int fd);
}


#include <cstdint>

namespace IOSFS {
    void Init();
    int Open(const char* path, int mode);
    int Read(int fd, void* buffer, uint32_t size);
    int Close(int fd);
    int Stat(const char* path, void* out);
}