#pragma once
#include "IOS_Device.h"

class IOS_Null : public IOSDevice {
public:
    int Ioctl(int, void*) override {
        return 0;
    }
};