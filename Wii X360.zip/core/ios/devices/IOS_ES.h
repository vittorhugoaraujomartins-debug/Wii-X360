#pragma once
#include "IOS_Device.h"

class IOS_ES : public IOSDevice {
public:
    int Ioctl(int request, void* buffer) override {
        // Wii espera sucesso na maioria dos calls
        return 0;
    }
};