
#include "IOS_ES.h"
#include <cstring>

enum {
    ES_LAUNCH_TITLE     = 0x08,
    ES_GET_TITLE_ID     = 0x1D,
    ES_GET_TICKET_VIEWS = 0x20,
    ES_GET_NUM_TITLES   = 0x18,
};

int IOS_ES::Ioctl(int request, void* buffer) {

    switch (request) {

        case ES_GET_NUM_TITLES:
            if (buffer)
                *(uint32_t*)buffer = 1;
            return 0;

        case ES_GET_TICKET_VIEWS:
            // Retorna "sem erro"
            return 0;

        case ES_GET_TITLE_ID:
            if (buffer)
                *(uint64_t*)buffer = 0x0001000148414141ULL;
            return 0;

        case ES_LAUNCH_TITLE:
            // Aceita sempre
            return 0;

        default:
            return 0;
    }
}