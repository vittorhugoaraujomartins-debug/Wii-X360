#include "ES.h"
#include <unordered_set>
#include <cstring>

namespace ES {

static std::unordered_set<int> handles;
static int next_fd = 200; // <<< NÃO colide com FS

void Init() {}
void Shutdown() {
    handles.clear();
}

bool Handles(const char* dev) {
    return strcmp(dev, "/dev/es") == 0;
}

int Open(const char*) {
    int fd = next_fd++;
    handles.insert(fd);
    return fd;
}

int Close(int fd) {
    handles.erase(fd);
    return 0;
}

bool Owns(int fd) {
    return handles.count(fd) != 0;
}

int Ioctl(int,
          uint32_t cmd,
          void*, uint32_t,
          void*, uint32_t) {

    // Stub permissivo:
    // ES_GetTicketViews
    // ES_LaunchTitle
    // ES_GetTitleID
    // etc

    return 0;
}

}