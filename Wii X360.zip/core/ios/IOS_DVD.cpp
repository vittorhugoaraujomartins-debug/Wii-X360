#include "IOS_DVD.h"
#include "../MemoryManager.h"
#include <cstring>

// IOS DVD ioctl commands (Wii)
enum {
    DVD_READ     = 0x71,
    DVD_SEEK     = 0x72,
    DVD_GET_SIZE = 0x73
};

IOS_DVD::IOS_DVD()
    : currentOffset(0) {
}

int IOS_DVD::Ioctl(uint32_t cmd,
                   void* in, uint32_t inSize,
                   void* out, uint32_t outSize) {

    auto rom = MemoryManager::GetRegion(MemoryRegion::ROM);

    switch (cmd) {

    // =========================
    // SEEK
    // =========================
    case DVD_SEEK: {
        if (!in || inSize < sizeof(uint32_t))
            return -1;

        uint32_t offset = *(uint32_t*)in;
        if (offset < rom.size)
            currentOffset = offset;
        else
            currentOffset = rom.size;

        return 0;
    }

    // =========================
    // READ
    // =========================
    case DVD_READ: {
        if (!out || outSize == 0)
            return -1;

        uint32_t size = outSize;
        if (currentOffset + size > rom.size)
            size = rom.size - currentOffset;

        memcpy(out, rom.base + currentOffset, size);
        currentOffset += size;

        return size; // IOS retorna bytes lidos
    }

    // =========================
    // GET DISC SIZE
    // =========================
    case DVD_GET_SIZE: {
        if (!out || outSize < sizeof(uint32_t))
            return -1;

        *(uint32_t*)out = rom.size;
        return 0;
    }

    default:
        return -1;
    }
}