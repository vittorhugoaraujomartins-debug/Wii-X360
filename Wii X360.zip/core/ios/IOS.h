#pragma once
#include <cstdint>
namespace IOS{ void Init(); uint32_t Open(uint32_t,uint32_t);
uint32_t Ioctl(uint32_t,uint32_t,void*,uint32_t,void*,uint32_t); }
