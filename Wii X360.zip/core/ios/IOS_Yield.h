#pragma once

namespace IOSYield {
    inline void Yield() {
        // Stub — futuramente scheduler
    }
}