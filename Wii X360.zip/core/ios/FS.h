
#pragma once
#include <cstdint>

namespace FS {

    void Init();
    void Shutdown();

    // /dev/fs
    bool Handles(const char* dev);

    // Interface IOS
    int  Open(const char* path);
    int  Close(int fd);

    bool Owns(int fd);

    int  Ioctl(int fd,
               uint32_t cmd,
               void* in, uint32_t inSize,
               void* out, uint32_t outSize);

    int  Read(int fd, void* buffer, uint32_t size);
    int  Seek(int fd, uint32_t pos);

}