#include "IOS.h"
#include "FS.h"
#include "ES.h"
#include "IOS_IPC.h"
#include "IOS_FS.h"
#include "../io/DVD.h"

namespace IOS {

void Init() {
    FS::Init();
    ES::Init();
    IOSIPC::Init();
    IOSFS::Init();
}

void Shutdown() {
    FS::Shutdown();
    ES::Shutdown();
}

void Update() {
    IOSIPC::Update();
}

// Entrada principal de IPC (CPU escreve no mailbox)
int HandleIPC(uint32_t command, void* buffer) {
    switch (command) {

        case IOS_OPEN:
            return Open(reinterpret_cast<const char*>(buffer));

        case IOS_IOCTL:
            // buffer esperado já estruturado pelo IPC
            return 0;

        default:
            // não quebra jogos
            return 0;
    }
}

// ============================
// Device / FS routing
// ============================

int Open(const char* device) {

    if (FS::Handles(device))
        return FS::Open(device);

    if (ES::Handles(device))
        return ES::Open(device);

    if (DVD::Handles(device))
        return DVD::Open(device);

    return -1;
}

int Close(int fd) {
    if (FS::Owns(fd)) FS::Close(fd);
    if (ES::Owns(fd)) ES::Close(fd);
    return 0;
}

int Ioctl(int fd, uint32_t cmd,
          void* in, uint32_t inSize,
          void* out, uint32_t outSize) {

    if (FS::Owns(fd))
        return FS::Ioctl(fd, cmd, in, inSize, out, outSize);

    if (ES::Owns(fd))
        return ES::Ioctl(fd, cmd, in, inSize, out, outSize);

    return 0;
}

int Read(int fd, void* buffer, uint32_t size) {
    if (FS::Owns(fd))
        return FS::Read(fd, buffer, size);

    return 0;
}

int Write(int, const void*, uint32_t size) {
    // maioria dos jogos ignora retorno real
    return size;
}

}

#include "IOS_FS.h"
#include "IPC.h"

void IOS::Init() {
    IOSDevice::RegisterDevices();
    IOSFS::Init();
    IOSIPC::Init();
}