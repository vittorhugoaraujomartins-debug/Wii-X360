#include "FS.h"
#include <unordered_map>
#include <vector>
#include <fstream>
#include <cstring>

namespace FS {

struct File {
    std::vector<uint8_t> data;
    uint32_t pos = 0;
};

static std::unordered_map<int, File> files;
static int next_fd = 100;

void Init() {}

void Shutdown() {
    files.clear();
}

bool Handles(const char* dev) {
    return strncmp(dev, "/dev/fs", 7) == 0;
}

int Open(const char* path) {
    // path vem como "/dev/fs/boot.dol" ou similar
    const char* realPath = strstr(path, "/dev/fs/");
    if (!realPath)
        return -1;

    realPath += 8; // pula "/dev/fs/"

    std::ifstream f(realPath, std::ios::binary);
    if (!f.is_open())
        return -1;

    File file{};
    f.seekg(0, std::ios::end);
    size_t size = (size_t)f.tellg();
    f.seekg(0);

    file.data.resize(size);
    f.read((char*)file.data.data(), size);
    file.pos = 0;

    int fd = next_fd++;
    files[fd] = std::move(file);
    return fd;
}

int Close(int fd) {
    if (!files.count(fd))
        return -1;

    files.erase(fd);
    return 0;
}

bool Owns(int fd) {
    return files.count(fd) != 0;
}

int Read(int fd, void* buffer, uint32_t size) {
    if (!files.count(fd))
        return -1;

    File& f = files[fd];
    uint32_t left = (uint32_t)f.data.size() - f.pos;
    uint32_t toRead = size < left ? size : left;

    memcpy(buffer, f.data.data() + f.pos, toRead);
    f.pos += toRead;
    return toRead;
}

int Seek(int fd, uint32_t pos) {
    if (!files.count(fd))
        return -1;

    files[fd].pos = pos;
    return 0;
}

int Ioctl(int,
          uint32_t,
          void*, uint32_t,
          void*, uint32_t) {
    // FS do Wii quase não usa ioctl
    return 0;
}

} // namespace FS