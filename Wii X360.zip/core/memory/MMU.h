#pragma once
#include <cstdint>
inline uint8_t* MMU_Translate(uint8_t* mem1,uint8_t* mem2,uint32_t addr){
 if(addr<0x01800000) return mem1+addr;
 if(addr>=0x80000000&&addr<0x81800000) return mem1+(addr-0x80000000);
 if(addr>=0x90000000&&addr<0x94000000) return mem2+(addr-0x90000000);
 return nullptr;
}
