#pragma once
#include <cstdint>

enum class MMUAccess {
    Read,
    Write,
    Execute
};

namespace MMU {

    void Init();

    uint8_t* Translate(uint32_t addr, MMUAccess access);

    uint8_t  Read8(uint32_t addr);
    uint16_t Read16(uint32_t addr);
    uint32_t Read32(uint32_t addr);

    void Write8(uint32_t addr, uint8_t v);
    void Write16(uint32_t addr, uint16_t v);
    void Write32(uint32_t addr, uint32_t v);

    void InvalidateRange(uint32_t addr, uint32_t size);
}
