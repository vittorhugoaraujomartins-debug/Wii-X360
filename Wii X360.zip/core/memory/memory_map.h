#pragma once
#include <cstdint>

namespace WiiMem {

// =========================
// Endereços reais do Wii
// =========================

static constexpr uint32_t MEM1_START = 0x80000000;
static constexpr uint32_t MEM1_SIZE  = 0x01800000; // 24 MB

static constexpr uint32_t MEM2_START = 0x90000000;
static constexpr uint32_t MEM2_SIZE  = 0x04000000; // 64 MB

static constexpr uint32_t ROM_START  = 0x10000000;
static constexpr uint32_t ROM_SIZE   = 0x10000000; // 256 MB (seguro)

// =========================
// Inicialização
// =========================

bool Init();
void Shutdown();

// =========================
// Leitura / escrita (CPU + JIT)
// =========================

uint8_t  Read8(uint32_t addr);
uint16_t Read16(uint32_t addr);
uint32_t Read32(uint32_t addr);

void Write8(uint32_t addr, uint8_t v);
void Write16(uint32_t addr, uint16_t v);
void Write32(uint32_t addr, uint32_t v);

// =========================
// FAST PATH JIT
// =========================

uint8_t* Translate(uint32_t addr);
bool IsValidAddress(uint32_t addr);

// =========================
// ROM
// =========================

bool LoadROM(const char* path);

}
