#include <xtl.h>
#include <xgraphics.h>
#include <cstdio>
#include <thread>
#include <chrono>

#include "MemoryManager.h"
#include "ram_manager.h"
#include "XenonCPU.h"
#include "ppc_jit.h"
#include "IOS.h"
#include "GX.h"
#include "GXFIFO.h"
#include "XenosGPU.h"

// ----------------- Instâncias Globais -----------------
WiiCPU::XenonCPU cpu;
PPCJIT jit;

static bool g_running = true;

// ----------------- Threads -----------------

void CPUThread() {
    const int CYCLES_PER_FRAME = 12000000; // Wii ~729MHz / 60fps

    while (g_running) {
        cpu.RunCycles(CYCLES_PER_FRAME);
        std::this_thread::sleep_for(std::chrono::milliseconds(0));
    }
}

void GPUThread() {
    while (g_running) {
        if (GXFIFO::HasCommands()) {
            GXFIFO::Execute();
            GX_Draw();
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
}

void IOSThread() {
    while (g_running) {
        IOS::Update();
        std::this_thread::sleep_for(std::chrono::milliseconds(4));
    }
}

// ----------------- Inicialização -----------------

bool InitEmulator() {
    if (!WiiX360::MemoryManager::Initialize()) {
        DbgPrint("Falha em MemoryManager!\n");
        return false;
    }

    if (!WiiX360::RamManager::Init()) {
        DbgPrint("Falha em RamManager!\n");
        return false;
    }

    cpu.Initialize();
    jit.Reset();

    IOS::Init();
    GX::Init();
    XenosGPU::Init();

    // 🔥 Pré-compilação / cache
    GX::PrecompileShaders();
    GX::BuildStaticMeshes();
    jit.PrecompileHotBlocks(0x80004000, 0x80020000);

    DbgPrint("Emulador inicializado com sucesso!\n");
    return true;
}

// ----------------- Shutdown -----------------

void ShutdownEmulator() {
    g_running = false;

    GX::Shutdown();
    IOS::Shutdown();
    XenosGPU::Shutdown();
    WiiX360::RamManager::Shutdown();
    WiiX360::MemoryManager::Shutdown();

    DbgPrint("Emulador finalizado.\n");
}

// ----------------- Main -----------------

void main() {
    if (!InitEmulator())
        return;

    std::thread cpuThread(CPUThread);
    std::thread gpuThread(GPUThread);
    std::thread iosThread(IOSThread);

    while (true) {
        XVideoWaitForVBlank();

        XINPUT_STATE state{};
        if (XInputGetState(0, &state) == ERROR_SUCCESS) {
            if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_BACK) &&
                (state.Gamepad.wButtons & XINPUT_GAMEPAD_START)) {
                break;
            }
        }
    }

    ShutdownEmulator();

    cpuThread.join();
    gpuThread.join();
    iosThread.join();
}
