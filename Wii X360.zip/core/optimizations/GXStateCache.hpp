#pragma once
#include <cstdint>

struct GXState {
    uint32_t blendMode;
    uint32_t depthMode;
    uint32_t cullMode;
    uint32_t texConfig;
};

class GXStateCache {
public:
    void Reset() { valid = false; }

    bool IsSame(const GXState& s) const {
        if (!valid) return false;
        return memcmp(&state, &s, sizeof(GXState)) == 0;
    }

    void Update(const GXState& s) {
        state = s;
        valid = true;
    }

private:
    GXState state{};
    bool valid = false;
};