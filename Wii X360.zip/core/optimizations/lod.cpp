#include "Optimizations.hpp"

void LOD_Update(LODObject* obj, float cameraDistance)
{
    if (cameraDistance < 15.0f)
        obj->lodLevel = 0; // full
    else if (cameraDistance < 40.0f)
        obj->lodLevel = 1; // medium
    else
        obj->lodLevel = 2; // low
}
#include "LOD.h"

float LOD::Compute(float distance) {
    if (distance < 8.0f) return 1.0f;
    if (distance < 20.0f) return 0.75f;
    if (distance < 50.0f) return 0.5f;
    return 0.25f;
}