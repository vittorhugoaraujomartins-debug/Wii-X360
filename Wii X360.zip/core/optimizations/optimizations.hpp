#pragma once

// Limites seguros para Xbox 360
#define MAX_VISIBLE_OBJECTS 4096
#define MAX_INSTANCES       2048

// ====== LOD ======
struct LODObject {
    float distance;
    int   lodLevel;
};

// ====== Occlusion ======
struct BoundingBox {
    float minX, minY, minZ;
    float maxX, maxY, maxZ;
};

// ====== API ======
void LOD_Update(LODObject* obj, float cameraDistance);
bool Occlusion_Test(const BoundingBox& box);

void GreedyMesh_Build();
void GPUInstancing_Submit();
void PreRender_LoadAssets();