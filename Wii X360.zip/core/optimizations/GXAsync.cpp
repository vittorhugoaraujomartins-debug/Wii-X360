#include "GXAsync.h"

void GXAsync::SubmitAsync(std::function<void()> job) {
    threadQueue.push(job);
}

void GXAsync::Process() {
    while (!threadQueue.empty()) {
        threadQueue.pop()();
    }
}