#include "Optimizations.hpp"

void PreRender_LoadAssets()
{
    // Pré-carrega shaders e modelos críticos
    // Evita stutter durante gameplay
}

#include "PreRender.h"

void PreRender::WarmupShaders(const std::vector<Shader*>& shaders) {
    for (auto* s : shaders) {
        XenosGPU::CompileShader(s);
    }
}