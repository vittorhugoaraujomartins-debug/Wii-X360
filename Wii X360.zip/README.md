
Wii Emulator for Xbox 360
========================

This is a **base emulator scaffold**.

Current state:
- Executable skeleton
- CPU (PowerPC) stub
- GPU (GX) stub
- Audio DSP stub
- Input stub

This does NOT run games yet.
