
#include "gpu.h"
void GPU::GXSync(){
    fifoCPUFlush();
    fifoGPUWait();
}
