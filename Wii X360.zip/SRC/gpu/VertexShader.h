#pragma once
#include <xgraphics.h>

namespace VertexShader {

// Inicializa shaders
bool Init(IDirect3DDevice9* device);

// Libera recursos
void Shutdown();

// Ativa vertex shader padrão
void Bind();

// Desativa vertex shader
void Unbind();

}