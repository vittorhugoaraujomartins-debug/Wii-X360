#pragma once
#include <stdint.h>

struct GXBPState {
    bool zTest;
    bool zWrite;
    bool blend;
};

extern GXBPState g_bp;

void GXWriteBP(uint8_t reg, uint32_t val);