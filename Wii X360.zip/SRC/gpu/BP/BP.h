#pragma once
#include <cstdint>
#include <d3d9.h>

struct BPState
{
    // Depth
    bool depthEnable = false;
    bool depthWrite  = false;
    uint8_t depthFunc = 0;

    // Blend
    bool blendEnable = false;
    uint8_t blendSrc = 0;
    uint8_t blendDst = 0;
    uint8_t blendOp  = 0;

    // Color Mask
    bool colorMaskR = true;
    bool colorMaskG = true;
    bool colorMaskB = true;
    bool colorMaskA = true;

    // Alpha
    bool alphaEnable = false;
    uint8_t alphaFunc = 0;
    uint8_t alphaRef  = 0;

    // Dirty flags
    bool dirtyDepth = true;
    bool dirtyBlend = true;
    bool dirtyColor = true;
    bool dirtyAlpha = true;
};

namespace GX
{
    void BP_Reset();
    void BP_Write(uint32_t reg, uint32_t value);
    void BP_Apply();
}