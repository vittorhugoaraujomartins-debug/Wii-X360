#pragma once
#include <stdint.h>

namespace GX {

struct BPState {
    bool blendEnable;
    bool depthEnable;
    bool colorWrite;
};

extern BPState gBP;

void BP_Reset();
void BP_Write(uint32_t reg, uint32_t value);

}