#include "BP.h"

extern IDirect3DDevice9* g_d3d;

namespace GX {

static BPState gBP;
static BPState gLastApplied;

// ------------------------------------------------------------

void BP_Reset()
{
    gBP = BPState();
    gLastApplied = BPState();
}

// ------------------------------------------------------------

void BP_Write(uint32_t reg, uint32_t value)
{
    switch (reg)
    {
        case 0x40: // ZMODE
        {
            bool newEnable = (value & 1);
            uint8_t newFunc = (value >> 1) & 0x7;
            bool newWrite = (value >> 4) & 1;

            if (gBP.depthEnable != newEnable ||
                gBP.depthFunc   != newFunc ||
                gBP.depthWrite  != newWrite)
            {
                gBP.depthEnable = newEnable;
                gBP.depthFunc   = newFunc;
                gBP.depthWrite  = newWrite;
                gBP.dirtyDepth = true;
            }
            break;
        }

        case 0x41: // BLENDMODE
        {
            bool newEnable = (value & 1);
            uint8_t newSrc = (value >> 1) & 0x7;
            uint8_t newDst = (value >> 4) & 0x7;
            uint8_t newOp  = (value >> 7) & 0x3;

            if (gBP.blendEnable != newEnable ||
                gBP.blendSrc != newSrc ||
                gBP.blendDst != newDst ||
                gBP.blendOp  != newOp)
            {
                gBP.blendEnable = newEnable;
                gBP.blendSrc = newSrc;
                gBP.blendDst = newDst;
                gBP.blendOp  = newOp;
                gBP.dirtyBlend = true;
            }
            break;
        }

        case 0x42: // COLOR MASK
        {
            bool r = value & 1;
            bool g = value & 2;
            bool b = value & 4;
            bool a = value & 8;

            if (gBP.colorMaskR != r ||
                gBP.colorMaskG != g ||
                gBP.colorMaskB != b ||
                gBP.colorMaskA != a)
            {
                gBP.colorMaskR = r;
                gBP.colorMaskG = g;
                gBP.colorMaskB = b;
                gBP.colorMaskA = a;
                gBP.dirtyColor = true;
            }
            break;
        }

        case 0x43: // ALPHA
        {
            uint8_t func = value & 0x7;
            uint8_t ref  = (value >> 8) & 0xFF;

            if (gBP.alphaFunc != func ||
                gBP.alphaRef  != ref)
            {
                gBP.alphaEnable = true;
                gBP.alphaFunc = func;
                gBP.alphaRef  = ref;
                gBP.dirtyAlpha = true;
            }
            break;
        }
    }
}

static D3DCMPFUNC ConvertCompare(uint8_t f)
{
    switch (f)
    {
        case 0: return D3DCMP_NEVER;
        case 1: return D3DCMP_LESS;
        case 2: return D3DCMP_EQUAL;
        case 3: return D3DCMP_LESSEQUAL;
        case 4: return D3DCMP_GREATER;
        case 5: return D3DCMP_NOTEQUAL;
        case 6: return D3DCMP_GREATEREQUAL;
        default: return D3DCMP_ALWAYS;
    }
}


void BP_Apply()
{
    // 🚀 Skip total
    if (!gBP.dirtyDepth &&
        !gBP.dirtyBlend &&
        !gBP.dirtyColor &&
        !gBP.dirtyAlpha)
        return;

    // ================= DEPTH =================
    if (gBP.dirtyDepth)
    {
        g_d3d->SetRenderState(D3DRS_ZENABLE,
            gBP.depthEnable ? TRUE : FALSE);

        g_d3d->SetRenderState(D3DRS_ZWRITEENABLE,
            gBP.depthWrite ? TRUE : FALSE);

        g_d3d->SetRenderState(D3DRS_ZFUNC,
            ConvertCompare(gBP.depthFunc));

        gBP.dirtyDepth = false;
    }

    // ================= BLEND =================
    if (gBP.dirtyBlend)
    {
        g_d3d->SetRenderState(D3DRS_ALPHABLENDENABLE,
            gBP.blendEnable ? TRUE : FALSE);

        gBP.dirtyBlend = false;
    }

    // ================= COLOR =================
    if (gBP.dirtyColor)
    {
        DWORD mask = 0;

        if (gBP.colorMaskR) mask |= D3DCOLORWRITEENABLE_RED;
        if (gBP.colorMaskG) mask |= D3DCOLORWRITEENABLE_GREEN;
        if (gBP.colorMaskB) mask |= D3DCOLORWRITEENABLE_BLUE;
        if (gBP.colorMaskA) mask |= D3DCOLORWRITEENABLE_ALPHA;

        g_d3d->SetRenderState(D3DRS_COLORWRITEENABLE, mask);

        gBP.dirtyColor = false;
    }

    // ================= ALPHA =================
    if (gBP.dirtyAlpha)
    {
        g_d3d->SetRenderState(
            D3DRS_ALPHATESTENABLE,
            gBP.alphaEnable ? TRUE : FALSE);

        g_d3d->SetRenderState(
            D3DRS_ALPHAFUNC,
            ConvertCompare(gBP.alphaFunc));

        g_d3d->SetRenderState(
            D3DRS_ALPHAREF,
            gBP.alphaRef);

        gBP.dirtyAlpha = false;
    }
}




