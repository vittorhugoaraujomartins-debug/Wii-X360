#include "BP.h"

namespace GX {

BPState gBP;

void BP_Reset() {
    gBP.blendEnable = false;
    gBP.depthEnable = false;
    gBP.colorWrite  = true;
}

void BP_Write(uint32_t reg, uint32_t value) {
    switch (reg) {

    case 0x41: // BLENDMODE
        gBP.blendEnable = (value & 1);
        break;

    case 0x40: // ZMODE
        gBP.depthEnable = (value & 1);
        break;

    case 0x42: // COLOR WRITE
        gBP.colorWrite = (value != 0);
        break;
    }
}

}