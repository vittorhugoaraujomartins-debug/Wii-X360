#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct GXVertexArrays {
    float*    pos;     // xyz xyz xyz
    uint32_t* color0;  // RGBA8
    float*    tex0;    // uv uv uv
};

extern GXVertexArrays g_vertexArrays;