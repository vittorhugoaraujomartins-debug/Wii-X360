#include "GXVertexFormat.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>
