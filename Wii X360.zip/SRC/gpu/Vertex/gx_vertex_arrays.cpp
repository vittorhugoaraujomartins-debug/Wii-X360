#include "gx_vertex_arrays.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


GXVertexArrays g_vertexArrays = {
    nullptr,
    nullptr,
    nullptr
};