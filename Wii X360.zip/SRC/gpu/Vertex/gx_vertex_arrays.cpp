#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


GXVertexArrays g_vertexArrays = {
    nullptr,
    nullptr,
    nullptr
};