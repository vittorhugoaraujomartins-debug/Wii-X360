#include "gx_vertex.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):

namespace {

// Endereços base (vindos do CP futuramente)
uint32_t posBase = 0;
uint32_t colBase = 0;
uint32_t uvBase  = 0;

uint32_t posStride = 12; // 3 floats
uint32_t colStride = 4;  // RGBA8
uint32_t uvStride  = 8;  // 2 floats

}

namespace GXVTX {

void Init() {
    // valores iniciais seguros
}

void Shutdown() {}

static inline void ReadPosition(uint32_t index, float* out) {
    uint32_t addr = posBase + index * posStride;
    out[0] = *(float*)MemoryAccess::Read32(addr + 0);
    out[1] = *(float*)MemoryAccess::Read32(addr + 4);
    out[2] = *(float*)MemoryAccess::Read32(addr + 8);
}

static inline uint32_t ReadColor(uint32_t index) {
    uint32_t addr = colBase + index * colStride;
    return MemoryAccess::Read32(addr);
}

static inline void ReadUV(uint32_t index, float* out) {
    uint32_t addr = uvBase + index * uvStride;
    out[0] = *(float*)MemoryAccess::Read32(addr + 0);
    out[1] = *(float*)MemoryAccess::Read32(addr + 4);
}

GXVertex FetchVertex(uint32_t index) {
    GXVertex v{};

    ReadPosition(index, v.pos);
    v.color = ReadColor(index);
    ReadUV(index, v.uv);

    return v;
}

}



#include "gx_vertex.h"

namespace GXVertex {

static float ReadFloat(uint8_t* f, int& rp)
{
    float v = *(float*)&f[rp];
    rp += 4;
    return v;
}

static uint32_t ReadU32(uint8_t* f, int& rp)
{
    uint32_t v = *(uint32_t*)&f[rp];
    rp += 4;
    return v;
}

void LoadVertex(uint8_t* fifo, int& rp, Vertex& out)
{
    out.x = ReadFloat(fifo, rp);
    out.y = ReadFloat(fifo, rp);
    out.z = ReadFloat(fifo, rp);

    out.u = ReadFloat(fifo, rp);
    out.v = ReadFloat(fifo, rp);

    out.color = ReadU32(fifo, rp);
}

}