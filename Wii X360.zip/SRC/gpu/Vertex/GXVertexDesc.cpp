#include "GXVertexDesc.h"
#include <cstring>

// ================= STATE =================

static GXVertexDescState g_vcd;

// ================= API =================

namespace GXVCD {

void Init() {
    memset(&g_vcd, 0, sizeof(g_vcd));

    // Defaults seguros
    g_vcd.pos.attr   = GX_VA_POS;
    g_vcd.pos.type   = GX_DIRECT;
    g_vcd.pos.comp   = GX_F32;
    g_vcd.pos.count  = 3;

    g_vcd.color.attr = GX_VA_CLR0;
    g_vcd.color.type = GX_DIRECT;

    g_vcd.tex0.attr  = GX_VA_TEX0;
    g_vcd.tex0.type  = GX_NONE;
}

void SetPos(GXAttrType type, GXCompType comp, uint8_t count) {
    g_vcd.pos.type  = type;
    g_vcd.pos.comp  = comp;
    g_vcd.pos.count = count;
}

void SetColor(GXAttrType type) {
    g_vcd.color.type = type;
}

void SetTex0(GXAttrType type, GXCompType comp, uint8_t count) {
    g_vcd.tex0.type  = type;
    g_vcd.tex0.comp  = comp;
    g_vcd.tex0.count = count;
}

const GXVertexDescState& GetState() {
    return g_vcd;
}

}