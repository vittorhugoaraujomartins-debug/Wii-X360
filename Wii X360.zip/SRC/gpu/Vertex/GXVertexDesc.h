#pragma once

#include <cstdint>

// ================= GX Vertex Attributes =================

enum GXAttr {
    GX_VA_POS  = 0,
    GX_VA_NRM  = 1,
    GX_VA_CLR0 = 2,
    GX_VA_TEX0 = 3,
};

// Tipo de dado
enum GXAttrType {
    GX_NONE = 0,
    GX_DIRECT,
    GX_INDEX8,
    GX_INDEX16
};

// Formato
enum GXCompType {
    GX_F32 = 0,
    GX_U8,
    GX_S16
};

// Descriptor de um atributo
struct GXVertexAttrDesc {
    GXAttr       attr;
    GXAttrType   type;
    GXCompType   comp;
    uint8_t      count; // componentes (2,3,4)
};

// Estado global do VCD
struct GXVertexDescState {
    GXVertexAttrDesc pos;
    GXVertexAttrDesc color;
    GXVertexAttrDesc tex0;
};

namespace GXVCD {

void Init();
void SetPos(GXAttrType type, GXCompType comp, uint8_t count);
void SetColor(GXAttrType type);
void SetTex0(GXAttrType type, GXCompType comp, uint8_t count);

const GXVertexDescState& GetState();

}