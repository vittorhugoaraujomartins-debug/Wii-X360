#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

enum GXAttrType {
    GX_NONE = 0,
    GX_DIRECT = 1,
    GX_INDEX8 = 2,
    GX_INDEX16 = 3
};

struct GXVCD {
    GXAttrType pos;
    GXAttrType color0;
    GXAttrType tex0;
};

struct GXVAT {
    uint8_t posComp;   // XYZ
    uint8_t colorComp; // RGB/RGBA
    uint8_t texComp;   // ST
};

extern GXVCD g_vcd;
extern GXVAT g_vat;

#pragma once

struct GXVertex {
    float x, y, z;
    uint32_t color;
};