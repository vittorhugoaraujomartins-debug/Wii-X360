#include "GXVertex.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


GXVCD g_vcd = {
    GX_DIRECT,   // posição direta
    GX_DIRECT,   // cor direta
    GX_DIRECT    // texcoord direto
};

GXVAT g_vat = {
    3, // XYZ
    4, // RGBA
    2  // ST
};



