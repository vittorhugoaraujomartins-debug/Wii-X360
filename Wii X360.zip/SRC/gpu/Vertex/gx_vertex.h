#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct GXVertex {
    float pos[3];
    uint32_t color;
    float uv[2];
};

namespace GXVTX {

void Init();
void Shutdown();

// index = índice lógico do vértice (CP)
GXVertex FetchVertex(uint32_t index);

}

#pragma once

struct GXVertex {
    float x, y, z;
    uint32_t color;
    float u, v;
};