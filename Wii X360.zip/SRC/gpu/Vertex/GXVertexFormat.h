#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct GXVertex {
    float x, y, z;
    uint32_t color;
    float s, t;
};