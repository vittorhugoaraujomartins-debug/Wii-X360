#include "TextureManager.h"
#include <xtl.h>
#include <cstring>

static IDirect3DDevice9* g_device = nullptr;

namespace TextureManager {

bool Init(IDirect3DDevice9* device) {
    g_device = device;
    return g_device != nullptr;
}

void Shutdown() {
    g_device = nullptr;
}

IDirect3DTexture9* CreateTexture2D(
    uint32_t width,
    uint32_t height,
    const void* rgbaData
) {
    if (!g_device) return nullptr;

    IDirect3DTexture9* tex = nullptr;

    HRESULT hr = g_device->CreateTexture(
        width,
        height,
        1,
        0,
        D3DFMT_A8R8G8B8,
        D3DPOOL_DEFAULT,
        &tex,
        nullptr
    );

    if (FAILED(hr)) return nullptr;

    D3DLOCKED_RECT rect;
    tex->LockRect(0, &rect, nullptr, 0);

    memcpy(rect.pBits, rgbaData, width * height * 4);

    tex->UnlockRect(0);
    return tex;
}

void Bind(IDirect3DTexture9* tex) {
    if (!g_device) return;
    g_device->SetTexture(0, tex);
}

void Unbind() {
    if (!g_device) return;
    g_device->SetTexture(0, nullptr);
}

}