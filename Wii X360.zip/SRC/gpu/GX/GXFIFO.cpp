#include "GXFIFO.h"
#include "XenosGPU.h"
#include <queue>
#include <cstring>

static std::queue<uint32_t> fifo;

namespace GXFIFO {

void Init() {
    while (!fifo.empty()) fifo.pop();
}

void Push32(uint32_t v) {
    fifo.push(v);
}

void PushFloat(float f) {
    uint32_t v;
    memcpy(&v, &f, sizeof(uint32_t));
    fifo.push(v);
}

void Execute() {

    while (!fifo.empty()) {

        uint32_t cmd = fifo.front();
        fifo.pop();

        // GXBegin
        if ((cmd & 0xF0000000) == 0x10000000) {
            XenosGPU::Begin();
        }
        // GXEnd
        else if ((cmd & 0xF0000000) == 0x40000000) {
            XenosGPU::End();
        }
        // Vértice
        else {
            float x = *(float*)&cmd;

            uint32_t vy = fifo.front(); fifo.pop();
            uint32_t vz = fifo.front(); fifo.pop();
            uint32_t color = fifo.front(); fifo.pop();

            float y = *(float*)&vy;
            float z = *(float*)&vz;

            XenosGPU::PushVertex(x, y, z, color);
        }
    }
}

}