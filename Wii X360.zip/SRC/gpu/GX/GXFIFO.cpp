#include "GXFIFO.h"
#include "XenosGPU.h"

namespace GXFIFO {

FIFO g_fifo;

void FIFO::Init(uint32_t sizeBytes) {
    buffer.clear();
    buffer.reserve(sizeBytes / 4);
    read_ptr = 0;
}

void FIFO::WriteU32(uint32_t v) {
    buffer.push_back(v);
}

bool FIFO::HasData(uint32_t count) const {
    return (read_ptr + count) <= buffer.size();
}

uint32_t FIFO::Read32() {
    return HasData(1) ? buffer[read_ptr++] : 0;
}

void FIFO::Execute() {
    read_ptr = 0;

    while (HasData(1)) {
        uint32_t cmd = Read32();

        switch (cmd) {

        case GX_CMD_LOAD_CP:
            XenosGPU::ApplyGXState(
                *reinterpret_cast<GX::GXState*>(Read32())
            );
            break;

        case GX_CMD_DRAW: {
            auto prim  = (GX::PrimitiveType)Read32();
            auto count = Read32();
            XenosGPU::Draw(prim, count);
            break;
        }

        default:
            break;
        }
    }
}

} // namespace GXFIFO

#include "GXFIFO.h"
#include "GX.h"

static std::queue<uint32_t> fifo;

namespace GXFIFO {

void Init() {
    while (!fifo.empty()) fifo.pop();
}

void Push(uint32_t cmd) {
    fifo.push(cmd);
}

bool HasCommands() {
    return !fifo.empty();
}

void Execute() {
    while (!fifo.empty()) {
        uint32_t cmd = fifo.front();
        fifo.pop();
        GX::ProcessCommand(cmd);
    }
}

}


#include "GXFIFO.h"
#include "GX.h"
#include <vector>

static std::vector<uint8_t> fifo;
static size_t readPtr = 0;

namespace GXFIFO {

void Init() {
    fifo.clear();
    readPtr = 0;
}

void WriteU8(uint8_t v) {
    fifo.push_back(v);
}

void WriteU16(uint16_t v) {
    fifo.push_back(v >> 8);
    fifo.push_back(v & 0xFF);
}

void WriteU32(uint32_t v) {
    fifo.push_back((v >> 24) & 0xFF);
    fifo.push_back((v >> 16) & 0xFF);
    fifo.push_back((v >> 8) & 0xFF);
    fifo.push_back(v & 0xFF);
}

static uint8_t ReadU8() {
    return fifo[readPtr++];
}

static uint16_t ReadU16() {
    uint16_t v = (ReadU8() << 8);
    v |= ReadU8();
    return v;
}

void Execute() {
    while (readPtr < fifo.size()) {
        uint8_t cmd = ReadU8();
        GX::ProcessCommand(cmd);
    }

    fifo.clear();
    readPtr = 0;
}

}

#include "GXVertexFormat.h"
#include "GXVertex.h"
#include "XenosGPU.h"

static GXVertex currentVertex;

void GXFIFO::Write(uint32_t data) {

    static int stage = 0;

    switch (stage) {

    case 0: // posição
        currentVertex.x = ((data >> 16) & 0xFF) / 128.0f;
        currentVertex.y = ((data >> 8) & 0xFF) / 128.0f;
        currentVertex.z = (data & 0xFF) / 128.0f;
        stage++;
        break;

    case 1: // cor
        currentVertex.color = data;
        stage++;
        break;

    case 2: // texcoord
        currentVertex.s = ((data >> 16) & 0xFFFF) / 65535.0f;
        currentVertex.t = (data & 0xFFFF) / 65535.0f;
        stage = 0;

        XenosGPU::SubmitVertex(currentVertex);
        break;
    }
}