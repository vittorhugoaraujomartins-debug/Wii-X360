#pragma once
#include <cstdint>

struct GXVertex {
    float x, y, z;
    uint32_t color;
    float s, t;
};