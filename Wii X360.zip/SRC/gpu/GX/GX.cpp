#include "GX.h"
#include "GXFIFO.h"
#include <cstring>

namespace GX {

static GXState g_state;
static PrimitiveType g_currentPrim;

static std::vector<float> g_vertexBuffer;
static constexpr uint32_t FLOATS_PER_VERTEX = 7;

void Init() {
    memset(&g_state, 0, sizeof(GXState));
    g_currentPrim = GX_TRIANGLES;
    g_vertexBuffer.clear();
}

void Shutdown() {
    g_vertexBuffer.clear();
}

void SetState(const GXState& state) {
    g_state = state;

    GXFIFO::g_fifo.WriteU32(GX_CMD_LOAD_CP);
    GXFIFO::g_fifo.WriteU32(reinterpret_cast<uint32_t>(&g_state));
}

void Begin(PrimitiveType prim) {
    g_currentPrim = prim;
    g_vertexBuffer.clear();
}

void Position3f(float x, float y, float z) {
    g_vertexBuffer.push_back(x);
    g_vertexBuffer.push_back(y);
    g_vertexBuffer.push_back(z);
}

void Color4f(float r, float g, float b, float a) {
    g_vertexBuffer.push_back(r);
    g_vertexBuffer.push_back(g);
    g_vertexBuffer.push_back(b);
    g_vertexBuffer.push_back(a);
}

void End() {
    if (g_vertexBuffer.empty())
        return;

    GXFIFO::g_fifo.WriteU32(GX_CMD_DRAW);
    GXFIFO::g_fifo.WriteU32(static_cast<uint32_t>(g_currentPrim));
    GXFIFO::g_fifo.WriteU32(
        g_vertexBuffer.size() / FLOATS_PER_VERTEX
    );

    XenosGPU::UploadVertexBuffer(
        g_vertexBuffer.data(),
        g_vertexBuffer.size() * sizeof(float),
        FLOATS_PER_VERTEX * sizeof(float)
    );

    g_vertexBuffer.clear();
}

void Flush() {
    InstrOrder::IOBarrier();
    GXFIFO::g_fifo.Execute();
}

} // namespace GX

#include "GX.h"
#include "XenosGPU.h"

struct GXVertex {
    float x, y, z;
};

static GXVertex verts[3];
static int vtxCount = 0;
static bool drawing = false;

namespace GX {

void Init() {
    vtxCount = 0;
    drawing = false;
}

void ProcessCommand(uint32_t cmd) {
    uint8_t type = (cmd >> 28) & 0xF;

    switch (type) {

    case 0x1: // BEGIN
        vtxCount = 0;
        drawing = true;
        break;

    case 0x2: { // VTX (simples)
        if (!drawing || vtxCount >= 3) break;

        int x = (cmd >> 16) & 0xFF;
        int y = (cmd >> 8)  & 0xFF;
        int z = cmd & 0xFF;

        verts[vtxCount++] = {
            (x - 128) / 128.0f,
            (y - 128) / 128.0f,
            (z - 128) / 128.0f
        };
        break;
    }

    case 0x4: // END
        if (vtxCount == 3)
            XenosGPU::DrawTriangle(verts);
        drawing = false;
        break;
    }
}

void Draw() {
    // vazio por enquanto
}

#include "GX.h"
#include "XenosGPU.h"
#include <vector>

static std::vector<GXVertex> vertices;
static bool drawing = false;

// TEV estado mínimo
static GXColor tevColor = {1, 1, 1, 1};

namespace GX {

void Init() {
    vertices.clear();
    drawing = false;
}

static float norm(uint8_t v) {
    return v / 255.0f;
}

void ProcessCommand(uint8_t cmd) {

    switch (cmd) {

    case 0x10: // GX_BEGIN
        vertices.clear();
        drawing = true;
        break;

    case 0x11: { // GX_VERTEX
        if (!drawing) break;

        GXVertex v;
        v.x = (int8_t)GXFIFO::ReadU8() / 64.0f;
        v.y = (int8_t)GXFIFO::ReadU8() / 64.0f;
        v.z = (int8_t)GXFIFO::ReadU8() / 64.0f;

        v.color.r = norm(GXFIFO::ReadU8());
        v.color.g = norm(GXFIFO::ReadU8());
        v.color.b = norm(GXFIFO::ReadU8());
        v.color.a = 1.0f;

        // TEV mínimo
        v.color.r *= tevColor.r;
        v.color.g *= tevColor.g;
        v.color.b *= tevColor.b;

        vertices.push_back(v);
        break;
    }

    case 0x20: { // GX_SET_TEV_COLOR
        tevColor.r = norm(GXFIFO::ReadU8());
        tevColor.g = norm(GXFIFO::ReadU8());
        tevColor.b = norm(GXFIFO::ReadU8());
        tevColor.a = 1.0f;
        break;
    }

    case 0x12: // GX_END
        drawing = false;
        if (vertices.size() >= 3)
            XenosGPU::Draw(vertices);
        break;
    }
}

}