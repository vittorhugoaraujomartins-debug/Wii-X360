#include "GX.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void GXBegin(GXPrimitive prim) {
    GXFIFO::Push32(0x10000000 | prim);
}

void GXEnd() {
    GXFIFO::Push32(0x40000000);
}

void GXPosition3f32(float x, float y, float z) {
    GXFIFO::PushFloat(x);
    GXFIFO::PushFloat(y);
    GXFIFO::PushFloat(z);
}

void GXColor4u8(uint8_t r, uint8_t g, uint8_t b, uint8_t a) {
    uint32_t color =
        (a << 24) | (r << 16) | (g << 8) | b;
    GXFIFO::Push32(color);
}

