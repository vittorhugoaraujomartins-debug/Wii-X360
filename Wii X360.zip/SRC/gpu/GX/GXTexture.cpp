#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include "GXTexture.h"

static uint32_t checker[64 * 64];

GXTexture g_activeTexture;

void GXTexture_Init() {

    for (int y = 0; y < 64; y++) {
        for (int x = 0; x < 64; x++) {
            bool c = ((x / 8 + y / 8) & 1);
            checker[y * 64 + x] = c ? 0xFFFFFFFF : 0xFF000000;
        }
    }

    g_activeTexture.width = 64;
    g_activeTexture.height = 64;
    g_activeTexture.data = checker;
}