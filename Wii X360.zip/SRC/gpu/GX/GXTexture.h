#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

struct GXTexture {
    uint32_t width;
    uint32_t height;
    uint32_t* data;
};

extern GXTexture g_activeTexture;