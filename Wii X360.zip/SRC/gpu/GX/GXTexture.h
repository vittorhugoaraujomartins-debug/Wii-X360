#pragma once
#include <cstdint>

struct GXTexture {
    uint32_t width;
    uint32_t height;
    uint32_t* data;
};

extern GXTexture g_activeTexture;