#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

void GX_Begin(uint8_t primitive, uint16_t vertexCount, const uint8_t* fifo);