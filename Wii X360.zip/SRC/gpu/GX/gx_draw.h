#pragma once
#include <cstdint>

void GX_Begin(uint8_t primitive, uint16_t vertexCount, const uint8_t* fifo);