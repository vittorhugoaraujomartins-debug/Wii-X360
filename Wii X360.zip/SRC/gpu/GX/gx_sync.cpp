#include "gx_sync.h"
#include "gx_fifo.h"

namespace GX {

void DrawDone() {
    GXFIFO::Execute(); // flush imediato
}

}