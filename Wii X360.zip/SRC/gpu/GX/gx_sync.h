#pragma once
namespace GX {
    void DrawDone();
}