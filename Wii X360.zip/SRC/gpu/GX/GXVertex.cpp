#include "GXVertex.h"

GXVCD g_vcd = {
    GX_DIRECT,   // posição direta
    GX_DIRECT,   // cor direta
    GX_DIRECT    // texcoord direto
};

GXVAT g_vat = {
    3, // XYZ
    4, // RGBA
    2  // ST
};