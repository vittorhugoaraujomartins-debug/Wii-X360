#pragma once
#include <cstdint>

namespace GX {

    void Init();
    void ProcessCommand(uint32_t cmd);
    void Draw();
}

#pragma once
#include <cstdint>

struct GXColor {
    float r, g, b, a;
};

struct GXVertex {
    float x, y, z;
    GXColor color;
};

namespace GX {

    void Init();
    void ProcessCommand(uint8_t cmd);
}