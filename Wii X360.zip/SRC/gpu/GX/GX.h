#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

namespace GX {

    void Init();
    void ProcessCommand(uint32_t cmd);
    void Draw();
}

#pragma once
#include <cstdint>

struct GXColor {
    float r, g, b, a;
};

struct GXVertex {
    float x, y, z;
    GXColor color;
};

namespace GX {

    void Init();
    void ProcessCommand(uint8_t cmd);
}

#pragma once
#include <cstdint>

namespace GX {

enum PrimitiveType {
    GX_TRIANGLES = 0x90,
};

struct GXColor {
    uint8_t r, g, b, a;
};

void Init();
void Shutdown();

// API GX mínima
void GXBegin(PrimitiveType prim, uint16_t vtxCount);
void GXEnd();

void GXPosition3f32(float x, float y, float z);
void GXColor4u8(uint8_t r, uint8_t g, uint8_t b, uint8_t a);

}