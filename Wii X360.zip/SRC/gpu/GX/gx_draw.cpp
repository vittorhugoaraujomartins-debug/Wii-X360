#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void GX_Begin(uint8_t prim, uint16_t vertexCount, const uint8_t* fifo) {

    std::vector<GXVertex> vertices;
    vertices.reserve(vertexCount);

    for (uint16_t i = 0; i < vertexCount; i++) {
        vertices.push_back(GX_FetchVertex(fifo));
    }

    // Ponte GX -> GPU
    XenosGPU::DrawIndexed(prim, vertices);
}

EFB::Begin();

EFB::End();
EFB::Present();