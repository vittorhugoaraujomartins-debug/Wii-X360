#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>
// FIXME: include not found in project (left original below):
#include <queue>

namespace GXFIFO {

    void Init();
    void Push(uint32_t cmd);
    bool HasCommands();
    void Execute();
}

t
#pragma once
#include <cstdint>

namespace GXFIFO {

    void Init();
    void WriteU8(uint8_t v);
    void WriteU16(uint16_t v);
    void WriteU32(uint32_t v);

    void Execute();
}

#pragma once
#include <cstdint>
// FIXME: include not found in project (left original below):
#include <queue>

namespace GXFIFO {

void Init();
void Shutdown();

void Push32(uint32_t v);
void PushFloat(float f);

bool HasCommands();
uint32_t Pop32();
float PopFloat();

void Execute();

}