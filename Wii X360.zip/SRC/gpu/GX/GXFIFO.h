#pragma once
#include <cstdint>
#include <queue>

namespace GXFIFO {

    void Init();
    void Push(uint32_t cmd);
    bool HasCommands();
    void Execute();
}

t
#pragma once
#include <cstdint>

namespace GXFIFO {

    void Init();
    void WriteU8(uint8_t v);
    void WriteU16(uint16_t v);
    void WriteU32(uint32_t v);

    void Execute();
}

#pragma once
#include <cstdint>
#include <queue>

namespace GXFIFO {

void Init();
void Shutdown();

void Push32(uint32_t v);
void PushFloat(float f);

bool HasCommands();
uint32_t Pop32();
float PopFloat();

void Execute();

}