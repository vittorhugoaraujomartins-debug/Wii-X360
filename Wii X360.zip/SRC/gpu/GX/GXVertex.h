#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

enum GXAttrType {
    GX_NONE = 0,
    GX_DIRECT = 1,
    GX_INDEX8 = 2,
    GX_INDEX16 = 3
};

struct GXVCD {
    GXAttrType pos;
    GXAttrType color0;
    GXAttrType tex0;
};

struct GXVAT {
    uint8_t posComp;   // XYZ
    uint8_t colorComp; // RGB/RGBA
    uint8_t texComp;   // ST
};

extern GXVCD g_vcd;
extern GXVAT g_vat;

#pragma once
#include <cstdint>

struct GXVertex {
    float x, y, z;
    uint32_t color;
};