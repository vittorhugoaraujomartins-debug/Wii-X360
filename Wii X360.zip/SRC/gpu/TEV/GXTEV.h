#pragma once

#include <stdint.h>

namespace GXTEV {

// fontes
enum ColorSource {
    SRC_VERTEX,
    SRC_TEXTURE,
    SRC_PREV,
    SRC_CONST
};

// operações
enum Op {
    OP_ADD,
    OP_SUB,
    OP_MODULATE,
    OP_REPLACE
};

struct Stage {
    ColorSource a;
    ColorSource b;
    ColorSource c;
    ColorSource d;
    Op op;
};

void Init();
void Reset();

void SetStage(int id, const Stage& s);
void SetConstColor(uint32_t color);

uint32_t Apply(uint32_t vertexColor, uint32_t textureColor);

}
