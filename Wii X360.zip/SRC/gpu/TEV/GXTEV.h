#pragma once
#include <stdint.h>

namespace GXTEV {

static const int MAX_TEV_STAGES = 6;

// Fontes de cor
enum ColorSource {
    SRC_VERTEX,
    SRC_TEXTURE,
    SRC_PREV,
    SRC_CONST
};

// Operações TEV
enum Op {
    OP_REPLACE,
    OP_MODULATE,
    OP_ADD,
    OP_SUB
};

struct Stage {
    ColorSource a;
    ColorSource b;
    ColorSource d;   // bias/add
    Op op;
};

void Init();
void Reset();

void SetStage(int id, const Stage& s);
void SetConstColor(uint32_t color);

// Executa pipeline TEV
uint32_t Apply(uint32_t vertexColor, uint32_t textureColor);

}
