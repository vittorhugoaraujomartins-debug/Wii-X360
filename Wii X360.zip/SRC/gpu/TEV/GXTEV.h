#pragma once
#include <stdint.h>

namespace GXTEV {

static const int MAX_TEV_STAGES = 6;

// Fontes de cor
enum ColorSource {
    SRC_VERTEX,
    SRC_TEXTURE,
    SRC_PREV,
    SRC_CONST
};

// Operações TEV
enum Op {
    OP_REPLACE,
    OP_MODULATE,
    OP_ADD,
    OP_SUB
};

struct Stage {
    ColorSource a;
    ColorSource b;
    ColorSource d;   // bias/add
    Op op;
};

void Init();
void Reset();

void SetStage(int id, const Stage& s);
void SetConstColor(uint32_t color);

// Executa pipeline TEV
uint32_t Apply(uint32_t vertexColor, uint32_t textureColor);

}


enum TevScale {
    SCALE_1X,
    SCALE_2X,
    SCALE_4X,
    SCALE_HALF
};

enum TevBias {
    BIAS_ZERO,
    BIAS_ADD_HALF,
    BIAS_SUB_HALF
};

struct Stage {
    ColorSource a, b, c, d;
    TevOp       op;

    TevScale    scale = SCALE_1X;
    TevBias     bias  = BIAS_ZERO;
    bool        clamp = true;
};



struct TEVStage
{
    uint8_t colorA, colorB, colorC, colorD;
    uint8_t alphaA, alphaB, alphaC, alphaD;
    uint8_t colorOp;
    uint8_t alphaOp;
    bool clamp;
};

struct TEVState
{
    uint8_t numStages = 0;
    TEVStage stages[16];
};

extern TEVState g_tev;

namespace TEV
{
    void Reset();
    void SetStage(uint8_t stage, const TEVStage& s);
    void BuildShader();   // Gera HLSL dinâmico
}


enum FastPathType
{
    FAST_NONE,
    FAST_TEXTURE,
    FAST_VERTEX,
    FAST_MODULATE,
    FAST_ADD
};

static FastPathType g_fastPath = FAST_NONE;


