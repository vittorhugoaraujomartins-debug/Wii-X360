#include "vi.h"
#include "gx_fifo.h"
#include "scheduler.h"
#include "ppc_state.h"

static bool vblank = false;

namespace VI {

void Init() {
    vblank = false;
}

// Chamado no evento VBlank
void SetVBlank() {
    vblank = true;

    // Flush GX FIFO no VBlank (igual hardware)
    GXFIFO::Process();
}

// Tick opcional (se quiser polling)
void Tick() {
    if (vblank) {
        vblank = false;
    }
}

}