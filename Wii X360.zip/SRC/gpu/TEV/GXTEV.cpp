#include "GXTEV.h"

namespace GXTEV {

struct Stage {
    ColorSource a, b, c, d;

    TevBias bias;
    TevScale scale;

    bool clamp;

    uint8_t outReg; // 0=prev,1=reg0,2=reg1,3=reg2
};


static uint32_t g_reg[4]; // 0=prev,1,2,3

int activeStages = 0;

for (int i = 0; i < g_stageCount; i++)
{
    if (!IsStageDead(g_stages[i]))
        activeStages++;
}

if (activeStages == 0)
    return vertexColor;


if (g_stageCount == 2)
{
    // executa sem loop
    ExecuteStage(g_stages[0], vertexColor, textureColor);
    ExecuteStage(g_stages[1], vertexColor, textureColor);
    return g_reg[0];
}





// ================= UTIL =================

static inline int Clamp8(int v) {
    if (v < 0)   return 0;
    if (v > 255) return 255;
    return v;
}

static inline int Mul255(int a, int b) {
    return (a * b) / 255;
}

static inline void Split(uint32_t c, int& r, int& g, int& b, int& a) {
    r = (c >> 24) & 0xFF;
    g = (c >> 16) & 0xFF;
    b = (c >> 8 ) & 0xFF;
    a =  c        & 0xFF;
}

static inline uint32_t Pack(int r, int g, int b, int a) {
    return (Clamp8(r) << 24) |
           (Clamp8(g) << 16) |
           (Clamp8(b) << 8 ) |
            Clamp8(a);
}

// ================= OTIMIZAÇÃO =================

static bool IsStageDead(const Stage& st) {

    // REPLACE prev = prev → morto
    if (st.op == OP_REPLACE && st.a == SRC_PREV)
        return true;

    // ADD com zero
    if (st.op == OP_ADD && st.b == SRC_ZERO)
        return true;

    // SUB com zero
    if (st.op == OP_SUB && st.b == SRC_ZERO)
        return true;

    return false;
}


void Reset() {
    g_stageCount = 0;
    g_reg[0] = 0xFFFFFFFF; // prev
    g_reg[1] = g_reg[2] = g_reg[3] = 0;
}


static uint32_t GetSource(ColorSource src,
                          uint32_t vtx,
                          uint32_t tex)
{
    switch (src)
    {
        case SRC_VERTEX:  return vtx;
        case SRC_TEXTURE: return tex;
        case SRC_PREV:    return g_reg[0];
        case SRC_REG0:    return g_reg[1];
        case SRC_REG1:    return g_reg[2];
        case SRC_REG2:    return g_reg[3];
        case SRC_ZERO:    return 0;
        case SRC_ONE:     return 0xFFFFFFFF;
        default:          return 0;
    }
}



static bool IsStageDead(const Stage& st)
{
    // REPLACE prev->prev
    if (st.a == SRC_PREV &&
        st.b == SRC_ZERO &&
        st.c == SRC_ONE &&
        st.d == SRC_ZERO &&
        st.outReg == 0)
        return true;

    return false;
}





// ================= APPLY HLE AGRESSIVO =================


static inline void ApplyIndirectFast(
    float& u, float& v,
    uint32_t indirectTex)
{
    int r = (indirectTex >> 24) & 0xFF;
    int g = (indirectTex >> 16) & 0xFF;

    u += (r - 128) * 0.0039f;
    v += (g - 128) * 0.0039f;
}



uint32_t Apply(uint32_t vertexColor,
               uint32_t textureColor)
{
    g_reg[0] = vertexColor;

    for (int i = 0; i < g_stageCount; i++)
    {
        const Stage& st = g_stages[i];

        if (IsStageDead(st))
            continue;

        uint32_t A = GetSource(st.a, vertexColor, textureColor);
        uint32_t B = GetSource(st.b, vertexColor, textureColor);
        uint32_t C = GetSource(st.c, vertexColor, textureColor);
        uint32_t D = GetSource(st.d, vertexColor, textureColor);uint32_t Apply(uint32_t vertexColor,
               uint32_t textureColor)
{
    // ================= FAST PATH =================

    switch (g_fastPath)
    {
        case FAST_TEXTURE:
            return textureColor;

        case FAST_VERTEX:
            return vertexColor;

        case FAST_MODULATE:
        {
            int rV,gV,bV,aV;
            int rT,gT,bT,aT;

            Split(vertexColor,rV,gV,bV,aV);
            Split(textureColor,rT,gT,bT,aT);

            return Pack(
                Mul255(rV,rT),
                Mul255(gV,gT),
                Mul255(bV,bT),
                Mul255(aV,aT));
        }

        default:
            break;
    }

        int rA,gA,bA,aA;
        int rB,gB,bB,aB;
        int rC,gC,bC,aC;
        int rD,gD,bD,aD;

        Split(A,rA,gA,bA,aA);
        Split(B,rB,gB,bB,aB);
        Split(C,rC,gC,bC,aC);
        Split(D,rD,gD,bD,aD);

        int r = ((rA - rB) * rC) / 255 + rD;
        int g = ((gA - gB) * gC) / 255 + gD;
        int b = ((bA - bB) * bC) / 255 + bD;
        int a = ((aA - aB) * aC) / 255 + aD;

        // Bias
        if (st.bias == BIAS_ADD_HALF) {
            r+=128; g+=128; b+=128; a+=128;
        }
        else if (st.bias == BIAS_SUB_HALF) {
            r-=128; g-=128; b-=128; a-=128;
        }

        // Scale
        switch (st.scale) {
            case SCALE_2X: r*=2; g*=2; b*=2; a*=2; break;
            case SCALE_4X: r*=4; g*=4; b*=4; a*=4; break;
            case SCALE_HALF: r/=2; g/=2; b/=2; a/=2; break;
        }

        if (st.clamp) {
            r = Clamp8(r);
            g = Clamp8(g);
            b = Clamp8(b);
            a = Clamp8(a);
        }

        g_reg[st.outReg] = Pack(r,g,b,a);
    }

    return g_reg[0];
}




enum AlphaOp {
    ALPHA_NEVER,
    ALPHA_LESS,
    ALPHA_LEQUAL,
    ALPHA_EQUAL,
    ALPHA_GEQUAL,
    ALPHA_GREATER,
    ALPHA_NOTEQUAL,
    ALPHA_ALWAYS
};

static bool AlphaCompare(uint8_t a,
                         uint8_t ref,
                         AlphaOp op)
{
    switch (op) {
        case ALPHA_NEVER: return false;
        case ALPHA_LESS: return a < ref;
        case ALPHA_LEQUAL: return a <= ref;
        case ALPHA_EQUAL: return a == ref;
        case ALPHA_GEQUAL: return a >= ref;
        case ALPHA_GREATER: return a > ref;
        case ALPHA_NOTEQUAL: return a != ref;
        case ALPHA_ALWAYS: return true;
    }
    return true;
}



struct UVOffset {
    float du;
    float dv;
};

static UVOffset ApplyIndirect(float u,
                              float v,
                              uint32_t indirectTex)
{
    int r = (indirectTex >> 24) & 0xFF;
    int g = (indirectTex >> 16) & 0xFF;

    UVOffset off;
    off.du = (r - 128) / 255.0f;
    off.dv = (g - 128) / 255.0f;

    return off;
}



static void DetectFastPath()
{
    if (g_stageCount == 1)
    {
        const Stage& st = g_stages[0];

        // TEXTURE
        if (st.a == SRC_TEXTURE &&
            st.b == SRC_ZERO &&
            st.c == SRC_ONE &&
            st.d == SRC_ZERO)
        {
            g_fastPath = FAST_TEXTURE;
            return;
        }

        // VERTEX
        if (st.a == SRC_VERTEX &&
            st.b == SRC_ZERO &&
            st.c == SRC_ONE &&
            st.d == SRC_ZERO)
        {
            g_fastPath = FAST_VERTEX;
            return;
        }

        // MODULATE
        if (st.a == SRC_TEXTURE &&
            st.b == SRC_ZERO &&
            st.c == SRC_VERTEX &&
            st.d == SRC_ZERO)
        {
            g_fastPath = FAST_MODULATE;
            return;
        }
    }

    g_fastPath = FAST_NONE;
}



