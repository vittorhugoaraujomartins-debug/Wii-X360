#include "GXTEV.h"

namespace GXTEV {

static Stage g_stages[16];
static int g_stageCount = 0;

static uint32_t g_constColor = 0xFFFFFFFF;
static uint32_t g_prevColor  = 0xFFFFFFFF;

static inline uint8_t Mul(uint8_t a, uint8_t b) {
    return (uint8_t)((a * b) / 255);
}

static inline uint32_t Clamp(uint32_t c) {
    return c; // clamp real depois
}

static inline uint32_t GetSource(
    ColorSource src,
    uint32_t vc,
    uint32_t tc
) {
    switch (src) {
    case SRC_VERTEX:  return vc;
    case SRC_TEXTURE: return tc;
    case SRC_PREV:    return g_prevColor;
    case SRC_CONST:   return g_constColor;
    default:          return 0;
    }
}

static uint32_t Modulate(uint32_t a, uint32_t b) {
    return
        (Mul((a>>24)&0xFF,(b>>24)&0xFF) << 24) |
        (Mul((a>>16)&0xFF,(b>>16)&0xFF) << 16) |
        (Mul((a>>8 )&0xFF,(b>>8 )&0xFF) << 8 ) |
        (Mul((a    )&0xFF,(b    )&0xFF));
}

static uint32_t Add(uint32_t a, uint32_t b) {
    uint8_t r = ((a>>24)&0xFF) + ((b>>24)&0xFF);
    uint8_t g = ((a>>16)&0xFF) + ((b>>16)&0xFF);
    uint8_t b2= ((a>>8 )&0xFF) + ((b>>8 )&0xFF);
    uint8_t a2= ((a    )&0xFF) + ((b    )&0xFF);
    return (r<<24)|(g<<16)|(b2<<8)|a2;
}

static uint32_t Sub(uint32_t a, uint32_t b) {
    uint8_t r = ((a>>24)&0xFF) - ((b>>24)&0xFF);
    uint8_t g = ((a>>16)&0xFF) - ((b>>16)&0xFF);
    uint8_t b2= ((a>>8 )&0xFF) - ((b>>8 )&0xFF);
    uint8_t a2= ((a    )&0xFF) - ((b    )&0xFF);
    return (r<<24)|(g<<16)|(b2<<8)|a2;
}

// ================= API =================

void Init() {
    Reset();
}

void Reset() {
    g_stageCount = 0;
    g_prevColor  = 0xFFFFFFFF;
}

void SetStage(int id, const Stage& s) {
    if (id < 0 || id >= 16) return;
    g_stages[id] = s;
    if (id >= g_stageCount)
        g_stageCount = id + 1;
}

void SetConstColor(uint32_t color) {
    g_constColor = color;
}

uint32_t Apply(uint32_t vertexColor, uint32_t textureColor) {

    g_prevColor = vertexColor;

    for (int i = 0; i < g_stageCount; i++) {

        const Stage& st = g_stages[i];

        uint32_t A = GetSource(st.a, vertexColor, textureColor);
        uint32_t B = GetSource(st.b, vertexColor, textureColor);
        uint32_t C = GetSource(st.c, vertexColor, textureColor);
        uint32_t D = GetSource(st.d, vertexColor, textureColor);

        uint32_t out = 0;

        switch (st.op) {
        case OP_MODULATE:
            out = Modulate(A, B);
            break;
        case OP_ADD:
            out = Add(A, B);
            break;
        case OP_SUB:
            out = Sub(A, B);
            break;
        case OP_REPLACE:
            out = A;
            break;
        }

        out = Add(out, D);
        g_prevColor = Clamp(out);
    }

    return g_prevColor;
}

}