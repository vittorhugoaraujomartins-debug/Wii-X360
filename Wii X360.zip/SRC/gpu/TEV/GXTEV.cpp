#include "GXTEV.h"

namespace GXTEV {

static Stage g_stages[MAX_TEV_STAGES];
static int   g_stageCount = 0;

static uint32_t g_constColor = 0xFFFFFFFF;
static uint32_t g_prevColor  = 0xFFFFFFFF;

// ================= UTIL =================

static inline uint8_t Clamp8(int v) {
    if (v < 0)   return 0;
    if (v > 255) return 255;
    return (uint8_t)v;
}

static inline uint8_t Mul(uint8_t a, uint8_t b) {
    return (uint8_t)((a * b) / 255);
}

static inline uint32_t MakeColor(int r, int g, int b, int a) {
    return (Clamp8(r) << 24) |
           (Clamp8(g) << 16) |
           (Clamp8(b) << 8 ) |
            Clamp8(a);
}

static inline uint32_t GetSource(
    ColorSource src,
    uint32_t vtx,
    uint32_t tex
) {
    switch (src) {
    case SRC_VERTEX:  return vtx;
    case SRC_TEXTURE: return tex;
    case SRC_PREV:    return g_prevColor;
    case SRC_CONST:   return g_constColor;
    default:          return 0;
    }
}

// ================= OPS =================

static uint32_t OpModulate(uint32_t a, uint32_t b) {
    return MakeColor(
        Mul((a>>24)&0xFF, (b>>24)&0xFF),
        Mul((a>>16)&0xFF, (b>>16)&0xFF),
        Mul((a>>8 )&0xFF, (b>>8 )&0xFF),
        Mul((a    )&0xFF, (b    )&0xFF)
    );
}

static uint32_t OpAdd(uint32_t a, uint32_t b) {
    return MakeColor(
        ((a>>24)&0xFF) + ((b>>24)&0xFF),
        ((a>>16)&0xFF) + ((b>>16)&0xFF),
        ((a>>8 )&0xFF) + ((b>>8 )&0xFF),
        ((a    )&0xFF) + ((b    )&0xFF)
    );
}

static uint32_t OpSub(uint32_t a, uint32_t b) {
    return MakeColor(
        ((a>>24)&0xFF) - ((b>>24)&0xFF),
        ((a>>16)&0xFF) - ((b>>16)&0xFF),
        ((a>>8 )&0xFF) - ((b>>8 )&0xFF),
        ((a    )&0xFF) - ((b    )&0xFF)
    );
}

// ================= API =================

void Init() {
    Reset();
}

void Reset() {
    g_stageCount = 0;
    g_prevColor  = 0xFFFFFFFF;
    g_constColor = 0xFFFFFFFF;
}

void SetStage(int id, const Stage& s) {
    if (id < 0 || id >= MAX_TEV_STAGES)
        return;

    g_stages[id] = s;
    if (id >= g_stageCount)
        g_stageCount = id + 1;
}

void SetConstColor(uint32_t color) {
    g_constColor = color;
}

uint32_t Apply(uint32_t vertexColor, uint32_t textureColor) {

    g_prevColor = vertexColor;

    for (int i = 0; i < g_stageCount; i++) {

        const Stage& st = g_stages[i];

        uint32_t A = GetSource(st.a, vertexColor, textureColor);
        uint32_t B = GetSource(st.b, vertexColor, textureColor);
        uint32_t D = GetSource(st.d, vertexColor, textureColor);

        uint32_t out = 0;

        switch (st.op) {
        case OP_REPLACE:
            out = A;
            break;
        case OP_MODULATE:
            out = OpModulate(A, B);
            break;
        case OP_ADD:
            out = OpAdd(A, B);
            break;
        case OP_SUB:
            out = OpSub(A, B);
            break;
        }

        g_prevColor = OpAdd(out, D);
    }

    return g_prevColor;
}

}