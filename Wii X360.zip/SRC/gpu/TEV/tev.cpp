#include "tev.h"

namespace GXTEV {

static inline uint8_t Mul(uint8_t a, uint8_t b) {
    return (uint8_t)((a * b) / 255);
}

static inline Color FromU32(uint32_t c) {
    return {
        (uint8_t)(c >> 24),
        (uint8_t)(c >> 16),
        (uint8_t)(c >> 8),
        (uint8_t)(c)
    };
}

static inline uint32_t ToU32(Color c) {
    return (c.r << 24) | (c.g << 16) | (c.b << 8) | c.a;
}

void Init() {}
void Reset() {}

// ==========================
// TEV STAGE 0
// vtx * texture
// ==========================
Color Stage0(Color vtx, Color tex) {
    Color out;
    out.r = Mul(vtx.r, tex.r);
    out.g = Mul(vtx.g, tex.g);
    out.b = Mul(vtx.b, tex.b);
    out.a = Mul(vtx.a, tex.a);
    return out;
}

// ==========================
// TEV STAGE 1
// prev * konst
// ==========================
Color Stage1(Color prev, Color konst) {
    Color out;
    out.r = Mul(prev.r, konst.r);
    out.g = Mul(prev.g, konst.g);
    out.b = Mul(prev.b, konst.b);
    out.a = Mul(prev.a, konst.a);
    return out;
}

// ==========================
// PIPELINE FINAL
// ==========================
uint32_t Shade(uint32_t vertexColor, uint32_t texColor) {

    Color vtx  = FromU32(vertexColor);
    Color tex  = FromU32(texColor);

    // Konst fixa por enquanto (branco)
    Color konst = { 255, 255, 255, 255 };

    Color c0 = Stage0(vtx, tex);
    Color c1 = Stage1(c0, konst);

    return ToU32(c1);
}

}