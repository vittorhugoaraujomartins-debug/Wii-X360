#pragma once
#include <stdint.h>

namespace VI {

void Init();
void Tick();      // chamado pelo scheduler
void SetVBlank();

}