#pragma once
#include <stdint.h>

namespace GXTEV {

struct Color {
    uint8_t r, g, b, a;
};

void Init();
void Reset();

// TEV 2 stages
Color Stage0(Color vtx, Color tex);
Color Stage1(Color prev, Color konst);

// Pipeline final
uint32_t Shade(uint32_t vertexColor, uint32_t texColor);

}