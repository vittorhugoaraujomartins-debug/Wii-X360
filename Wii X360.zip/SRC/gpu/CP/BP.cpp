#include "BP.h"
#include "XenosGPU.h"

BPState g_bp;

void BP_Reset() {
    g_bp = {};
}

void BP_Write(uint32_t reg, uint32_t value) {

    switch (reg) {

    case 0x40: // ZMODE
        g_bp.zEnable = (value & 1);
        g_bp.zWrite  = (value & 2);
        break;

    case 0x41: // BLENDMODE
        g_bp.blendEnable = (value & 1);
        break;

    case 0x42: // CULLMODE
        g_bp.cullMode = value & 3;
        break;
    }

    XenosGPU::ApplyBPState(g_bp);
}