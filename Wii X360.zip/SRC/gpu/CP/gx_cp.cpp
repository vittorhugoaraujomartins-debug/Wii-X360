#include "gx_cp.h"
#include "gx_draw.h"
#include "gx_vertex.h"

namespace GXCP {

static inline uint32_t Read32(uint8_t* f, uint32_t& rp)
{
    uint32_t v =
        (f[rp] << 24) |
        (f[rp+1] << 16) |
        (f[rp+2] << 8) |
        f[rp+3];
    rp += 4;
    return v;
}

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& rp)
{
    // LOAD CP REG
    if (cmd >= 0x10 && cmd <= 0x1F)
    {
        uint32_t val = Read32(fifo, rp);
        return;
    }

    // DRAW
    if (cmd >= 0x80 && cmd <= 0xBF)
    {
        int vcount = fifo[rp++];

        GXDraw::Begin(cmd);

        for (int i = 0; i < vcount; i++)
        {
            GXVertex v =
                GXVertexLoader::LoadVertex(fifo, rp);

            GXDraw::Submit(v);
        }

        GXDraw::Flush();
    }
}

}


GXCP::Execute


#include "gx_vertex.h"
#include "gx_xf.h"

GXVertex::Vertex v;

GXVertex::LoadVertex(fifo, rp, v);

GXXF::Transform(v);

// Agora envia para backend (Direct3D)
RenderBackend::SubmitVertex(v);



#include "gx_cp.h"
#include "gx_draw.h"
#include "gx_vertex_loader.h"
#include "gx_cp_state.h"

static inline uint32_t Read32(uint8_t* f, uint32_t& rp)
{
    uint32_t v =
        (f[rp] << 24) |
        (f[rp+1] << 16) |
        (f[rp+2] << 8) |
        f[rp+3];
    rp += 4;
    return v;
}

namespace GXCP
{

void WriteCPReg(uint8_t reg, uint32_t value)
{
    switch (reg)
    {
        case 0x50: g_cpState.vcdLo = value; break;
        case 0x60: g_cpState.vcdHi = value; break;

        // VAT A
        case 0x70: g_cpState.vatA[0] = value; break;
        case 0x71: g_cpState.vatA[1] = value; break;

        // Exemplo array base
        case 0xA0: g_cpState.arrayBase[0] = value; break;

        default:
            break;
    }
}

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& rp)
{
    // CP Register Write
    if (cmd >= 0x10 && cmd <= 0x7F)
    {
        uint32_t value = Read32(fifo, rp);
        WriteCPReg(cmd, value);
        return;
    }

    // DRAW
    if (cmd >= 0x80 && cmd <= 0xBF)
    {
        uint16_t vcount = (fifo[rp] << 8) | fifo[rp+1];
        rp += 2;

        GXDraw::Begin(cmd);

        for (uint16_t i = 0; i < vcount; i++)
        {
            GXVertex v;
            GXVertexLoader::LoadVertex(fifo, rp, v, g_cpState);
            GXDraw::Submit(v);
        }

        GXDraw::Flush();
    }
}

}


// gx_vertex_loader.cpp

void GXVertexLoader::LoadVertex(
    uint8_t* fifo,
    uint32_t& rp,
    GXVertex& out,
    const CPState& state)
{
    // Exemplo simples: posição indexada
    if (state.vcdLo & (1 << 0)) // posição ativa
    {
        uint16_t index = (fifo[rp] << 8) | fifo[rp+1];
        rp += 2;

        uint32_t addr =
            state.arrayBase[0] +
            index * state.arrayStride[0];

        // Aqui você buscaria da RAM real
        ReadPositionFromRAM(addr, out.position);
    }

    // Normal
    if (state.vcdLo & (1 << 1))
    {
        uint16_t index = (fifo[rp] << 8) | fifo[rp+1];
        rp += 2;

        uint32_t addr =
            state.arrayBase[1] +
            index * state.arrayStride[1];

        ReadNormalFromRAM(addr, out.normal);
    }

    // Depois aplicar XF
    GXXF::Transform(out);
}



#include <unordered_map>

static std::unordered_map<uint64_t, GXVertex> g_vertexCache;

uint64_t MakeVertexKey(uint16_t posIndex, uint16_t normalIndex)
{
    return ((uint64_t)posIndex << 32) | normalIndex;
}



uint64_t key = MakeVertexKey(posIndex, normalIndex);

auto it = g_vertexCache.find(key);
if (it != g_vertexCache.end())
{
    out = it->second;
    return;
}

// Se não existir:
GXXF::Transform(out);
g_vertexCache[key] = out;


