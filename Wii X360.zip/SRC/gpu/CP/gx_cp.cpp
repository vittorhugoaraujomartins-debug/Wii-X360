#include "gx_cp.h"
#include "gx_draw.h"

namespace GXCP {

static inline uint32_t Read32(uint8_t* f, uint32_t& rp) {
    uint32_t v =
        (f[rp] << 24) | (f[rp+1] << 16) |
        (f[rp+2] << 8) | f[rp+3];
    rp += 4;
    return v;
}

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& rp) {

    // GX_LOAD_CP_REG
    if (cmd >= 0x10 && cmd <= 0x1F) {
        uint32_t val = Read32(fifo, rp);
        // salvar registradores CP
        return;
    }

    // DRAW
    if (cmd >= 0x80 && cmd <= 0xBF) {
        GXDraw::Begin(cmd);
        return;
    }
}

}

if (cmd >= 0x80 && cmd <= 0xBF) {
    int vcount = fifo[rp++];
    for (int i = 0; i < vcount; i++) {
        GXVertex v = GXVertexLoader::LoadVertex(fifo, rp);
        GXDraw::Submit(v);
    }
    GXDraw::Flush();
}