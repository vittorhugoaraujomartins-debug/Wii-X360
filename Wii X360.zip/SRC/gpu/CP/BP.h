#pragma once
#include <stdint.h>

struct BPState {
    bool zEnable;
    bool zWrite;
    bool blendEnable;
    uint8_t cullMode;
};

extern BPState g_bp;

void BP_Reset();
void BP_Write(uint32_t reg, uint32_t value);