#pragma once
#include <stdint.h>

namespace GXCP {

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& rp);

}