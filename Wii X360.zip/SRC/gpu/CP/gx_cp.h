#pragma once
#include <stdint.h>

namespace GXCP {

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& rp);

}


// gx_cp_state.h
#pragma once
#include <cstdint>

struct CPState
{
    // Vertex Descriptor
    uint32_t vcdLo = 0;
    uint32_t vcdHi = 0;

    // Vertex Attribute Tables (8 grupos possíveis)
    uint32_t vatA[8]{};
    uint32_t vatB[8]{};
    uint32_t vatC[8]{};

    // Array bases (posição, normal, cor, texcoord etc.)
    uint32_t arrayBase[16]{};

    // Array strides
    uint8_t arrayStride[16]{};
};

extern CPState g_cpState;