#include "XenosGPU.h"
#include <cstring>

static IDirect3DDevice9* g_device = nullptr;
static IDirect3DVertexBuffer9* g_vb = nullptr;
static IDirect3DIndexBuffer9* g_ib = nullptr;
static IDirect3DTexture9* g_texture = nullptr;

static uint32_t g_stride = 0;

namespace XenosGPU {

void Init(IDirect3DDevice9* device) {
    g_device = device;
}

void Shutdown() {
    if (g_vb) g_vb->Release();
    if (g_ib) g_ib->Release();
    if (g_texture) g_texture->Release();

    g_vb = nullptr;
    g_ib = nullptr;
    g_texture = nullptr;
}

void BeginFrame() {
    if (!g_device) return;
    g_device->Clear(0, nullptr,
        D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        D3DCOLOR_XRGB(0,0,0), 1.0f, 0);
    g_device->BeginScene();
}

void EndFrame() {
    if (!g_device) return;
    g_device->EndScene();
    g_device->Present(nullptr, nullptr, nullptr, nullptr);
}

void ApplyGXState(const GX::GXState& s) {
    g_device->SetRenderState(D3DRS_ZENABLE, s.depthTest);
    g_device->SetRenderState(D3DRS_ALPHATESTENABLE, s.alphaTest);
    g_device->SetRenderState(
        D3DRS_CULLMODE,
        s.cullFace ? D3DCULL_CCW : D3DCULL_NONE
    );
}

void UploadVertexBuffer(const void* data, uint32_t size, uint32_t stride) {
    g_stride = stride;

    if (g_vb) g_vb->Release();
    g_device->CreateVertexBuffer(size, 0, 0, D3DPOOL_DEFAULT, &g_vb, nullptr);

    void* dst;
    g_vb->Lock(0, size, &dst, 0);
    memcpy(dst, data, size);
    g_vb->Unlock();

    g_device->SetStreamSource(0, g_vb, 0, stride);
}

void UploadIndexBuffer(const void* data, uint32_t size) {
    if (g_ib) g_ib->Release();
    g_device->CreateIndexBuffer(size, 0, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_ib, nullptr);

    void* dst;
    g_ib->Lock(0, size, &dst, 0);
    memcpy(dst, data, size);
    g_ib->Unlock();

    g_device->SetIndices(g_ib);
}

static D3DPRIMITIVETYPE Translate(GX::PrimitiveType p) {
    switch (p) {
        case GX::GX_POINTS: return D3DPT_POINTLIST;
        case GX::GX_LINES: return D3DPT_LINELIST;
        case GX::GX_TRIANGLE_STRIP: return D3DPT_TRIANGLESTRIP;
        default: return D3DPT_TRIANGLELIST;
    }
}

void Draw(GX::PrimitiveType prim, uint32_t vertexCount) {
    g_device->DrawPrimitive(Translate(prim), 0, vertexCount);
}

void DrawIndexed(GX::PrimitiveType prim, uint32_t vertexCount, uint32_t indexCount) {
    g_device->DrawIndexedPrimitive(
        Translate(prim),
        0,
        0,
        vertexCount,
        0,
        indexCount / 3
    );
}

void ExecuteGX(const std::vector<uint32_t>& fifo) {
    // Decoder GX → Xenos (base correta)
    for (uint32_t cmd : fifo) {
        (void)cmd;
    }
}

void UploadTexture2D(const void* data, uint32_t w, uint32_t h) {
    if (g_texture) g_texture->Release();

    g_device->CreateTexture(
        w, h, 1, 0,
        D3DFMT_A8R8G8B8,
        D3DPOOL_DEFAULT,
        &g_texture, nullptr
    );

    D3DLOCKED_RECT r;
    g_texture->LockRect(0, &r, nullptr, 0);
    memcpy(r.pBits, data, w * h * 4);
    g_texture->UnlockRect(0);
}

void BindTexture() {
    g_device->SetTexture(0, g_texture);
}

bool IsVisible(const float* min, const float* max) {
    return max[2] > 0.1f;
}

void DrawInstanced(GX::PrimitiveType prim, uint32_t count, uint32_t instances) {
    for (uint32_t i = 0; i < instances; i++)
        Draw(prim, count);
}

}


void GPU::Run() {
    // Executa comandos GX acumulados
    while (!GX::CommandQueue.empty()) {
        GXCommand cmd = GX::CommandQueue.front();
        GX::CommandQueue.pop();
        ExecuteGXCommand(cmd);
    }
}

void GPU::ExecuteGXCommand(const GXCommand& cmd) {
    switch (cmd.type) {

        case GXCommandType::DRAW:
            Video::Draw();
            break;

        case GXCommandType::CLEAR:
            Video::Clear();
            break;

        default:
            // Ignorar comandos não implementados
            break;
    }
}