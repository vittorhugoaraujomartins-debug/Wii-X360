#include "PixelShader.h"
#include <xtl.h>

static IDirect3DPixelShader9* g_pixelShader = nullptr;
static IDirect3DDevice9* g_device = nullptr;

// Pixel Shader básico:
// saída = cor interpolada
static const DWORD g_ps_microcode[] = {
    0xFFFF0200, // ps_2_0
    0x00000042, // mov oC0, v0
    0x00000000  // end
};

namespace PixelShader {

bool Init(IDirect3DDevice9* device) {
    g_device = device;
    if (!g_device)
        return false;

    HRESULT hr = g_device->CreatePixelShader(
        g_ps_microcode,
        &g_pixelShader
    );

    return SUCCEEDED(hr);
}

void Bind() {
    if (g_device && g_pixelShader) {
        g_device->SetPixelShader(g_pixelShader);
    }
}

void Unbind() {
    if (g_device) {
        g_device->SetPixelShader(nullptr);
    }
}

void Shutdown() {
    if (g_pixelShader) {
        g_pixelShader->Release();
        g_pixelShader = nullptr;
    }
    g_device = nullptr;
}

}