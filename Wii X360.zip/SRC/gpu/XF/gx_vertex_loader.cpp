#include "gx_vertex_loader.h"
#include "gx_vcd.h"

static inline uint8_t  Read8 (uint8_t* f, uint32_t& rp){ return f[rp++]; }
static inline uint16_t Read16(uint8_t* f, uint32_t& rp){
    uint16_t v = (f[rp] << 8) | f[rp+1]; rp += 2; return v;
}
static inline uint32_t Read32(uint8_t* f, uint32_t& rp){
    uint32_t v = (f[rp]<<24)|(f[rp+1]<<16)|(f[rp+2]<<8)|f[rp+3];
    rp += 4; return v;
}

GXVertex GXVertexLoader::LoadVertex(uint8_t* f, uint32_t& rp) {
    GXVertex v = {};

    if (g_vcd.pos == GX_DIRECT) {
        v.x = (int16_t)Read16(f,rp) / 256.0f;
        v.y = (int16_t)Read16(f,rp) / 256.0f;
        v.z = (int16_t)Read16(f,rp) / 256.0f;
    }

    if (g_vcd.color0 == GX_DIRECT) {
        v.color = Read32(f,rp);
    }

    if (g_vcd.tex0 == GX_DIRECT) {
        v.u = (int16_t)Read16(f,rp) / 256.0f;
        v.v = (int16_t)Read16(f,rp) / 256.0f;
    }

    return v;
}