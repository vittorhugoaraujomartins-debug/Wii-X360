#pragma once
#include <stdint.h>

namespace GXEFB {

struct Color {
    uint8_t r, g, b, a;
};

void Init(uint32_t w, uint32_t h);
void Clear(Color c, float depth);

void WritePixel(uint32_t x, uint32_t y, Color c, float z);

void CopyToXFB();

}