#pragma once
#include <stdint.h>

struct GXVertex {
    float x, y, z;
    float nx, ny, nz;
    uint32_t color;
    float u, v;
};

namespace GXVertexLoader {

GXVertex LoadVertex(uint8_t* fifo, uint32_t& rp);

}