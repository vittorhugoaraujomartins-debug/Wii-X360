#pragma once
#include <stdint.h>

enum GXAttrType {
    GX_NONE = 0,
    GX_DIRECT,
    GX_INDEX8,
    GX_INDEX16
};

struct GXVCD {
    GXAttrType pos;
    GXAttrType normal;
    GXAttrType color0;
    GXAttrType tex0;
};

extern GXVCD g_vcd;

void GXSetVCD(uint8_t attr, uint8_t type);