#include "efb.h"
#include <vector>
#include <string.h>
#include "XenosGPU.h"

namespace GXEFB {

static uint32_t width = 0;
static uint32_t height = 0;

static std::vector<Color> colorBuffer;
static std::vector<float> depthBuffer;

void Init(uint32_t w, uint32_t h) {
    width = w;
    height = h;

    colorBuffer.resize(w * h);
    depthBuffer.resize(w * h);
}

void Clear(Color c, float depth) {
    for (uint32_t i = 0; i < width * height; i++) {
        colorBuffer[i] = c;
        depthBuffer[i] = depth;
    }
}

void WritePixel(uint32_t x, uint32_t y, Color c, float z) {
    if (x >= width || y >= height)
        return;

    uint32_t idx = y * width + x;

    // Depth test
    if (z < depthBuffer[idx]) {
        depthBuffer[idx] = z;
        colorBuffer[idx] = c;
    }
}

void CopyToXFB() {
    // Envia framebuffer inteiro para GPU
    XenosGPU::Present(
        (void*)colorBuffer.data(),
        width,
        height
    );
}

}