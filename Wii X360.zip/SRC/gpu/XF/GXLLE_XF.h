#pragma once
#include <stdint.h>

namespace GXLLE_XF {

struct Vec4 {
    float x, y, z, w;
};

void Reset();
void SetProjection(const float* m);
void SetModelView(const float* m);

Vec4 Transform(const Vec4& v);

}