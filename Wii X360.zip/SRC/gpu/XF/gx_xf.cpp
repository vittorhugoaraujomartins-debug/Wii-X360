#include "GXLLE_XF.h"
#include <cstring>

namespace GXLLE_XF {

static float model[16];
static float proj[16];

void Reset()
{
    memset(model, 0, sizeof(model));
    memset(proj, 0, sizeof(proj));
}

void SetProjection(const float* m)
{
    memcpy(proj, m, 16 * sizeof(float));
}

void SetModelView(const float* m)
{
    memcpy(model, m, 16 * sizeof(float));
}

static Vec4 Mul(const float* m, const Vec4& v)
{
    Vec4 o;

    o.x = m[0]*v.x + m[4]*v.y + m[8]*v.z + m[12]*v.w;
    o.y = m[1]*v.x + m[5]*v.y + m[9]*v.z + m[13]*v.w;
    o.z = m[2]*v.x + m[6]*v.y + m[10]*v.z + m[14]*v.w;
    o.w = m[3]*v.x + m[7]*v.y + m[11]*v.z + m[15]*v.w;

    return o;
}

Vec4 Transform(const Vec4& v)
{
    Vec4 world = Mul(model, v);
    Vec4 clip  = Mul(proj, world);

    if (clip.w != 0.0f)
    {
        clip.x /= clip.w;
        clip.y /= clip.w;
        clip.z /= clip.w;
    }

    return clip;
}

}