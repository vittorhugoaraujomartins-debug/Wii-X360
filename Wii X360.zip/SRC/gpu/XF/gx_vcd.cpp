#include "gx_vcd.h"

GXVCD g_vcd = {};

void GXSetVCD(uint8_t attr, uint8_t type) {
    GXAttrType t = (GXAttrType)type;

    switch (attr) {
        case 0: g_vcd.pos    = t; break;
        case 1: g_vcd.normal = t; break;
        case 2: g_vcd.color0 = t; break;
        case 3: g_vcd.tex0   = t; break;
    }
}