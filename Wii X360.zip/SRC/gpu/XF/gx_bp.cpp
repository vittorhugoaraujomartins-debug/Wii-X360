#include "gx_bp.h"

GXBPState g_bp = {};

void GXWriteBP(uint8_t reg, uint32_t val) {

    switch (reg) {
        case 0x40: // Z MODE
            g_bp.zTest  = (val >> 0) & 1;
            g_bp.zWrite = (val >> 1) & 1;
            break;

        case 0x41: // BLEND
            g_bp.blend = val & 1;
            break;
    }
}