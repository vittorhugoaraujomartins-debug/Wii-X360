#pragma once
#include <stdint.h>

namespace GXXF {

struct XFState
{
    float posMtx[8][4][4];
    float projMtx[4][4];

    bool dirty;
};

void Init();
void Reset();
void Write(uint16_t addr, uint32_t val);
void UploadIfDirty();

}


namespace XF_HLE
{
    void Reset();
    void SetMatrix(const float* mtx);
    void SetProjection(const float* proj);
    void SetLighting(bool enable);
    void SetUI2DMode(bool enable);

    void Transform(GXVertex::Vertex& v);
}