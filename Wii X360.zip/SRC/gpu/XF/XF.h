#pragma once
#include <stdint.h>

struct XFState {
    float proj[16];
    float view[16];
};

extern XFState g_xf;

void XF_Reset();
void XF_Write(uint32_t reg, const float* data);