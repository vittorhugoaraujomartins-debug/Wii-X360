#pragma once
#include <stdint.h>

struct XFState {
    float proj[16];
    float view[16];
};

extern XFState g_xf;

void XF_Reset();
void XF_Write(uint32_t reg, const float* data);


#pragma once
#include <stdint.h>
#include <vector>

// ===============================
// XF – Transform Unit (Wii)
// ===============================

namespace GXXF {

struct Vec4 {
    float x, y, z, w;
};

struct XFState {
    float posMtx[8][3][4];   // 8 ModelView 3x4
    float projMtx[4][4];     // Projection
    float viewport[6];       // x, y, width, height, near, far
};

extern XFState g_xf;

// Lifecycle
void Init();
void Reset();

// GX interface
void Write(uint16_t addr, uint32_t val);

// Transform
Vec4 Transform(const Vec4& v, int mtxIndex);

// Viewport
void ApplyViewport(Vec4& v);

}