#include "XF.h"
#include <string.h>

XFState g_xf;

void XF_Reset() {
    memset(&g_xf, 0, sizeof(g_xf));
}

void XF_Write(uint32_t reg, const float* data) {

    if (reg == 0x100) { // Projection
        memcpy(g_xf.proj, data, 16 * sizeof(float));
    }

    if (reg == 0x200) { // View
        memcpy(g_xf.view, data, 16 * sizeof(float));
    }
}

#include "XF.h"
#include <string.h>

namespace GXXF {

XFState g_xf;

void Init() {
    Reset();
}

void Reset() {
    memset(&g_xf, 0, sizeof(g_xf));

    // viewport default (Wii-like)
    g_xf.viewport[0] = 0.0f;
    g_xf.viewport[1] = 0.0f;
    g_xf.viewport[2] = 640.0f;
    g_xf.viewport[3] = 480.0f;
    g_xf.viewport[4] = 0.0f;
    g_xf.viewport[5] = 1.0f;
}

void Write(uint16_t addr, uint32_t val) {
    float f = *(float*)&val;

    // ModelView matrices (0x000 – 0x0FF)
    if (addr < 0x100) {
        int mtx = addr / 12;
        int idx = addr % 12;
        if (mtx < 8) {
            g_xf.posMtx[mtx][idx / 4][idx % 4] = f;
        }
        return;
    }

    // Projection matrix (0x100 – 0x13F)
    if (addr >= 0x100 && addr < 0x140) {
        int i = (addr - 0x100) / 4;
        int j = (addr - 0x100) % 4;
        g_xf.projMtx[i][j] = f;
        return;
    }

    // Viewport (simplificado)
    if (addr >= 0x200 && addr < 0x206) {
        g_xf.viewport[addr - 0x200] = f;
    }
}

Vec4 Transform(const Vec4& v, int mtx) {
    Vec4 out;

    // ModelView
    float x =
        g_xf.posMtx[mtx][0][0]*v.x +
        g_xf.posMtx[mtx][0][1]*v.y +
        g_xf.posMtx[mtx][0][2]*v.z +
        g_xf.posMtx[mtx][0][3];

    float y =
        g_xf.posMtx[mtx][1][0]*v.x +
        g_xf.posMtx[mtx][1][1]*v.y +
        g_xf.posMtx[mtx][1][2]*v.z +
        g_xf.posMtx[mtx][1][3];

    float z =
        g_xf.posMtx[mtx][2][0]*v.x +
        g_xf.posMtx[mtx][2][1]*v.y +
        g_xf.posMtx[mtx][2][2]*v.z +
        g_xf.posMtx[mtx][2][3];

    // Projection
    out.w =
        g_xf.projMtx[3][0]*x +
        g_xf.projMtx[3][1]*y +
        g_xf.projMtx[3][2]*z +
        g_xf.projMtx[3][3];

    out.x =
        g_xf.projMtx[0][0]*x +
        g_xf.projMtx[0][1]*y +
        g_xf.projMtx[0][2]*z +
        g_xf.projMtx[0][3];

    out.y =
        g_xf.projMtx[1][0]*x +
        g_xf.projMtx[1][1]*y +
        g_xf.projMtx[1][2]*z +
        g_xf.projMtx[1][3];

    out.z =
        g_xf.projMtx[2][0]*x +
        g_xf.projMtx[2][1]*y +
        g_xf.projMtx[2][2]*z +
        g_xf.projMtx[2][3];

    // NDC
    if (out.w != 0.0f) {
        out.x /= out.w;
        out.y /= out.w;
        out.z /= out.w;
    }

    return out;
}

void ApplyViewport(Vec4& v) {
    v.x = g_xf.viewport[0] + (v.x + 1.0f) * g_xf.viewport[2] * 0.5f;
    v.y = g_xf.viewport[1] + (1.0f - v.y) * g_xf.viewport[3] * 0.5f;
    v.z = g_xf.viewport[4] + v.z * (g_xf.viewport[5] - g_xf.viewport[4]);
}

}