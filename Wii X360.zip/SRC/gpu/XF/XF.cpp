#include "XF.h"
#include <string.h>

XFState g_xf;

void XF_Reset() {
    memset(&g_xf, 0, sizeof(g_xf));
}

void XF_Write(uint32_t reg, const float* data) {

    if (reg == 0x100) { // Projection
        memcpy(g_xf.proj, data, 16 * sizeof(float));
    }

    if (reg == 0x200) { // View
        memcpy(g_xf.view, data, 16 * sizeof(float));
    }
}