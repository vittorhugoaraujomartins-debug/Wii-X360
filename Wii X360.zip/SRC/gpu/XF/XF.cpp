#include "XF_HLE.h"
#include <cstring>

namespace GXXF {

static XFState g_xf;

static bool gXFDirty = true;

void SetMatrix(const float* mtx)
{
    if (memcmp(gMatrix, mtx, sizeof(gMatrix)) != 0)
    {
        memcpy(gMatrix, mtx, sizeof(gMatrix));
        gIdentity = IsIdentity(mtx);
        gXFDirty = true;
    }
}

void SetProjection(const float* proj)
{
    memcpy(gProj, proj, sizeof(gProj));
    gXFDirty = true;
}

void SetLighting(bool enable)
{
    if (gLighting != enable)
    {
        gLighting = enable;
        gXFDirty = true;
    }
}



bool ShouldSkipXF()
{
    if (!gXFDirty && !EFBState::IsDirty())
        return true;

    return false;
}


if (XF_HLE::ShouldSkipXF())
{
    // já está tudo transformado
    return;
}






void Init() {
    Reset();
}

void Reset() {
    memset(&g_xf, 0, sizeof(g_xf));
    g_xf.dirty = true;
}

void Write(uint16_t addr, uint32_t val)
{
    float f = *(float*)&val;

    // Model matrices (0x000–0x0FF)
    if (addr < 0x100)
    {
        int mtx = addr / 12;
        int idx = addr % 12;

        if (mtx < 8)
        {
            g_xf.posMtx[mtx][idx / 4][idx % 4] = f;
            g_xf.dirty = true;
        }
        return;
    }

    // Projection (0x100–0x13F)
    if (addr >= 0x100 && addr < 0x140)
    {
        int i = (addr - 0x100) / 4;
        int j = (addr - 0x100) % 4;

        g_xf.projMtx[i][j] = f;
        g_xf.dirty = true;
    }
}

void UploadIfDirty()
{
    if (!g_xf.dirty)
        return;

    // Upload para GPU (exemplo D3D9/Xenos)
    g_d3d->SetVertexShaderConstantF(
        0,
        &g_xf.posMtx[0][0][0],
        32
    );

    g_d3d->SetVertexShaderConstantF(
        32,
        &g_xf.projMtx[0][0],
        4
    );

    g_xf.dirty = false;
}

}



float4x4 posMtx[8];
float4x4 projMtx;

struct VS_IN
{
    float4 pos : POSITION;
    float  mtxIndex : TEXCOORD0;
};

struct VS_OUT
{
    float4 pos : POSITION;
};

VS_OUT mainVS(VS_IN input)
{
    VS_OUT o;

    int idx = (int)input.mtxIndex;
    float4 world = mul(input.pos, posMtx[idx]);
    o.pos = mul(world, projMtx);

    return o;
}



#include "XF.h"
#include <cstring>
#include <cmath>

namespace XF_HLE
{

static float gMatrix[16];
static float gProj[16];
static bool gLighting = false;
static bool gUI2DMode = false;

static bool gIdentity = false;
static bool gMatrixDirty = true;

// ------------------------------------------------------------

static bool IsIdentity(const float* m)
{
    static const float id[16] =
    {
        1,0,0,0,
        0,1,0,0,
        0,0,1,0,
        0,0,0,1
    };

    return memcmp(m, id, sizeof(id)) == 0;
}

// ------------------------------------------------------------

void Reset()
{
    memset(gMatrix, 0, sizeof(gMatrix));
    memset(gProj, 0, sizeof(gProj));
    gLighting = false;
    gUI2DMode = false;
    gIdentity = false;
    gMatrixDirty = true;
}

// ------------------------------------------------------------

void SetMatrix(const float* mtx)
{
    if (memcmp(gMatrix, mtx, sizeof(gMatrix)) != 0)
    {
        memcpy(gMatrix, mtx, sizeof(gMatrix));
        gIdentity = IsIdentity(mtx);
        gMatrixDirty = true;
    }
}

// ------------------------------------------------------------

void SetProjection(const float* proj)
{
    memcpy(gProj, proj, sizeof(gProj));
}

// ------------------------------------------------------------

void SetLighting(bool enable)
{
    gLighting = enable;
}

// ------------------------------------------------------------

void SetUI2DMode(bool enable)
{
    gUI2DMode = enable;
}

// ------------------------------------------------------------

void Transform(GXVertex::Vertex& v)
{
    // ================================
    // FAST PATH 1 — UI 2D
    // ================================
    if (gUI2DMode)
    {
        // só projeta direto
        float x = v.pos.x;
        float y = v.pos.y;

        v.pos.x = x * gProj[0] + gProj[12];
        v.pos.y = y * gProj[5] + gProj[13];
        v.pos.z = 0.0f;

        return;
    }

    // ================================
    // FAST PATH 2 — Matriz identidade
    // ================================
    if (gIdentity)
    {
        // só aplica projeção
        float x = v.pos.x;
        float y = v.pos.y;
        float z = v.pos.z;

        v.pos.x =
            x * gProj[0] +
            y * gProj[4] +
            z * gProj[8] +
            gProj[12];

        v.pos.y =
            x * gProj[1] +
            y * gProj[5] +
            z * gProj[9] +
            gProj[13];

        v.pos.z =
            x * gProj[2] +
            y * gProj[6] +
            z * gProj[10] +
            gProj[14];

        return;
    }

    // ================================
    // NORMAL PATH (3D completo)
    // ================================

    float x = v.pos.x;
    float y = v.pos.y;
    float z = v.pos.z;

    // World transform
    float wx =
        x * gMatrix[0] +
        y * gMatrix[4] +
        z * gMatrix[8] +
        gMatrix[12];

    float wy =
        x * gMatrix[1] +
        y * gMatrix[5] +
        z * gMatrix[9] +
        gMatrix[13];

    float wz =
        x * gMatrix[2] +
        y * gMatrix[6] +
        z * gMatrix[10] +
        gMatrix[14];

    // Projection
    v.pos.x =
        wx * gProj[0] +
        wy * gProj[4] +
        wz * gProj[8] +
        gProj[12];

    v.pos.y =
        wx * gProj[1] +
        wy * gProj[5] +
        wz * gProj[9] +
        gProj[13];

    v.pos.z =
        wx * gProj[2] +
        wy * gProj[6] +
        wz * gProj[10] +
        gProj[14];

    // ================================
    // Lighting (apenas se necessário)
    // ================================
    if (gLighting)
    {
        // iluminação simplificada tipo Wii comum
        float lightDir[3] = { 0.0f, 0.0f, -1.0f };

        float dot =
            v.normal.x * lightDir[0] +
            v.normal.y * lightDir[1] +
            v.normal.z * lightDir[2];

        if (dot < 0) dot = 0;

        v.color.r *= dot;
        v.color.g *= dot;
        v.color.b *= dot;
    }
}

}



void TransformBatch(GXVertex::Vertex* v, int count)
{
    if (ShouldSkipXF())
        return;

    for (int i = 0; i < count; i += 4)
    {
        int batch = (i + 4 <= count) ? 4 : count - i;

        for (int j = 0; j < batch; j++)
        {
            GXVertex::Vertex& vert = v[i + j];

            float x = vert.pos.x;
            float y = vert.pos.y;
            float z = vert.pos.z;

            float wx =
                x * gMatrix[0] +
                y * gMatrix[4] +
                z * gMatrix[8] +
                gMatrix[12];

            float wy =
                x * gMatrix[1] +
                y * gMatrix[5] +
                z * gMatrix[9] +
                gMatrix[13];

            float wz =
                x * gMatrix[2] +
                y * gMatrix[6] +
                z * gMatrix[10] +
                gMatrix[14];

            vert.pos.x =
                wx * gProj[0] +
                wy * gProj[4] +
                wz * gProj[8] +
                gProj[12];

            vert.pos.y =
                wx * gProj[1] +
                wy * gProj[5] +
                wz * gProj[9] +
                gProj[13];

            vert.pos.z =
                wx * gProj[2] +
                wy * gProj[6] +
                wz * gProj[10] +
                gProj[14];
        }
    }

    gXFDirty = false;
    EFBState::ClearDirty();
}