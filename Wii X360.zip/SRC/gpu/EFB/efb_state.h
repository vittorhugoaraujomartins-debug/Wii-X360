#pragma once

namespace EFBState
{
    void MarkDirty();
    void ClearDirty();
    bool IsDirty();
}