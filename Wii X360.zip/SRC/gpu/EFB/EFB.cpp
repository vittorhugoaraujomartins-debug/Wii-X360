#include "EFB.h"
#include <cstring>

extern IDirect3DDevice9* g_d3d;

EFBState g_efbState;

// ------------------------------------------------------------
// Recursos D3D
// ------------------------------------------------------------

static IDirect3DTexture9*  g_colorTex   = nullptr;
static IDirect3DSurface9*  g_colorSurf  = nullptr;
static IDirect3DSurface9*  g_depthSurf  = nullptr;
static IDirect3DSurface9*  g_backBuffer = nullptr;

static IDirect3DTexture9*  g_depthTex   = nullptr; // opcional (shader depth read)
static IDirect3DTexture9*  g_lastCopyDst = nullptr;

// ------------------------------------------------------------
// INIT
// ------------------------------------------------------------

bool EFB::Init(uint32_t w, uint32_t h)
{
    g_efbState.width  = w;
    g_efbState.height = h;

    g_efbState.clearColorValue = 0x00000000;
    g_efbState.clearDepthValue = 1.0f;

    g_efbState.clearColor = false;
    g_efbState.clearDepth = false;

    g_efbState.dirtyColor = true;
    g_efbState.dirtyDepth = true;
    g_efbState.bound      = false;

    // Color RT
    if (FAILED(g_d3d->CreateTexture(
        w, h, 1,
        D3DUSAGE_RENDERTARGET,
        D3DFMT_A8R8G8B8,
        D3DPOOL_DEFAULT,
        &g_colorTex, nullptr)))
        return false;

    g_colorTex->GetSurfaceLevel(0, &g_colorSurf);

    // Depth Surface
    if (FAILED(g_d3d->CreateDepthStencilSurface(
        w, h,
        D3DFMT_D24S8,
        D3DMULTISAMPLE_NONE,
        0, TRUE,
        &g_depthSurf, nullptr)))
        return false;

    g_d3d->GetRenderTarget(0, &g_backBuffer);

    return true;
}

// ------------------------------------------------------------
// BEGIN
// ------------------------------------------------------------

void EFB::Begin()
{
    // Verifica RT atual (seguro contra troca externa)
    IDirect3DSurface9* currentRT = nullptr;
    g_d3d->GetRenderTarget(0, &currentRT);

    if (currentRT != g_colorSurf)
    {
        g_d3d->SetRenderTarget(0, g_colorSurf);
        g_d3d->SetDepthStencilSurface(g_depthSurf);
        g_efbState.bound = true;
    }

    if (currentRT)
        currentRT->Release();

    // Clear (lazy)
    DWORD flags = 0;

    if (g_efbState.clearColor)
        flags |= D3DCLEAR_TARGET;

    if (g_efbState.clearDepth)
        flags |= D3DCLEAR_ZBUFFER;

    if (flags)
    {
        g_d3d->Clear(
            0, nullptr,
            flags,
            g_efbState.clearColorValue,
            g_efbState.clearDepthValue,
            0);

        if (g_efbState.clearColor)
            g_efbState.dirtyColor = true;

        if (g_efbState.clearDepth)
            g_efbState.dirtyDepth = true;
    }

    g_efbState.clearColor = false;
    g_efbState.clearDepth = false;

    // Viewport fixo
    static D3DVIEWPORT9 lastVP = {};
    D3DVIEWPORT9 vp;

    vp.X = 0;
    vp.Y = 0;
    vp.Width  = g_efbState.width;
    vp.Height = g_efbState.height;
    vp.MinZ = 0.0f;
    vp.MaxZ = 1.0f;

    if (memcmp(&vp, &lastVP, sizeof(vp)) != 0)
    {
        g_d3d->SetViewport(&vp);
        lastVP = vp;
    }
}

// ------------------------------------------------------------
// END
// ------------------------------------------------------------

void EFB::End()
{
    if (!g_efbState.bound)
        return;

    g_d3d->SetRenderTarget(0, g_backBuffer);
    g_efbState.bound = false;
}

// ------------------------------------------------------------
// CLEAR (lazy flag)
// ------------------------------------------------------------

void EFB::Clear(bool clrColor, bool clrDepth)
{
    g_efbState.clearColor |= clrColor;
    g_efbState.clearDepth |= clrDepth;
}

// ------------------------------------------------------------
// DRAW NOTIFY
// ------------------------------------------------------------

void EFB::OnDrawCall(bool writesDepth)
{
    g_efbState.dirtyColor = true;

    if (writesDepth)
        g_efbState.dirtyDepth = true;
}

// ------------------------------------------------------------
// COPY TO TEXTURE (COLOR)
// ------------------------------------------------------------

void EFB::CopyToTexture(IDirect3DTexture9* dst)
{
    if (!dst)
        return;

    // Skip se nada mudou
    if (!g_efbState.dirtyColor && g_lastCopyDst == dst)
        return;

    IDirect3DSurface9* dstSurf = nullptr;
    dst->GetSurfaceLevel(0, &dstSurf);

    g_d3d->StretchRect(
        g_colorSurf,
        nullptr,
        dstSurf,
        nullptr,
        D3DTEXF_NONE);

    dstSurf->Release();

    g_efbState.dirtyColor = false;
    g_lastCopyDst = dst;
}

// ------------------------------------------------------------
// COPY DEPTH (opcional)
// ------------------------------------------------------------

void EFB::CopyDepthToTexture(IDirect3DTexture9* dst)
{
    if (!dst || !g_efbState.dirtyDepth)
        return;

    IDirect3DSurface9* dstSurf = nullptr;
    dst->GetSurfaceLevel(0, &dstSurf);

    g_d3d->StretchRect(
        g_depthSurf,
        nullptr,
        dstSurf,
        nullptr,
        D3DTEXF_NONE);

    dstSurf->Release();

    g_efbState.dirtyDepth = false;
}

// ------------------------------------------------------------
// CPU SIDE COPY (fallback)
// ------------------------------------------------------------

void CopyEFBToTextureCPU(uint8_t* src, uint8_t* dst,
                         int width, int height, int stride)
{
    int rowBytes = width * 4;

    for (int y = 0; y < height; y++)
    {
        uint8_t* s = src + y * stride;
        uint8_t* d = dst + y * stride;

        memcpy(d, s, rowBytes);
    }
}
