#include "EFB.h"

static IDirect3DTexture9* g_efbColor = NULL;
static IDirect3DSurface9* g_efbSurface = NULL;
static IDirect3DSurface9* g_depthSurface = NULL;

static IDirect3DSurface9* g_backBuffer = NULL;
static IDirect3DSurface9* g_oldDepth = NULL;

static int g_width  = 640;
static int g_height = 528;

extern IDirect3DDevice9* g_d3d; // seu device global

namespace EFB {

bool Init(int width, int height) {
    g_width  = width;
    g_height = height;

    // Color buffer
    if (FAILED(g_d3d->CreateTexture(
        g_width,
        g_height,
        1,
        D3DUSAGE_RENDERTARGET,
        D3DFMT_A8R8G8B8,
        D3DPOOL_DEFAULT,
        &g_efbColor,
        NULL)))
        return false;

    g_efbColor->GetSurfaceLevel(0, &g_efbSurface);

    // Depth buffer
    if (FAILED(g_d3d->CreateDepthStencilSurface(
        g_width,
        g_height,
        D3DFMT_D24S8,
        D3DMULTISAMPLE_NONE,
        0,
        TRUE,
        &g_depthSurface,
        NULL)))
        return false;

    // Backbuffer
    g_d3d->GetRenderTarget(0, &g_backBuffer);

    return true;
}

void Begin() {
    g_d3d->GetDepthStencilSurface(&g_oldDepth);

    g_d3d->SetRenderTarget(0, g_efbSurface);
    g_d3d->SetDepthStencilSurface(g_depthSurface);

    g_d3d->Clear(
        0,
        NULL,
        D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        0x00000000,
        1.0f,
        0);
}

void End() {
    g_d3d->SetRenderTarget(0, g_backBuffer);
    g_d3d->SetDepthStencilSurface(g_oldDepth);
}

void Present() {
    // Copia EFB → BackBuffer
    g_d3d->StretchRect(
        g_efbSurface,
        NULL,
        g_backBuffer,
        NULL,
        D3DTEXF_NONE);
}

IDirect3DTexture9* GetColorTexture() {
    return g_efbColor;
}

}

#include "EFB.h"
#include <string.h>

static uint32_t* colorBuf = NULL;
static uint32_t* depthBuf = NULL;
static uint32_t width, height;

namespace EFB {

void Init(uint32_t w, uint32_t h) {
    width = w;
    height = h;
    colorBuf = new uint32_t[w * h];
    depthBuf = new uint32_t[w * h];
}

void Clear(uint32_t color, uint32_t depth) {
    for (uint32_t i = 0; i < width * height; i++) {
        colorBuf[i] = color;
        depthBuf[i] = depth;
    }
}

void WritePixel(int x, int y, uint32_t color, uint32_t depth) {
    int idx = y * width + x;
    if (depth <= depthBuf[idx]) {
        depthBuf[idx] = depth;
        colorBuf[idx] = color;
    }
}

uint32_t ReadPixel(int x, int y) {
    return colorBuf[y * width + x];
}

void CopyToXFB() {
    // aqui você envia colorBuf para Xenos (DX9 surface)
}

}


#include "EFB.h"
#include <string.h>

namespace GX {

EFBState gEFB;

void EFB_Init(uint32_t w, uint32_t h) {
    gEFB.width  = w;
    gEFB.height = h;
    gEFB.colorBuffer = new uint32_t[w * h];
    EFB_Clear(0x000000FF);
}

void EFB_Clear(uint32_t color) {
    for (uint32_t i = 0; i < gEFB.width * gEFB.height; i++)
        gEFB.colorBuffer[i] = color;
}

void EFB_CopyToXFB(uint32_t* xfb) {
    memcpy(xfb, gEFB.colorBuffer,
           gEFB.width * gEFB.height * 4);
}

}