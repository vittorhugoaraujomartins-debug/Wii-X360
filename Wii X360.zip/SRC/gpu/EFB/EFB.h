#pragma once
#include <d3d9.h>
#include <cstdint>

struct EFBState
{
    uint32_t width;
    uint32_t height;

    bool clearColor = false;
    bool clearDepth = false;

    uint32_t clearColorValue;
    float clearDepthValue;

    bool dirty = true;
    bool bound = false;


    RenderTarget* colorRT;
    RenderTarget* depthRT;

    uint32_t width;
    uint32_t height;

    uint64_t stateHash;

    bool dirtyColor;
    bool dirtyDepth;
};


namespace EFB
{
    bool Init(uint32_t w, uint32_t h);
    void Begin();
    void End();
    void Clear(bool clrColor, bool clrDepth);
    void CopyToTexture(IDirect3DTexture9* dst);
    bool IsDirty();
}