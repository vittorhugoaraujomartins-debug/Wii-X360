#include "efb.h"
#include <string.h>

namespace EFB {

static uint32_t* buffer = NULL;
static uint32_t width  = 0;
static uint32_t height = 0;

void Init(uint32_t w, uint32_t h) {
    width = w;
    height = h;
    buffer = new uint32_t[w * h];
    Clear(0x000000FF);
}

void Clear(uint32_t color) {
    for (uint32_t i = 0; i < width * height; i++)
        buffer[i] = color;
}

void WritePixel(int x, int y, uint32_t color) {
    if (x < 0 || y < 0 || x >= (int)width || y >= (int)height)
        return;

    buffer[y * width + x] = color;
}

// ==========================
// EFB → XFB
// ==========================
void CopyToXFB(uint32_t* xfb) {
    memcpy(xfb, buffer, width * height * sizeof(uint32_t));
}

}