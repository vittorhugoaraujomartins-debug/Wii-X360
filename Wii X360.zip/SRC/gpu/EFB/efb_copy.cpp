void CopyEFBToTexture(uint8_t* src, uint8_t* dst,
                      int width, int height, int stride)
{
    for (int y = 0; y < height; y++)
    {
        memcpy(dst + y * stride,
               src + y * stride,
               width * 4); // RGBA
    }

    // TODO: aplicar gamma correction real
}