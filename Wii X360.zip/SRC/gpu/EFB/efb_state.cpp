#include "efb_state.h"

namespace EFBState
{

static bool gDirty = true;

void MarkDirty()
{
    gDirty = true;
}

void ClearDirty()
{
    gDirty = false;
}

bool IsDirty()
{
    return gDirty;
}

}