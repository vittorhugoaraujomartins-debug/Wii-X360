#pragma once
#include <stdint.h>

namespace EFB {

void Init(uint32_t w, uint32_t h);
void Clear(uint32_t color);

void WritePixel(int x, int y, uint32_t color);

// Copia EFB → XFB
void CopyToXFB(uint32_t* xfb);

}