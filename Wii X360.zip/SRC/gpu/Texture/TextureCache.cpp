#include "TextureCache.h"
#include <xgraphics.h>
#include <cstring>

static std::unordered_map<uint64_t, CachedTexture> g_cache;

static uint64_t MakeKey(const GXTextureDesc& d) {
    return ((uint64_t)d.addr << 32) |
           (d.width << 16) |
           (d.height);
}

namespace TextureCache {

void Init() {
    g_cache.clear();
}

void Shutdown() {
    g_cache.clear();
}

void* GetTexture(const GXTextureDesc& desc) {

    uint64_t key = MakeKey(desc);
    auto it = g_cache.find(key);
    if (it != g_cache.end())
        return it->second.gpuTexture;

    // Criar textura nova
    IDirect3DDevice9* dev = XGraphicsGetDevice();
    IDirect3DTexture9* tex = nullptr;

    dev->CreateTexture(
        desc.width,
        desc.height,
        1,
        0,
        D3DFMT_A8R8G8B8,
        D3DPOOL_MANAGED,
        &tex,
        nullptr
    );

    // Upload fake por enquanto (MMU → textura depois)
    D3DLOCKED_RECT r;
    tex->LockRect(0, &r, nullptr, 0);
    memset(r.pBits, 0xFF, desc.width * desc.height * 4);
    tex->UnlockRect(0);

    g_cache[key] = { desc, tex };
    return tex;
}

void Invalidate(uint32_t addr, uint32_t size) {
    for (auto it = g_cache.begin(); it != g_cache.end(); ) {
        uint32_t taddr = it->second.desc.addr;
        if (taddr >= addr && taddr < addr + size)
            it = g_cache.erase(it);
        else
            ++it;
    }
}

}