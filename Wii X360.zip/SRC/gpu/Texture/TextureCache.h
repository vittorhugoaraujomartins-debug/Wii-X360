#pragma once
#include <stdint.h>
#include <unordered_map>

struct GXTextureDesc {
    uint32_t addr;
    uint16_t width;
    uint16_t height;
    uint8_t  format;
};

struct CachedTexture {
    GXTextureDesc desc;
    void* gpuTexture; // IDirect3DTexture9*
};

namespace TextureCache {

void Init();
void Shutdown();

void* GetTexture(const GXTextureDesc& desc);
void Invalidate(uint32_t addr, uint32_t size);

}