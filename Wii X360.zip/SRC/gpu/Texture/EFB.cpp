#include "EFB.h"

static IDirect3DTexture9* g_efbColor = nullptr;
static IDirect3DSurface9* g_efbSurface = nullptr;
static IDirect3DSurface9* g_depthSurface = nullptr;

static IDirect3DSurface9* g_backBuffer = nullptr;
static IDirect3DSurface9* g_oldDepth = nullptr;

static int g_width  = 640;
static int g_height = 528;

extern IDirect3DDevice9* g_d3d; // seu device global

namespace EFB {

bool Init(int width, int height) {
    g_width  = width;
    g_height = height;

    // Color buffer
    if (FAILED(g_d3d->CreateTexture(
        g_width,
        g_height,
        1,
        D3DUSAGE_RENDERTARGET,
        D3DFMT_A8R8G8B8,
        D3DPOOL_DEFAULT,
        &g_efbColor,
        nullptr)))
        return false;

    g_efbColor->GetSurfaceLevel(0, &g_efbSurface);

    // Depth buffer
    if (FAILED(g_d3d->CreateDepthStencilSurface(
        g_width,
        g_height,
        D3DFMT_D24S8,
        D3DMULTISAMPLE_NONE,
        0,
        TRUE,
        &g_depthSurface,
        nullptr)))
        return false;

    // Backbuffer
    g_d3d->GetRenderTarget(0, &g_backBuffer);

    return true;
}

void Begin() {
    g_d3d->GetDepthStencilSurface(&g_oldDepth);

    g_d3d->SetRenderTarget(0, g_efbSurface);
    g_d3d->SetDepthStencilSurface(g_depthSurface);

    g_d3d->Clear(
        0,
        nullptr,
        D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        0x00000000,
        1.0f,
        0);
}

void End() {
    g_d3d->SetRenderTarget(0, g_backBuffer);
    g_d3d->SetDepthStencilSurface(g_oldDepth);
}

void Present() {
    // Copia EFB → BackBuffer
    g_d3d->StretchRect(
        g_efbSurface,
        nullptr,
        g_backBuffer,
        nullptr,
        D3DTEXF_NONE);
}

IDirect3DTexture9* GetColorTexture() {
    return g_efbColor;
}

}