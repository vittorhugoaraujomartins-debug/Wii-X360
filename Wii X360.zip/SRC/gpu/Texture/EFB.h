#pragma once

#include <xtl.h>
#include <xgraphics.h>

namespace EFB {

bool Init(int width, int height);
void Begin();
void End();
void Present();

IDirect3DTexture9* GetColorTexture();

}

#pragma once
#include <stdint.h>

namespace EFB {

void Init(uint32_t w, uint32_t h);
void Clear(uint32_t color, uint32_t depth);

void WritePixel(int x, int y, uint32_t color, uint32_t depth);
uint32_t ReadPixel(int x, int y);

void CopyToXFB();

}