#pragma once

#include <xtl.h>
#include <xgraphics.h>

namespace EFB {

bool Init(int width, int height);
void Begin();
void End();
void Present();

IDirect3DTexture9* GetColorTexture();

}