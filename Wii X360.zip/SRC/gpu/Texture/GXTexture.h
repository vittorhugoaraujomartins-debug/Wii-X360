#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct GXTexture {
    uint32_t width;
    uint32_t height;
    uint32_t* data;
};

extern GXTexture g_activeTexture;