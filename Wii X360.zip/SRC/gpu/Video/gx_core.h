#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace GX {

// Primitivos básicos
enum PrimitiveType {
    GX_POINTS,
    GX_LINES,
    GX_TRIANGLES,
    GX_TRIANGLE_STRIP
};

// Estado simplificado
struct GXState {
    bool depthTest;
    bool alphaTest;
    bool cullFace;
};

// Vida útil
void Init();
void Shutdown();

// Estado
void SetState(const GXState& state);

// Immediate mode (base Wii)
void Begin(PrimitiveType prim);
void Position3f(float x, float y, float z);
void Color4f(float r, float g, float b, float a);
void End();

// Sincronização
void Flush();

}