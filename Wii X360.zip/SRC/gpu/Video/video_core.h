#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct IDirect3DDevice9;

namespace Video {

// Inicialização do vídeo (recebe device do XDK)
bool Init(IDirect3DDevice9* device);

// Finaliza tudo
void Shutdown();

// Frame
void BeginFrame();
void EndFrame();

// Limpa framebuffer
void Clear(uint32_t color = 0x000000);

// Draw genérico (HLE)
void Draw();

// Apresenta imagem
void Present();

}