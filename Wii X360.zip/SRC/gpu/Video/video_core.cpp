#include "video_core.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):

static IDirect3DDevice9* g_device = NULL;

namespace Video {

bool Init(IDirect3DDevice9* device) {
    g_device = device;
    return g_device != NULL;
}

void Shutdown() {
    g_device = NULL;
}

void BeginFrame() {
    if (!g_device) return;

    g_device->Clear(
        0, NULL,
        D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
        D3DCOLOR_XRGB(0, 0, 0),
        1.0f, 0
    );
    g_device->BeginScene();
}

void EndFrame() {
    if (!g_device) return;
    g_device->EndScene();
}

void Clear(uint32_t color) {
    if (!g_device) return;

    g_device->Clear(
        0, NULL,
        D3DCLEAR_TARGET,
        color,
        1.0f, 0
    );
}

void Draw() {
    // HLE: GX / FIFO vai chamar isso
    // backend real fica no XenosGPU
}

void Present() {
    if (!g_device) return;
    g_device->Present(NULL, NULL, NULL, NULL);
}

}