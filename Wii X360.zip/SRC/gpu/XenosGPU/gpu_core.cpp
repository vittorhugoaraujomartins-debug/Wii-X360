#include "gpu_core.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


namespace GPU {

void Init() {
    GXFIFO::Init();
    g_gx.Reset();
    RendererDX9::Init();
}

void Step(uint32_t cycles) {
    while (GXFIFO::HasCommand()) {
        uint8_t cmd = GXFIFO::Read8();

        switch (cmd) {
        case 0x61: { // BP command
            uint8_t reg = GXFIFO::Read8();
            uint32_t val =
                (GXFIFO::Read8() << 16) |
                (GXFIFO::Read8() << 8) |
                GXFIFO::Read8();

            g_gx.bp[reg] = val;
            RendererDX9::OnBPWrite(reg, val);
            break;
        }

        default:
            // comandos não implementados ainda
            break;
        }
    }
}

}