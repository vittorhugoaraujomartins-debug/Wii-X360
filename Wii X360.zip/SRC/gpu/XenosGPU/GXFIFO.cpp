#include "GXFIFO.h"
#include "XenosGPU.h"

namespace GXFIFO {

FIFO g_fifo;

void FIFO::Init(uint32_t sizeBytes) {
    buffer.clear();
    buffer.reserve(sizeBytes / 4);
    read_ptr = 0;
}

void FIFO::WriteU32(uint32_t v) {
    buffer.push_back(v);
}

bool FIFO::HasData(uint32_t count) const {
    return (read_ptr + count) <= buffer.size();
}

uint32_t FIFO::Read32() {
    return HasData(1) ? buffer[read_ptr++] : 0;
}

void FIFO::Execute() {
    read_ptr = 0;

    while (HasData(1)) {
        uint32_t cmd = Read32();

        switch (cmd) {

        case GX_CMD_LOAD_CP:
            XenosGPU::ApplyGXState(
                *reinterpret_cast<GX::GXState*>(Read32())
            );
            break;

        case GX_CMD_DRAW: {
            auto prim  = (GX::PrimitiveType)Read32();
            auto count = Read32();
            XenosGPU::Draw(prim, count);
            break;
        }

        default:
            break;
        }
    }
}

} // namespace GXFIFO