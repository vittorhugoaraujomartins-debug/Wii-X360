#pragma once
#include <cstdint>

namespace GPU {
    void Init();
    void Step(uint32_t cycles);
}