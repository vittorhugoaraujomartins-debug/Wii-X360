#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace GPU {
    void Init();
    void Step(uint32_t cycles);
}