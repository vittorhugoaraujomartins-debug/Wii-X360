#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

struct GXTEVStage {
    bool enableTexture;
};

extern GXTEVStage g_tevStage;