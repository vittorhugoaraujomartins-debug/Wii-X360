#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct GXTEVStage {
    bool enableTexture;
};

extern GXTEVStage g_tevStage;