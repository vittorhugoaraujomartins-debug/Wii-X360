#pragma once
#include <cstdint>

struct GXTEVStage {
    bool enableTexture;
};

extern GXTEVStage g_tevStage;