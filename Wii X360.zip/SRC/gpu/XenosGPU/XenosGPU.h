#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "GX.h"
#include "GXVertex.h"

#pragma once

struct GXVertex;

namespace XenosGPU {

    void Init();
    void Shutdown();

    void DrawTriangle(const GXVertex* vtx);
}

#pragma once

namespace XenosGPU {

    void Init();
    void Draw(const std::vector<GXVertex>& vtx);
}

#pragma once

namespace XenosGPU {
    void DrawIndexed(uint8_t prim, const std::vector<GXVertex>& vtx);
}

#pragma once

namespace XenosGPU {

void Init();
void Shutdown();

void Begin();
void PushVertex(float x, float y, float z, uint32_t color);
void End();

}