#pragma once
#include <xtl.h>

struct GXVertex;

namespace XenosGPU {

    void Init();
    void Shutdown();

    void DrawTriangle(const GXVertex* vtx);
}

#pragma once
#include <vector>
#include "GX.h"

namespace XenosGPU {

    void Init();
    void Draw(const std::vector<GXVertex>& vtx);
}

#pragma once
#include <vector>
#include "gx_vertex.h"

namespace XenosGPU {
    void DrawIndexed(uint8_t prim, const std::vector<GXVertex>& vtx);
}

#pragma once
#include <cstdint>

namespace XenosGPU {

void Init();
void Shutdown();

void Begin();
void PushVertex(float x, float y, float z, uint32_t color);
void End();

}