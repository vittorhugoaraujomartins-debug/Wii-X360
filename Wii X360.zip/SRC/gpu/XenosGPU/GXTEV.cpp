#include "GXTEV.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


GXTEVStage g_tevStage = {
    true // usa textura
};