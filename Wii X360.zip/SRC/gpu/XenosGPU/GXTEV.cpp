#include "GXTEV.h"

GXTEVStage g_tevStage = {
    true // usa textura
};