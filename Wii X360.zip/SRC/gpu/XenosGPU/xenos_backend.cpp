#include "xenos_backend.h"
void XenosBackend::Init(){}
void XenosBackend::ApplyState(const GXState&){ }
void XenosBackend::Draw(){}
