#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):
void XenosBackend::Init(){}
void XenosBackend::ApplyState(const GXState&){ }
void XenosBackend::Draw(){}