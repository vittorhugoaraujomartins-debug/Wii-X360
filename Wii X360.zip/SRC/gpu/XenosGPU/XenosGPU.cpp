#include "XenosGPU.h"
#include "GXTEV.h"
#include "GXTexture.h"
#include <xgraphics.h>
#include <vector>
#include <cstring>

static IDirect3DDevice9* g_device = nullptr;
static IDirect3DVertexBuffer9* g_vb = nullptr;
static uint32_t g_stride = 0;

// ================= INIT / SHUTDOWN =================

void XenosGPU::Init() {
    g_device = XGraphicsGetDevice();
}

void XenosGPU::Init(IDirect3DDevice9* device) {
    g_device = device;
}

void XenosGPU::Shutdown() {
    if (g_vb) {
        g_vb->Release();
        g_vb = nullptr;
    }
    g_device = nullptr;
}

// ================= GX STATE =================

void XenosGPU::ApplyGXState(const GX::GXState& s) {
    if (!g_device) return;

    g_device->SetRenderState(D3DRS_ZENABLE, s.depthTest);
    g_device->SetRenderState(
        D3DRS_CULLMODE,
        s.cullFace ? D3DCULL_CCW : D3DCULL_NONE
    );
}

// ================= VERTEX BUFFER =================

void XenosGPU::UploadVertexBuffer(
    const void* data,
    uint32_t size,
    uint32_t stride
) {
    if (!g_device) return;

    g_stride = stride;

    if (g_vb) g_vb->Release();

    g_device->CreateVertexBuffer(
        size, 0, 0,
        D3DPOOL_DEFAULT,
        &g_vb,
        nullptr
    );

    void* dst = nullptr;
    g_vb->Lock(0, size, &dst, 0);
    memcpy(dst, data, size);
    g_vb->Unlock();

    g_device->SetStreamSource(0, g_vb, 0, stride);
}

// ================= DRAW (VB) =================

void XenosGPU::Draw(GX::PrimitiveType prim, uint32_t count) {
    if (!g_device) return;

    g_device->DrawPrimitive(
        D3DPT_TRIANGLELIST,
        0,
        count
    );
}

// ================= IMMEDIATE DRAW =================

struct XVertex {
    float x, y, z;
    DWORD color;
};

static DWORD PackColor(const GXColor& c) {
    return D3DCOLOR_COLORVALUE(c.r, c.g, c.b, c.a);
}

// --- Draw 1 triangle ---
void XenosGPU::DrawTriangle(const GXVertex* gx) {
    if (!g_device) return;

    XVertex v[3] = {
        { gx[0].x, gx[0].y, gx[0].z, 0xFFFF0000 },
        { gx[1].x, gx[1].y, gx[1].z, 0xFF00FF00 },
        { gx[2].x, gx[2].y, gx[2].z, 0xFF0000FF },
    };

    g_device->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);
    g_device->DrawPrimitiveUP(
        D3DPT_TRIANGLELIST,
        1,
        v,
        sizeof(XVertex)
    );
}

// --- Draw vector ---
void XenosGPU::Draw(const std::vector<GXVertex>& vtx) {
    if (!g_device || vtx.empty()) return;

    std::vector<XVertex> out(vtx.size());

    for (size_t i = 0; i < vtx.size(); i++) {
        out[i] = {
            vtx[i].x,
            vtx[i].y,
            vtx[i].z,
            PackColor(vtx[i].color)
        };
    }

    g_device->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);
    g_device->DrawPrimitiveUP(
        D3DPT_TRIANGLELIST,
        out.size() / 3,
        out.data(),
        sizeof(XVertex)
    );
}

// ================= TEV PASS =================

void XenosGPU::Draw() {
    if (!g_device) return;

    if (g_tevStage.enableTexture) {
        SetTexture(
            0,
            g_activeTexture.data,
            g_activeTexture.width,
            g_activeTexture.height
        );
    }

    DrawPrimitive();
}

#include "XenosGPU.h"
#include <xgraphics.h>

void XenosGPU::DrawIndexed(uint8_t prim, const std::vector<GXVertex>& vtx) {

    if (vtx.empty()) return;

    IDirect3DDevice9* dev = XGraphicsGetDevice();
    if (!dev) return;

    dev->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1);

    switch (prim) {
    case 0x90: // GX_TRIANGLES
        dev->DrawPrimitiveUP(
            D3DPT_TRIANGLELIST,
            vtx.size() / 3,
            vtx.data(),
            sizeof(GXVertex)
        );
        break;

    default:
        // outros primitivos depois
        break;
    }
}