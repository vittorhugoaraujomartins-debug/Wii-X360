#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

#include "XenosGPU.h"
#include "GXTEV.h"
#include "GXTexture.h"

#include <cstring>   // memcpy

// FIXME: include not found in project (left original below):

struct Vtx {
    float x, y, z;
    uint32_t color;
};

static IDirect3DDevice9* g_dev = nullptr;
static std::vector<Vtx> g_vertices;

void XenosGPU::Init() {
    g_dev = XGraphicsGetDevice();
}

void XenosGPU::Shutdown() {
    g_vertices.clear();
}

void XenosGPU::Begin() {
    g_vertices.clear();
}

void XenosGPU::PushVertex(float x, float y, float z, uint32_t color) {
    g_vertices.push_back({x, y, z, color});

const auto& vcd = GXVCD::GetState();

if (vcd.pos.type == GX_DIRECT) {
    // lê x,y,z
}

if (vcd.color.type == GX_DIRECT) {
    // lê cor
}

if (vcd.tex0.type != GX_NONE) {
    // lê UV
}

}

void XenosGPU::End() {
    if (!g_dev || g_vertices.empty()) return;

    g_dev->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);
    g_dev->DrawPrimitiveUP(
        D3DPT_TRIANGLELIST,
        g_vertices.size() / 3,
        g_vertices.data(),
        sizeof(Vtx)
    );
}