#pragma once
#include <cstdint>

namespace GPU {

void Init();
void Reset();
void Step();              // Consome FIFO
void WriteFIFO(uint32_t); // CPU escreve comandos GX

}