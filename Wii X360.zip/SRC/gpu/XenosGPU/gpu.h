#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

namespace GPU {

void Init();
void Reset();
void Step();              // Consome FIFO
void WriteFIFO(uint32_t); // CPU escreve comandos GX

}