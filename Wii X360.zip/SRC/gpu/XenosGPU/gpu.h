#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace GPU {

void Init();
void Reset();
void Step();              // Consome FIFO
void WriteFIFO(uint32_t); // CPU escreve comandos GX

}