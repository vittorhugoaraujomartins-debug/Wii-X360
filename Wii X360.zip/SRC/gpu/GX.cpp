#include "GX.h"
#include <cstring>

namespace GX {

static GXState g_state;
static PrimitiveType g_currentPrim;

static std::vector<float> g_vertexBuffer;
// layout: x y z r g b a
static constexpr uint32_t FLOATS_PER_VERTEX = 7;

// ================= Init / Shutdown =================

void Init() {
    memset(&g_state, 0, sizeof(GXState));
    g_currentPrim = GX_TRIANGLES;
    g_vertexBuffer.clear();
    XenosGPU::Init();
}

void Shutdown() {
    XenosGPU::Shutdown();
    g_vertexBuffer.clear();
}

// ================= State =================

void SetState(const GXState& state) {
    g_state = state;
    XenosGPU::ApplyGXState(state);
}

// ================= Immediate Mode =================

void Begin(PrimitiveType prim) {
    g_currentPrim = prim;
    g_vertexBuffer.clear();
}

void Position3f(float x, float y, float z) {
    g_vertexBuffer.push_back(x);
    g_vertexBuffer.push_back(y);
    g_vertexBuffer.push_back(z);
}

void Color4f(float r, float g, float b, float a) {
    g_vertexBuffer.push_back(r);
    g_vertexBuffer.push_back(g);
    g_vertexBuffer.push_back(b);
    g_vertexBuffer.push_back(a);
}

void End() {
    if (g_vertexBuffer.empty())
        return;

    const uint32_t vertexCount =
        static_cast<uint32_t>(g_vertexBuffer.size() / FLOATS_PER_VERTEX);

    XenosGPU::UploadVertexBuffer(
        g_vertexBuffer.data(),
        vertexCount * FLOATS_PER_VERTEX * sizeof(float),
        FLOATS_PER_VERTEX * sizeof(float)
    );

    XenosGPU::DrawPrimitive(g_currentPrim, vertexCount);

    g_vertexBuffer.clear();
}

// ================= Utils =================

void Flush() {
    // futuro: FIFO real
}

void Draw(PrimitiveType prim, uint32_t count) {
    XenosGPU::DrawPrimitive(prim, count);
}

void DrawIndexed(PrimitiveType prim, uint32_t count, uint32_t indexCount) {
    XenosGPU::DrawPrimitiveIndexed(prim, count, indexCount);
}

void LoadTexture(const void* data, uint32_t w, uint32_t h) {
    XenosGPU::UploadTexture2D(data, w, h);
}

} // namespace GX

#include "GX.h"

namespace GX {
    std::queue<GXCommand> CommandQueue;
}
