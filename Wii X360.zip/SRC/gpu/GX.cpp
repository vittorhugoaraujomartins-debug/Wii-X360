#include "GX.h"
#include "GXFIFO.h"
#include <cstring>

namespace GX {

static GXState g_state;
static PrimitiveType g_currentPrim;

static std::vector<float> g_vertexBuffer;
static constexpr uint32_t FLOATS_PER_VERTEX = 7;

void Init() {
    memset(&g_state, 0, sizeof(GXState));
    g_currentPrim = GX_TRIANGLES;
    g_vertexBuffer.clear();
}

void Shutdown() {
    g_vertexBuffer.clear();
}

void SetState(const GXState& state) {
    g_state = state;

    GXFIFO::g_fifo.WriteU32(GX_CMD_LOAD_CP);
    GXFIFO::g_fifo.WriteU32(reinterpret_cast<uint32_t>(&g_state));
}

void Begin(PrimitiveType prim) {
    g_currentPrim = prim;
    g_vertexBuffer.clear();
}

void Position3f(float x, float y, float z) {
    g_vertexBuffer.push_back(x);
    g_vertexBuffer.push_back(y);
    g_vertexBuffer.push_back(z);
}

void Color4f(float r, float g, float b, float a) {
    g_vertexBuffer.push_back(r);
    g_vertexBuffer.push_back(g);
    g_vertexBuffer.push_back(b);
    g_vertexBuffer.push_back(a);
}

void End() {
    if (g_vertexBuffer.empty())
        return;

    GXFIFO::g_fifo.WriteU32(GX_CMD_DRAW);
    GXFIFO::g_fifo.WriteU32(static_cast<uint32_t>(g_currentPrim));
    GXFIFO::g_fifo.WriteU32(
        g_vertexBuffer.size() / FLOATS_PER_VERTEX
    );

    XenosGPU::UploadVertexBuffer(
        g_vertexBuffer.data(),
        g_vertexBuffer.size() * sizeof(float),
        FLOATS_PER_VERTEX * sizeof(float)
    );

    g_vertexBuffer.clear();
}

void Flush() {
    InstrOrder::IOBarrier();
    GXFIFO::g_fifo.Execute();
}

} // namespace GX