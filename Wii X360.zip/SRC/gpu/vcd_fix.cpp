
#include "gpu.h"
void GPU::LoadVertex(const uint8_t* s){
    readPos(s);
    if(vcd.color) readColor(s);
    if(vcd.tex) readTex(s);
}
