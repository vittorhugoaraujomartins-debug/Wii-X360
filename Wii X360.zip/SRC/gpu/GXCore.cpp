#include "CP/cp.h"
#include "BP/bp.h"
#include "XF/xf.h"
#include "gpu_hle/GXTranslator.h"

void GXCore_Init()
{
}

void GXCore_Process()
{
    while (CP_HasCommands())
    {
        CP_Command cmd = CP_Next();

        CP_Process(cmd);

        if (cmd.type == CP_DRAW)
        {
            GXHLE_DrawFromCP();
        }

        if (cmd.type == CP_CLEAR)
        {
            GXHLE_ClearFromBP();
        }
    }
}