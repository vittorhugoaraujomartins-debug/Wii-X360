
#include "gpu.h"
void GPU::CopyEFBtoXFB(int w,int h,int stride){
    for(int y=0;y<h;y++)
        memcpy(XFB+y*stride, EFB+y*w*4, w*4);
}
