#pragma once
#include <cstdint>

namespace GXFIFO {
    void Init();
    void Write8(uint8_t v);
    void Write16(uint16_t v);
    void Write32(uint32_t v);

    bool HasCommand();
    uint8_t Read8();
}