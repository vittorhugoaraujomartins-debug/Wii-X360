#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

struct GXState {
    uint32_t bp[256]; // registers BP
    uint32_t xf[256]; // transform
    uint32_t cp[256]; // command processor

    void Reset();
};

extern GXState g_gx;

#pragma once
#include <cstdint>

struct GXVertex {
    float x, y, z;
    float u, v;
    uint32_t color;
};

struct GXState {
    // Matrizes XF
    float modelView[16];
    float projection[16];

    // TEV mínimo
    bool useTexture;
    uint32_t tevColor;

    // Vertex buffer
    GXVertex vertexBuffer[4096];
    uint32_t vertexCount;
};

extern GXState gGX;