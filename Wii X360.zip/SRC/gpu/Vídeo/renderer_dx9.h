#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

namespace RendererDX9 {
    void Init();
    void OnBPWrite(uint8_t reg, uint32_t value);
    void Draw();
}