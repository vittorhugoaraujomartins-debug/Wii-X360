#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace RendererDX9 {
    void Init();
    void OnBPWrite(uint8_t reg, uint32_t value);
    void Draw();
}