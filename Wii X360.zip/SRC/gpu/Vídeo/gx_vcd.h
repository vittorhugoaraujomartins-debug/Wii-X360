#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

enum GXAttrType {
    GX_NONE    = 0,
    GX_DIRECT  = 1,
    GX_INDEX8  = 2,
    GX_INDEX16 = 3
};

struct GXVCD {
    GXAttrType pos;
    GXAttrType color0;
    GXAttrType tex0;
};

void GX_SetVCD(uint32_t value);

extern GXVCD g_vcd;