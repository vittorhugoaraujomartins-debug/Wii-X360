#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include "gx_state.h"
#include <cstring>

GXState g_gx;

void GXState::Reset() {
    memset(this, 0, sizeof(GXState));
}