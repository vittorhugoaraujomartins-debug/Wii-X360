#include "gx_state.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


GXState g_gx;

void GXState::Reset() {
    memset(this, 0, sizeof(GXState));
}