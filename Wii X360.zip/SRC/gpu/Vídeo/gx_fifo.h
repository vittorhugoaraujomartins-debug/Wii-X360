#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

namespace GXFIFO {
    void Init();
    void Write8(uint8_t v);
    void Write16(uint16_t v);
    void Write32(uint32_t v);

    bool HasCommand();
    uint8_t Read8();
}


#pragma once
#include <cstdint>
#include <vector>

namespace GX {

class FIFO {
public:
    void Init(uint32_t size);
    void Reset();

    void Write32(uint32_t v);
    bool Read32(uint32_t& out);

    bool HasData() const;

private:
    std::vector<uint32_t> buffer;
    uint32_t readPos = 0;
    uint32_t writePos = 0;
};

extern FIFO g_fifo;

}


#pragma once
#include <cstdint>

namespace GXFIFO {

void Write8(uint8_t v);
void Write16(uint16_t v);
void Write32(uint32_t v);

void Execute();
}

#pragma once
#include <cstdint>
// FIXME: include not found in project (left original below):
#include <queue>

namespace GXFIFO {

void Reset();
void Push(uint32_t v);
bool HasData();
uint32_t Pop();
void Execute(uint32_t cmd);

}