#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include "renderer_dx9.h"

namespace RendererDX9 {

void Init() {
    // Inicializar device DX9
}

void OnBPWrite(uint8_t reg, uint32_t value) {
    // Traduz BP → estado DX9
}

void Draw() {
    // DrawPrimitive
}

}