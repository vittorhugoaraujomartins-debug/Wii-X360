#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


GXVCD g_vcd = {
    GX_NONE,
    GX_NONE,
    GX_NONE
};

void GX_SetVCD(uint32_t value) {
    g_vcd.pos    = (GXAttrType)((value >> 0) & 0x3);
    g_vcd.color0 = (GXAttrType)((value >> 2) & 0x3);
    g_vcd.tex0   = (GXAttrType)((value >> 4) & 0x3);
}