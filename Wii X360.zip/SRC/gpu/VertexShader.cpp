#include "VertexShader.h"
#include <xtl.h>

// =======================
// Vertex Shader básico
// =======================
//
// Entrada:
// POSITION0 → posição
// COLOR0    → cor
// TEXCOORD0 → UV
//
// Saída direta (sem transformação ainda)

static IDirect3DVertexShader9* g_vs = nullptr;
static IDirect3DDevice9* g_device = nullptr;

// Código HLSL (bytecode inline simplificado)
// OBS: no X360 normalmente isso é pré-compilado,
// mas para base de emulador isso é aceitável.
static const char* g_vs_source =
"struct VS_IN {                      \n"
"  float4 pos : POSITION0;           \n"
"  float4 col : COLOR0;              \n"
"  float2 uv  : TEXCOORD0;           \n"
"};                                  \n"
"struct VS_OUT {                     \n"
"  float4 pos : POSITION0;           \n"
"  float4 col : COLOR0;              \n"
"  float2 uv  : TEXCOORD0;           \n"
"};                                  \n"
"VS_OUT main(VS_IN v) {               \n"
"  VS_OUT o;                          \n"
"  o.pos = v.pos;                    \n"
"  o.col = v.col;                    \n"
"  o.uv  = v.uv;                     \n"
"  return o;                         \n"
"}";

namespace VertexShader {

bool Init(IDirect3DDevice9* device) {
    g_device = device;
    if (!g_device)
        return false;

    HRESULT hr = g_device->CreateVertexShader(
        (const DWORD*)g_vs_source,
        &g_vs
    );

    if (FAILED(hr)) {
        g_vs = nullptr;
        return false;
    }

    return true;
}

void Bind() {
    if (g_device && g_vs)
        g_device->SetVertexShader(g_vs);
}

void Unbind() {
    if (g_device)
        g_device->SetVertexShader(nullptr);
}

void Shutdown() {
    if (g_vs) {
        g_vs->Release();
        g_vs = nullptr;
    }
}

}
