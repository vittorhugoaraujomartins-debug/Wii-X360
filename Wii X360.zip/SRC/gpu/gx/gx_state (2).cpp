#include "gx_state.h"
GXState gGXState={};
