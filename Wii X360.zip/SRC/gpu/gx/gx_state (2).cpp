#include "gx_state (2).h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

GXState gGXState={};