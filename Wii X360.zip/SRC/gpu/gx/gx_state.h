#pragma once
#include <cstdint>

struct GXState {
    uint32_t bp[256]; // registers BP
    uint32_t xf[256]; // transform
    uint32_t cp[256]; // command processor

    void Reset();
};

extern GXState g_gx;