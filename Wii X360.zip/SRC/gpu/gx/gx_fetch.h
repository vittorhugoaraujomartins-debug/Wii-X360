#pragma once
#include <cstdint>
#include "gx_vertex.h"
#include "gx_vcd.h"

uint32_t GX_ReadIndex(const uint8_t*& fifo, GXAttrType type);
GXVertex GX_FetchVertex(const uint8_t*& fifo);