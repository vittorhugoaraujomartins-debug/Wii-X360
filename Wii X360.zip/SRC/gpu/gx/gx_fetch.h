#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>
#include "gx_vertex.h"
#include "gx_vcd.h"

uint32_t GX_ReadIndex(const uint8_t*& fifo, GXAttrType type);
GXVertex GX_FetchVertex(const uint8_t*& fifo);