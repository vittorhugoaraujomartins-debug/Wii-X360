#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

uint32_t GX_ReadIndex(const uint8_t*& fifo, GXAttrType type);
GXVertex GX_FetchVertex(const uint8_t*& fifo);