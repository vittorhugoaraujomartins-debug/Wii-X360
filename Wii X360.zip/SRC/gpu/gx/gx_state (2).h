#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <stdint.h>
struct GXState{uint32_t vertexFormat;uint32_t textureState;uint32_t shaderKey;bool dirty;};extern GXState gGXState;
