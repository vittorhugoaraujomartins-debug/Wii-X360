#include "gx_tev.h"

namespace GXTEV {

void Init() {}

static inline uint8_t Mul(uint8_t a, uint8_t b) {
    return (uint8_t)((a * b) / 255);
}

uint32_t Shade(uint32_t vc, uint32_t tc) {
    uint8_t vr = (vc >> 24) & 0xFF;
    uint8_t vg = (vc >> 16) & 0xFF;
    uint8_t vb = (vc >> 8)  & 0xFF;
    uint8_t va = vc & 0xFF;

    uint8_t tr = (tc >> 24) & 0xFF;
    uint8_t tg = (tc >> 16) & 0xFF;
    uint8_t tb = (tc >> 8)  & 0xFF;
    uint8_t ta = tc & 0xFF;

    return (Mul(vr,tr) << 24) |
           (Mul(vg,tg) << 16) |
           (Mul(vb,tb) << 8)  |
           (Mul(va,ta));
}

}