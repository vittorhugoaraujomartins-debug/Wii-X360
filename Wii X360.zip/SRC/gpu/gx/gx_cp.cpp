#include "gx_cp.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


namespace GX {

void CP_Init() {
    // nada ainda
}

void CP_Process() {
    while (g_fifo.HasData()) {
        uint32_t word;
        if (!g_fifo.Read32(word))
            return;

        uint8_t cmd = word >> 24;

        switch (cmd) {

        case CMD_NOP:
            break;

        case CMD_DRAW: {
            uint16_t vtxCount = word & 0xFFFF;
            VTX::Draw(vtxCount);
            break;
        }

        case CMD_LOAD_XF: {
            uint16_t addr = (word >> 8) & 0xFFFF;
            uint16_t count = word & 0xFF;
            XF::Load(addr, count);
            break;
        }

        default:
            // comando desconhecido (ignora)
            break;
        }
    }
}




}


#include "gx_cp.h"
#include "XenosGPU.h"
#include "GXVTX.h"
#include "GXXF.h"

namespace GXCP {

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& rp) {

    switch (cmd) {

    // GX_BEGIN
    case 0x10: {
        uint16_t prim = (fifo[rp] << 8) | fifo[rp + 1];
        rp += 2;
        GXVTX::Begin(prim);
        break;
    }

    // Vertex data (simplificado)
    case 0x20: {
        float x = *(float*)&fifo[rp]; rp += 4;
        float y = *(float*)&fifo[rp]; rp += 4;
        float z = *(float*)&fifo[rp]; rp += 4;
        uint32_t color = *(uint32_t*)&fifo[rp]; rp += 4;
        GXVTX::Vertex(x, y, z, color);
        break;
    }

    // Load XF matrix
    case 0x30: {
        GXXF::LoadMatrix(&fifo[rp]);
        rp += 64;
        break;
    }

    // GX_END
    case 0x40:
        GXVTX::End();
        break;

    default:
        // opcode desconhecido → ignora
        break;
    }
}

}