#include "gx_cp.h"
#include "gx_fifo.h"
#include "gx_vtx.h"
#include "gx_xf.h"

namespace GX {

void CP_Init() {
    // nada ainda
}

void CP_Process() {
    while (g_fifo.HasData()) {
        uint32_t word;
        if (!g_fifo.Read32(word))
            return;

        uint8_t cmd = word >> 24;

        switch (cmd) {

        case CMD_NOP:
            break;

        case CMD_DRAW: {
            uint16_t vtxCount = word & 0xFFFF;
            VTX::Draw(vtxCount);
            break;
        }

        case CMD_LOAD_XF: {
            uint16_t addr = (word >> 8) & 0xFFFF;
            uint16_t count = word & 0xFF;
            XF::Load(addr, count);
            break;
        }

        default:
            // comando desconhecido (ignora)
            break;
        }
    }
}

}