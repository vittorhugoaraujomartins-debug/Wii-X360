#pragma once
#include <cstdint>

namespace GXGPU {

void Init();
void ExecuteCommand(uint8_t cmd, uint8_t* data);
void Draw();
}