#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace GXGPU {

void Init();
void ExecuteCommand(uint8_t cmd, uint8_t* data);
void Draw();
}