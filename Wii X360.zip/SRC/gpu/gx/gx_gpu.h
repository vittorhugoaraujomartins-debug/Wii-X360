#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

namespace GXGPU {

void Init();
void ExecuteCommand(uint8_t cmd, uint8_t* data);
void Draw();
}