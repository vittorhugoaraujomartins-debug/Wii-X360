#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>



#pragma once

enum GXCompType { GX_F32=0, GX_U8=1, GX_S16=2 };

struct GXVAT {
    GXCompType posType;
    GXCompType colorType;
    GXCompType texType;
};

extern GXVAT g_vat;
void GX_SetVAT(uint32_t value);