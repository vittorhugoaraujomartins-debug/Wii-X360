#pragma once
#include <cstdint>

namespace GX::VTX {

struct Vertex {
    float x, y, z;
    float u, v;
    uint32_t color;
};

void Draw(uint16_t count);

}

#pragma once
#include <cstdint>

struct GXVertex {
    float x, y, z;
    uint32_t color;
};

namespace GXVTX {

void Reset();
void Begin(uint32_t prim);
void Vertex(uint32_t data);
void End();

}