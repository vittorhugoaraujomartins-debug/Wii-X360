#pragma once
#include <cstdint>

namespace GX::VTX {

struct Vertex {
    float x, y, z;
    float u, v;
    uint32_t color;
};

void Draw(uint16_t count);

}