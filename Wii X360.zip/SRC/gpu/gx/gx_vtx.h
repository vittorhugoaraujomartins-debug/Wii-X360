#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace GX::VTX {

struct Vertex {
    float x, y, z;
    float u, v;
    uint32_t color;
};

void Draw(uint16_t count);

}

#pragma once

struct GXVertex {
    float x, y, z;
    uint32_t color;
};

namespace GXVTX {

void Reset();
void Begin(uint32_t prim);
void Vertex(uint32_t data);
void End();

}