#include "gx_vtx.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


namespace GX::VTX {

void Draw(uint16_t count) {
    for (uint16_t i = 0; i < count; i++) {
        uint32_t raw;
        GX::g_fifo.Read32(raw);

        // Stub: só consome dados
        // Depois: descriptors reais
    }
}

}


// FIXME: include not found in project (left original below):

static void MulMatVec(const float* m, float& x, float& y, float& z) {

    float tx =
        m[0] * x + m[4] * y + m[8]  * z + m[12];
    float ty =
        m[1] * x + m[5] * y + m[9]  * z + m[13];
    float tz =
        m[2] * x + m[6] * y + m[10] * z + m[14];

    x = tx; y = ty; z = tz;
}

void GX_TransformVertices() {

    for (uint32_t i = 0; i < gGX.vertexCount; i++) {
        GXVertex& v = gGX.vertexBuffer[i];
        MulMatVec(gGX.modelView, v.x, v.y, v.z);
    }
}



static std::vector<GXVertex> vertices;
static bool drawing = false;

namespace GXVTX {

void Reset() {
    vertices.clear();
    drawing = false;
}

void Begin(uint32_t) {
    vertices.clear();
    drawing = true;
}

void Vertex(uint32_t data) {
    if (!drawing) return;

    GXVertex v{};
    v.x = (float)((data >> 16) & 0xFF) / 128.0f;
    v.y = (float)((data >> 8) & 0xFF) / 128.0f;
    v.z = 0.0f;
    v.color = 0xFFFFFFFF;
    vertices.push_back(v);
}

void End() {
    drawing = false;
    GXXF::Draw(vertices);
}

}