#include "gx_vtx.h"
#include "gx_fifo.h"

namespace GX::VTX {

void Draw(uint16_t count) {
    for (uint16_t i = 0; i < count; i++) {
        uint32_t raw;
        GX::g_fifo.Read32(raw);

        // Stub: só consome dados
        // Depois: descriptors reais
    }
}

}