#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace GX {

enum GXCommand : uint8_t {
    CMD_NOP        = 0x00,
    CMD_DRAW       = 0xA0,
    CMD_LOAD_XF    = 0x10,
    CMD_LOAD_CP    = 0x08
};

void CP_Init();
void CP_Process();

}

#pragma once
#include <stdint.h>

namespace GXCP {

void Execute(uint8_t cmd, uint8_t* fifo, uint32_t& readPtr);

}