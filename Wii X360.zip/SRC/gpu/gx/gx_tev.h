#pragma once
#include <cstdint>

namespace GXTEV {

void Init();
uint32_t Shade(uint32_t vertexColor, uint32_t texColor);

}