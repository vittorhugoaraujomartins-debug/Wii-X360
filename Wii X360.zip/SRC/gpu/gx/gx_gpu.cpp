#include "gx_gpu.h"
#include "gx_state.h"

GXState gGX;

namespace GXGPU {

void Init() {
    gGX.vertexCount = 0;
    gGX.useTexture = false;
    gGX.tevColor = 0xFFFFFFFF;
}

void ExecuteCommand(uint8_t cmd, uint8_t* data) {

    switch (cmd) {

    // Load matrix (XF)
    case 0x10:
        memcpy(gGX.modelView, data, sizeof(float) * 16);
        break;

    // Begin draw
    case 0x20:
        gGX.vertexCount = 0;
        break;

    // Vertex
    case 0x30: {
        GXVertex& v = gGX.vertexBuffer[gGX.vertexCount++];
        memcpy(&v, data, sizeof(GXVertex));
        break;
    }

    // End draw
    case 0x40:
        Draw();
        break;
    }
}

}