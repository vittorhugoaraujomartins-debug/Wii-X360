#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include "gx_vertex_arrays.h"

GXVertexArrays g_vertexArrays = {
    nullptr,
    nullptr,
    nullptr
};