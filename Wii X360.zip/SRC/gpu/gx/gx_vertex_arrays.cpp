#include "gx_vertex_arrays.h"

GXVertexArrays g_vertexArrays = {
    nullptr,
    nullptr,
    nullptr
};