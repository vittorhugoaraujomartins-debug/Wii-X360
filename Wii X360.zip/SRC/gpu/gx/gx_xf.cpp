#include "gx_xf.h"

static XFState g_xf;

namespace {

inline void MulMV(const float* m, float* v) {
    float x = v[0], y = v[1], z = v[2];

    v[0] = m[0] * x + m[1] * y + m[2] * z + m[3];
    v[1] = m[4] * x + m[5] * y + m[6] * z + m[7];
    v[2] = m[8] * x + m[9] * y + m[10]* z + m[11];
}

inline void MulProj(const float* m, float* v) {
    float x = v[0], y = v[1], z = v[2];

    float w = m[12]*x + m[13]*y + m[14]*z + m[15];
    float nx = m[0]*x + m[1]*y + m[2]*z + m[3];
    float ny = m[4]*x + m[5]*y + m[6]*z + m[7];
    float nz = m[8]*x + m[9]*y + m[10]*z + m[11];

    if (w != 0.0f) {
        v[0] = nx / w;
        v[1] = ny / w;
        v[2] = nz / w;
    }
}

}

namespace GXXF {

void Init() {
    for (int i = 0; i < 12; i++) g_xf.modelView[i] = 0.0f;
    for (int i = 0; i < 16; i++) g_xf.projection[i] = 0.0f;
}

void LoadModelView(const float* mtx) {
    for (int i = 0; i < 12; i++)
        g_xf.modelView[i] = mtx[i];
}

void LoadProjection(const float* mtx) {
    for (int i = 0; i < 16; i++)
        g_xf.projection[i] = mtx[i];
}

void Transform(float* pos) {
    MulMV(g_xf.modelView, pos);
    MulProj(g_xf.projection, pos);
}

}


#include "gx_xf.h"
#include "gx_fifo.h"

namespace GX::XF {

static float regs[256];

void Load(uint16_t addr, uint16_t count) {
    for (uint16_t i = 0; i < count; i++) {
        uint32_t raw;
        if (!GX::g_fifo.Read32(raw))
            break;

        regs[addr + i] = *(float*)&raw;
    }
}

}


#include "gx_xf.h"
#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>

static float mvp[16];

namespace GXXF {

void Reset() {
    for (int i = 0; i < 16; i++)
        mvp[i] = (i % 5 == 0) ? 1.0f : 0.0f;
}

void LoadMatrix(uint32_t) {
    // placeholder (hardcoded identity)
}

void Draw(const std::vector<GXVertex>& vtx) {
    if (vtx.size() < 3) return;

    // aqui você liga com o backend DX9
    // DrawPrimitiveUP TRIANGLELIST
}

}