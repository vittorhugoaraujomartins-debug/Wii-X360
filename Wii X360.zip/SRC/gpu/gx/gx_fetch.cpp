#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


uint32_t GX_ReadIndex(const uint8_t*& fifo, GXAttrType type) {
    if (type == GX_INDEX8) {
        return *fifo++;
    }
    if (type == GX_INDEX16) {
        uint16_t v = (fifo[0] << 8) | fifo[1];
        fifo += 2;
        return v;
    }
    return 0;
}

GXVertex GX_FetchVertex(const uint8_t*& fifo) {
    GXVertex v{};

    // POSITION
    if (g_vcd.pos == GX_DIRECT) {
        memcpy(&v.x, fifo, 12);
        fifo += 12;
    } else {
        uint32_t idx = GX_ReadIndex(fifo, g_vcd.pos);
        float* p = &g_vertexArrays.pos[idx * 3];
        v.x = p[0];
        v.y = p[1];
        v.z = p[2];
    }

    // COLOR0
    if (g_vcd.color0 == GX_DIRECT) {
        v.color = *(uint32_t*)fifo;
        fifo += 4;
    } else {
        uint32_t idx = GX_ReadIndex(fifo, g_vcd.color0);
        v.color = g_vertexArrays.color0[idx];
    }

    // TEX0
    if (g_vcd.tex0 == GX_DIRECT) {
        memcpy(&v.u, fifo, 8);
        fifo += 8;
    } else {
        uint32_t idx = GX_ReadIndex(fifo, g_vcd.tex0);
        float* t = &g_vertexArrays.tex0[idx * 2];
        v.u = t[0];
        v.v = t[1];
    }

    return v;
}