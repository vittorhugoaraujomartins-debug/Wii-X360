#pragma once

struct XFState {
    float modelView[12];   // 3x4
    float projection[16];  // 4x4
};

namespace GXXF {

void Init();
void LoadModelView(const float* mtx);
void LoadProjection(const float* mtx);

void Transform(float* pos); // pos[3]

}

#pragma once
#include <cstdint>

namespace GX::XF {

void Load(uint16_t addr, uint16_t count);

}

#pragma once
#include <vector>
#include "gx_vtx.h"

namespace GXXF {

void Reset();
void LoadMatrix(uint32_t);
void Draw(const std::vector<GXVertex>& vtx);

}