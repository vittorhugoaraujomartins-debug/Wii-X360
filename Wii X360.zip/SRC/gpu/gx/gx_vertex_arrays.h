#pragma once
#include <cstdint>

struct GXVertexArrays {
    float*    pos;     // xyz xyz xyz
    uint32_t* color0;  // RGBA8
    float*    tex0;    // uv uv uv
};

extern GXVertexArrays g_vertexArrays;