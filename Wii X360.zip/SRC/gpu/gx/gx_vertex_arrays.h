#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

struct GXVertexArrays {
    float*    pos;     // xyz xyz xyz
    uint32_t* color0;  // RGBA8
    float*    tex0;    // uv uv uv
};

extern GXVertexArrays g_vertexArrays;