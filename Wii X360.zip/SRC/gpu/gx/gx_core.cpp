#include "gx_core.h"
#include "XenosGPU.h"
#include <vector>
#include <cstring>

namespace GX {

static GXState g_state{};
static PrimitiveType g_currentPrim;

static std::vector<float> g_vtx;
static constexpr uint32_t FLOATS_PER_VERTEX = 7;
// x y z r g b a

void Init() {
    memset(&g_state, 0, sizeof(g_state));
    g_currentPrim = GX_TRIANGLES;
    g_vtx.clear();
}

void Shutdown() {
    g_vtx.clear();
}

void SetState(const GXState& state) {
    g_state = state;
    XenosGPU::ApplyGXState(state);
}

void Begin(PrimitiveType prim) {
    g_currentPrim = prim;
    g_vtx.clear();
}

void Position3f(float x, float y, float z) {
    g_vtx.push_back(x);
    g_vtx.push_back(y);
    g_vtx.push_back(z);
}

void Color4f(float r, float g, float b, float a) {
    g_vtx.push_back(r);
    g_vtx.push_back(g);
    g_vtx.push_back(b);
    g_vtx.push_back(a);
}

void End() {
    if (g_vtx.empty())
        return;

    uint32_t count =
        static_cast<uint32_t>(g_vtx.size() / FLOATS_PER_VERTEX);

    XenosGPU::UploadVertexBuffer(
        g_vtx.data(),
        count * FLOATS_PER_VERTEX * sizeof(float),
        FLOATS_PER_VERTEX * sizeof(float)
    );

    XenosGPU::Draw(g_currentPrim, count);

    g_vtx.clear();
}

void Flush() {
    // futuro: FIFO real + sync CPU/GPU
}

}