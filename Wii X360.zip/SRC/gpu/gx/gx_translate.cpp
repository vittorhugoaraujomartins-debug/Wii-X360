#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
// FIXME: include not found in project (left original below):
#include "gx_translate.h"
#include "gx_state.h"
// FIXME: include not found in project (left original below):
#include "xenos_backend.h"
void GXTranslate::HandleCommand(uint32_t cmd){switch(cmd&0xFF000000){case 0x10000000:if(gGXState.vertexFormat!=cmd){gGXState.vertexFormat=cmd;gGXState.dirty=true;}break;case 0x20000000:if(gGXState.textureState!=cmd){gGXState.textureState=cmd;gGXState.dirty=true;}break;case 0x30000000:if(gGXState.dirty){XenosBackend::ApplyState(gGXState);gGXState.dirty=false;}XenosBackend::Draw();break;}}
