#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):
// FIXME: include not found in project (left original below):
void GXTranslate::HandleCommand(uint32_t cmd){switch(cmd&0xFF000000){case 0x10000000:if(gGXState.vertexFormat!=cmd){gGXState.vertexFormat=cmd;gGXState.dirty=true;}break;case 0x20000000:if(gGXState.textureState!=cmd){gGXState.textureState=cmd;gGXState.dirty=true;}break;case 0x30000000:if(gGXState.dirty){XenosBackend::ApplyState(gGXState);gGXState.dirty=false;}XenosBackend::Draw();break;}}