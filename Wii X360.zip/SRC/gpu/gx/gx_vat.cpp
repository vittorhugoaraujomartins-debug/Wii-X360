#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>



GXVAT g_vat = { GX_F32, GX_U8, GX_F32 };

void GX_SetVAT(uint32_t v) {
    g_vat.posType   = (GXCompType)((v >> 0) & 3);
    g_vat.colorType = (GXCompType)((v >> 2) & 3);
    g_vat.texType   = (GXCompType)((v >> 4) & 3);
}