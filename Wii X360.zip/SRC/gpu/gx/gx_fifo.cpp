#include "gx_fifo.h"

namespace GX {

FIFO g_fifo;

void FIFO::Init(uint32_t size) {
    buffer.resize(size / 4);
    readPos = writePos = 0;
}

void FIFO::Reset() {
    readPos = writePos = 0;
}

void FIFO::Write32(uint32_t v) {
    buffer[writePos++] = v;
    writePos %= buffer.size();
}

bool FIFO::Read32(uint32_t& out) {
    if (readPos == writePos)
        return false;

    out = buffer[readPos++];
    readPos %= buffer.size();
    return true;
}

bool FIFO::HasData() const {
    return readPos != writePos;
}

}