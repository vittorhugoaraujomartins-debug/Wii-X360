#include "XenosGPU.h"

static IDirect3DDevice9* g_device = nullptr;
static IDirect3DVertexBuffer9* g_vb = nullptr;
static uint32_t g_stride = 0;

namespace XenosGPU {

void Init(IDirect3DDevice9* device) {
    g_device = device;
}

void Shutdown() {
    if (g_vb) g_vb->Release();
    g_vb = nullptr;
}

void ApplyGXState(const GX::GXState& s) {
    g_device->SetRenderState(D3DRS_ZENABLE, s.depthTest);
    g_device->SetRenderState(D3DRS_CULLMODE,
        s.cullFace ? D3DCULL_CCW : D3DCULL_NONE
    );
}

void UploadVertexBuffer(const void* data, uint32_t size, uint32_t stride) {
    g_stride = stride;

    if (g_vb) g_vb->Release();
    g_device->CreateVertexBuffer(size, 0, 0,
        D3DPOOL_DEFAULT, &g_vb, nullptr);

    void* dst;
    g_vb->Lock(0, size, &dst, 0);
    memcpy(dst, data, size);
    g_vb->Unlock();

    g_device->SetStreamSource(0, g_vb, 0, stride);
}

void Draw(GX::PrimitiveType prim, uint32_t count) {
    g_device->DrawPrimitive(
        D3DPT_TRIANGLELIST, 0, count
    );
}

}