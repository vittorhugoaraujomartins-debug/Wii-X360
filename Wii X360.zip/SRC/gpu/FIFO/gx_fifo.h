#pragma once
#include <stdint.h>

namespace GXFIFO {

void Init();
void Reset();

// Escrita pelo PPC (MMIO GX)
void Write8(uint8_t v);
void Write16(uint16_t v);
void Write32(uint32_t v);

// Consumo pela GPU
void Process();

// Estado
bool HasData();

}