#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


namespace GX {

FIFO g_fifo;

void FIFO::Init(uint32_t size) {
    buffer.resize(size / 4);
    readPos = writePos = 0;
}

void FIFO::Reset() {
    readPos = writePos = 0;
}

void FIFO::Write32(uint32_t v) {
    buffer[writePos++] = v;
    writePos %= buffer.size();
}

bool FIFO::Read32(uint32_t& out) {
    if (readPos == writePos)
        return false;

    out = buffer[readPos++];
    readPos %= buffer.size();
    return true;
}

bool FIFO::HasData() const {
    return readPos != writePos;
}

}


static uint8_t fifo[0x10000];
static uint32_t fifoWrite = 0;

namespace GXFIFO {

void Write8(uint8_t v) {
    fifo[fifoWrite++] = v;
}

void Write16(uint16_t v) {
    *(uint16_t*)&fifo[fifoWrite] = v;
    fifoWrite += 2;
}

void Write32(uint32_t v) {
    *(uint32_t*)&fifo[fifoWrite] = v;
    fifoWrite += 4;
}

void Execute() {
    uint32_t ptr = 0;

    while (ptr < fifoWrite) {
        uint8_t cmd = fifo[ptr++];
        GXGPU::ExecuteCommand(cmd, &fifo[ptr]);
    }

    fifoWrite = 0;
}
}



static std::queue<uint32_t> fifo;

namespace GXFIFO {

void Reset() {
    while (!fifo.empty()) fifo.pop();
}

void Push(uint32_t v) {
    fifo.push(v);
}

bool HasData() {
    return !fifo.empty();
}

uint32_t Pop() {
    uint32_t v = fifo.front();
    fifo.pop();
    return v;
}

// GX opcode mínimo
void Execute(uint32_t cmd) {
    uint8_t opcode = cmd >> 24;

    switch (opcode) {
    case 0x10: GXVTX::Begin(cmd & 0xFFFF); break; // GX_BEGIN
    case 0x20: GXVTX::Vertex(cmd); break;        // VTX data
    case 0x30: GXXF::LoadMatrix(cmd); break;     // XF matrix
    case 0x40: GXVTX::End(); break;               // GX_END
    default: break;
    }
}

}

#include "gx_fifo.h"
#include "gx_cp.h"

static uint8_t fifo[2 * 1024 * 1024]; // 2MB realista
static uint32_t writePtr = 0;
static uint32_t readPtr  = 0;

namespace GXFIFO {

void Init() {
    Reset();
}

void Reset() {
    writePtr = readPtr = 0;
}

static inline void Push(uint8_t v) {
    fifo[writePtr++] = v;
    writePtr &= (sizeof(fifo) - 1);
}

void Write8(uint8_t v)  { Push(v); }
void Write16(uint16_t v){ Push(v >> 8); Push(v); }
void Write32(uint32_t v){
    Push(v >> 24); Push(v >> 16);
    Push(v >> 8);  Push(v);
}

void Process() {
    while (readPtr != writePtr) {
        uint8_t cmd = fifo[readPtr++];
        readPtr &= (sizeof(fifo) - 1);

        GXCP::Execute(cmd, fifo, readPtr);
    }
}

}