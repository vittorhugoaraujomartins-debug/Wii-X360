#include "gx_fifo.h"
#include "gx_cp.h"

static uint8_t fifo[2 * 1024 * 1024]; // 2MB (igual GC/Wii)
static uint32_t writePtr = 0;
static uint32_t readPtr  = 0;

namespace GXFIFO {

void Init() {
    Reset();
}

void Reset() {
    writePtr = readPtr = 0;
}

static inline void Push(uint8_t v) {
    fifo[writePtr++] = v;
    writePtr &= (sizeof(fifo) - 1);
}

void Write8(uint8_t v) {
    Push(v);
}

void Write16(uint16_t v) {
    Push(v >> 8);
    Push(v);
}

void Write32(uint32_t v) {
    Push(v >> 24);
    Push(v >> 16);
    Push(v >> 8);
    Push(v);
}

bool HasData() {
    return readPtr != writePtr;
}

// Consumo do FIFO pelo CP
void Process() {
    while (readPtr != writePtr) {

        uint8_t cmd = fifo[readPtr++];
        readPtr &= (sizeof(fifo) - 1);

        GXCP::Execute(cmd, fifo, readPtr);
    }
}

}