// GXCommandBatcher.cpp

#include <vector>
#include <cstdint>

static std::vector<uint32_t> gxBatch;

void GX_PushCommand(uint32_t cmd)
{
    gxBatch.push_back(cmd);

    if (gxBatch.size() >= 256)
        GX_Flush();
}

void GX_Flush()
{
    // Processa lote inteiro
    for (auto cmd : gxBatch)
    {
        // ProcessCommand(cmd);
    }

    gxBatch.clear();
}