#include "GXFIFO.h"
#include "GX.h"
#include "XenosGPU.h"


// FIXME: include not found in project (left original below):

static std::queue<uint32_t> fifo;

namespace GXFIFO {

void Init() {
    while (!fifo.empty()) fifo.pop();
}

void Push32(uint32_t v) {
    fifo.push(v);
}

void PushFloat(float f) {
    uint32_t v;
    memcpy(&v, &f, sizeof(uint32_t));
    fifo.push(v);
}

void Execute() {

    while (!fifo.empty()) {

        uint32_t cmd = fifo.front();
        fifo.pop();

        // GXBegin
        if ((cmd & 0xF0000000) == 0x10000000) {
            XenosGPU::Begin();
        }
        // GXEnd
        else if ((cmd & 0xF0000000) == 0x40000000) {
            XenosGPU::End();
        }
        // Vértice
        else {
            float x = *(float*)&cmd;

            uint32_t vy = fifo.front(); fifo.pop();
            uint32_t vz = fifo.front(); fifo.pop();
            uint32_t color = fifo.front(); fifo.pop();

            float y = *(float*)&vy;
            float z = *(float*)&vz;

            XenosGPU::PushVertex(x, y, z, color);
        }
    }
}

}


GXVCD::SetPos(GX_DIRECT, GX_F32, 3);
GXVCD::SetColor(GX_DIRECT);
GXVCD::SetTex0(GX_NONE, GX_F32, 2);


#include "GXFIFO.h"

namespace GX {

static uint32_t fifoCount = 0;

void FIFO_Init() {
    fifoCount = 0;
}

void FIFO_Write(uint32_t) {
    fifoCount++;
}

void FIFO_Flush() {
    fifoCount = 0;
}

}