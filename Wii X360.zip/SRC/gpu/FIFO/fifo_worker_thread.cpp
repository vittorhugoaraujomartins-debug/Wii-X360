#include "fifo_worker_thread.h"

void FIFOProcessor::Start()
{
    running = true;
    worker = std::thread(&FIFOProcessor::ThreadLoop, this);
}

void FIFOProcessor::Stop()
{
    running = false;
    cv.notify_all();
    if (worker.joinable())
        worker.join();
}

void FIFOProcessor::PushCommand(uint32_t cmd)
{
    {
        std::lock_guard<std::mutex> lock(mutex);
        commandQueue.push(cmd);
    }
    cv.notify_one();
}

void FIFOProcessor::ThreadLoop()
{
    while (running)
    {
        std::unique_lock<std::mutex> lock(mutex);
        cv.wait(lock, [&]() { return !commandQueue.empty() || !running; });

        while (!commandQueue.empty())
        {
            uint32_t cmd = commandQueue.front();
            commandQueue.pop();

            // TODO: ProcessGXCommand(cmd);
        }
    }
}