##pragma once
#include <stdint.h>

namespace GXFIFO {

void Init();
void WriteU32(uint32_t v);
void Execute();

}
#pragma once
// FIXME: include not found in project (left original below):

namespace GXFIFO {

    void Init();
    void Push(uint32_t cmd);
    bool HasCommands();
    void Execute();
}

t
#pragma once

namespace GXFIFO {

    void Init();
    void WriteU8(uint8_t v);
    void WriteU16(uint16_t v);
    void WriteU32(uint32_t v);

    void Execute();
}

#pragma once
// FIXME: include not found in project (left original below):

namespace GXFIFO {

void Init();
void Shutdown();

void Push32(uint32_t v);
void PushFloat(float f);

bool HasCommands();
uint32_t Pop32();
float PopFloat();

void Execute();

}

#pragma once
#include <stdint.h>

namespace GX {

void FIFO_Init();
void FIFO_Write(uint32_t data);
void FIFO_Flush();

}