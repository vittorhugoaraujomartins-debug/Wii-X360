#pragma once
#include <thread>
#include <atomic>
#include <queue>
#include <mutex>
#include <condition_variable>

class FIFOProcessor
{
public:
    void Start();
    void Stop();
    void PushCommand(uint32_t cmd);

private:
    void ThreadLoop();

    std::thread worker;
    std::atomic<bool> running = false;

    std::queue<uint32_t> commandQueue;
    std::mutex mutex;
    std::condition_variable cv;
};