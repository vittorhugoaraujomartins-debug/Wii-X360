#pragma once
#include <cstdint>
#include <vector>
#include <xgraphics.h>
#include "GX.h"

namespace XenosGPU {

// Vida útil
void Init(IDirect3DDevice9* device);
void Shutdown();

// Frame
void BeginFrame();
void EndFrame();

// Estado GX
void ApplyGXState(const GX::GXState& state);

// Buffers
void UploadVertexBuffer(const void* data, uint32_t size, uint32_t stride);
void UploadIndexBuffer(const void* data, uint32_t size);

// Draw
void Draw(GX::PrimitiveType prim, uint32_t vertexCount);
void DrawIndexed(GX::PrimitiveType prim, uint32_t vertexCount, uint32_t indexCount);

// FIFO
void ExecuteGX(const std::vector<uint32_t>& fifo);

// Texturas
void UploadTexture2D(const void* data, uint32_t width, uint32_t height);
void BindTexture();

// Otimizações
bool IsVisible(const float* bboxMin, const float* bboxMax);
void DrawInstanced(GX::PrimitiveType prim, uint32_t count, uint32_t instances);

}
