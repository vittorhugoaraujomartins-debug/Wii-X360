#include "gpu.h"
void GPU::SafeRender() {
    if(!initialized) return;
    RenderFrame();
}
