#include "gx_shader_manager.h"

extern IDirect3DDevice9* g_d3d;

bool GXShaderManager::Init() {

    // Aqui você carrega os shaders compilados (.xvu / .xpu)
    // ou compila em runtime se quiser

    // Placeholder: assume que já foram criados
    return true;
}

void GXShaderManager::Bind() {
    g_d3d->SetVertexShader(vs);
    g_d3d->SetPixelShader(ps);
}

void GXShaderManager::SetMVP(const float* mtx) {
    g_d3d->SetVertexShaderConstantF(0, mtx, 4);
}