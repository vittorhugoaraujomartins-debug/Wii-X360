#pragma once
#include <xtl.h>
#include <xgraphics.h>

class GXShaderManager {
public:
    bool Init();
    void Bind();
    void SetMVP(const float* mtx);

private:
    IDirect3DVertexShader9* vs = NULL;
    IDirect3DPixelShader9*  ps = NULL;

    D3DXHANDLE hMVP = NULL;
};