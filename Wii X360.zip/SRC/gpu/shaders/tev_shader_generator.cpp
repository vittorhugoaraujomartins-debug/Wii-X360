#include "tev_shader_generator.h"
#include <sstream>

using namespace GXTEV;

static std::string SourceToHLSL(ColorSource src)
{
    switch (src)
    {
        case SRC_VERTEX:  return "vColor";
        case SRC_TEXTURE: return "tColor";
        case SRC_PREV:    return "prev";
        case SRC_CONST:   return "constColor";
        default: return "float4(0,0,0,0)";
    }
}

static std::string OpToHLSL(const Stage& st, const std::string& A, const std::string& B)
{
    switch (st.op)
    {
        case OP_REPLACE:  return A;
        case OP_MODULATE: return "(" + A + " * " + B + ")";
        case OP_ADD:      return "(" + A + " + " + B + ")";
        case OP_SUB:      return "(" + A + " - " + B + ")";
        default: return A;
    }
}

std::string TEVShaderGenerator::GeneratePixelShader(const std::vector<Stage>& stages)
{
    std::stringstream ss;

    ss << "float4 constColor;\n";
    ss << "sampler2D tex0;\n";

    ss << "struct PS_IN {\n";
    ss << "    float4 vColor : COLOR0;\n";
    ss << "    float2 uv : TEXCOORD0;\n";
    ss << "};\n";

    ss << "float4 main(PS_IN input) : COLOR {\n";
    ss << "    float4 vColor = input.vColor;\n";
    ss << "    float4 tColor = tex2D(tex0, input.uv);\n";
    ss << "    float4 prev = vColor;\n";

    for (size_t i = 0; i < stages.size(); i++)
    {
        const Stage& st = stages[i];

        std::string A = SourceToHLSL(st.a);
        std::string B = SourceToHLSL(st.b);
        std::string D = SourceToHLSL(st.d);

        std::string result = OpToHLSL(st, A, B);

        // Bias
        if (st.bias == BIAS_ADD_HALF)
            result = "(" + result + " + 0.5)";
        else if (st.bias == BIAS_SUB_HALF)
            result = "(" + result + " - 0.5)";

        // Scale
        if (st.scale == SCALE_2X)
            result = "(" + result + " * 2.0)";
        else if (st.scale == SCALE_4X)
            result = "(" + result + " * 4.0)";
        else if (st.scale == SCALE_HALF)
            result = "(" + result + " * 0.5)";

        result = result + " + " + D;

        if (st.clamp)
            result = "saturate(" + result + ")";

        ss << "    prev = " << result << ";\n";
    }

    ss << "    return prev;\n";
    ss << "}\n";

    return ss.str();
}


static uint64_t HashPipeline(const GXPipelineState& s)
{
    uint64_t h = 1469598103934665603ULL; // FNV

    auto HashVal = [&](uint64_t v)
    {
        h ^= v;
        h *= 1099511628211ULL;
    };

    HashVal(s.depthEnable);
    HashVal(s.depthWrite);
    HashVal(s.depthFunc);
    HashVal(s.blendEnable);
    HashVal(s.blendSrc);
    HashVal(s.blendDst);
    HashVal(s.alphaEnable);
    HashVal(s.alphaFunc);
    HashVal(s.alphaRef);
    HashVal(s.lighting);
    HashVal(s.uiMode);

    for (auto& st : s.tevStages)
    {
        HashVal(st.a);
        HashVal(st.b);
        HashVal(st.c);
        HashVal(st.d);
        HashVal(st.bias);
        HashVal(st.scale);
        HashVal(st.clamp);
    }

    return h;
}



float4x4 WorldViewProj;
bool lighting;

struct VS_IN {
    float4 pos : POSITION0;
    float4 color : COLOR0;
    float2 uv : TEXCOORD0;
};

struct VS_OUT {
    float4 pos : POSITION0;
    float4 color : COLOR0;
    float2 uv : TEXCOORD0;
};

VS_OUT vs_main(VS_IN input)
{
    VS_OUT o;
    o.pos = mul(input.pos, WorldViewProj);

    if (lighting)
        o.color = input.color * 0.8;
    else
        o.color = input.color;

    o.uv = input.uv;
    return o;
}


std::unordered_map<uint64_t, IDirect3DPixelShader9*> gShaderCache;


uint64_t h = HashPipeline(state);

if (gShaderCache.find(h) == gShaderCache.end())
{
    std::string code = GenerateUnifiedShader(state);

    IDirect3DPixelShader9* shader = Compile(code);
    gShaderCache[h] = shader;
}

g_d3d->SetPixelShader(gShaderCache[h]);



if (CanInstance(drawCall))
{
    AccumulateInstance(drawCall);
}
else
{
    FlushInstances();
    DrawNormally();
}


float4x4 InstanceMatrix[64];
int instanceID : SV_InstanceID;


o.pos = mul(input.pos, InstanceMatrix[instanceID]);


