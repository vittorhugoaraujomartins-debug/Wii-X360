#include "gx_common.hlsl"

struct PS_IN {
    float4 color : COLOR0;
    float2 uv    : TEXCOORD0;
};

float4 main(PS_IN input) : COLOR {

    float4 ras = input.color;
    float4 prev = ras;

    // Stage 0
    float4 tex0 = tex2D(s_Texture[0], input.uv);
    prev = TEVStage(prev, tex0, ras, u_TevColor[0], 1);

    // Stage 1
    float4 tex1 = tex2D(s_Texture[1], input.uv);
    prev = TEVStage(prev, tex1, ras, u_TevColor[1], 1);

    // Stage 2
    float4 tex2 = tex2D(s_Texture[2], input.uv);
    prev = TEVStage(prev, tex2, ras, u_TevColor[2], 2);

    // Stage 3
    float4 tex3 = tex2D(s_Texture[3], input.uv);
    prev = TEVStage(prev, tex3, ras, u_TevColor[3], 1);

    // Stage 4
    float4 tex4 = tex2D(s_Texture[4], input.uv);
    prev = TEVStage(prev, tex4, ras, u_TevColor[4], 2);

    // Stage 5
    float4 tex5 = tex2D(s_Texture[5], input.uv);
    prev = TEVStage(prev, tex5, ras, u_TevColor[5], 1);

    return prev;
}