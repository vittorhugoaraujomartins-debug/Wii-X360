float4x4 u_MVP;

// Raster color
float4 u_RasColor;

// TEV registers
float4 u_TevColor[6];

// Samplers (até 6)
sampler2D s_Texture[6];