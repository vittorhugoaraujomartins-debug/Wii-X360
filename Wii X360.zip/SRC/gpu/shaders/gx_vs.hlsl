#include "gx_common.hlsl"

struct VS_IN {
    float3 pos   : POSITION;
    float4 color : COLOR0;
    float2 uv    : TEXCOORD0;
};

struct VS_OUT {
    float4 pos   : POSITION;
    float4 color : COLOR0;
    float2 uv    : TEXCOORD0;
};

VS_OUT main(VS_IN input) {
    VS_OUT o;
    o.pos   = mul(float4(input.pos, 1.0), u_MVP);
    o.color = input.color;
    o.uv    = input.uv;
    return o;
}