#pragma once
#include <string>
#include <vector>
#include "GXTEV.h"

class TEVShaderGenerator
{
public:
    std::string GeneratePixelShader(const std::vector<GXTEV::Stage>& stages);
};


struct GXPipelineState
{
    // BP
    bool depthEnable;
    bool depthWrite;
    uint8_t depthFunc;

    bool blendEnable;
    uint8_t blendSrc;
    uint8_t blendDst;

    bool alphaEnable;
    uint8_t alphaFunc;
    uint8_t alphaRef;

    // XF
    bool lighting;
    bool uiMode;

    // TEV
    std::vector<GXTEV::Stage> tevStages;

    // hash final
    uint64_t hash;
};



