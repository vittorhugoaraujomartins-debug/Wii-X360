void GXCore_Init();
void GXCore_Process();