#include "gpu.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


namespace GPU {

void Init() {
    GXFIFO::Reset();
    GXVTX::Reset();
    GXXF::Reset();
    GXTEV::Reset();
}

void Reset() {
    Init();
}

void WriteFIFO(uint32_t v) {
    GXFIFO::Push(v);
}

void Step() {
    while (GXFIFO::HasData()) {
        uint32_t cmd = GXFIFO::Pop();
        GXFIFO::Execute(cmd);
    }
}

}

// --- Added by bugfix patch ---

void GPU::Run() {
    int guard = 0;
    while (!GX::CommandQueue.empty() && guard < 1024) {
        GXCommand cmd = GX::CommandQueue.front();
        GX::CommandQueue.pop();
        ExecuteGXCommand(cmd);
        guard++;
    }
}