#include "XenosHLEGPU.h"

// Aqui acontece a mágica GX → Xenos

void XenosHLEGPU::DrawTriangles(const HLEVertex* verts, int count)
{
    // Upload vertex buffer
    // Bind shader simples
    // DrawPrimitive TRIANGLELIST

    // Exemplo lógico:

    /*
    X360_SetVertexBuffer(verts, count * sizeof(HLEVertex));
    X360_DrawPrimitive(TRIANGLELIST, count / 3);
    */
}


ID3DBlob* compiledShader = nullptr;
ID3DBlob* errors = nullptr;

std::string shaderCode = generator.GeneratePixelShader(stages);

HRESULT hr = D3DCompile(
    shaderCode.c_str(),
    shaderCode.size(),
    nullptr,
    nullptr,
    nullptr,
    "main",
    "ps_3_0",
    0,
    0,
    &compiledShader,
    &errors
);