#pragma once

#include <cstdint>

struct HLEVertex
{
    float x, y, z;
    float nx, ny, nz;
    float u, v;
    uint32_t color;
};

class XenosHLEGPU
{
public:
    static void Init();
    static void Shutdown();

    static void BeginFrame();
    static void EndFrame();

    static void Clear(float r, float g, float b, float a);

    static void DrawTriangles(const HLEVertex* verts, int count);

    static void SetViewport(int x, int y, int w, int h);
};