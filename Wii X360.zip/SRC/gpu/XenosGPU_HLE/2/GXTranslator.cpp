#include "GXTranslator.h"

// Inclui seus módulos atuais
#include "../gx/gx_state.h"
#include "../Vertex/GXVertex.h"
#include "../BP/bp_state.h"

void GXHLE_BeginFrame()
{
    XenosHLEGPU::BeginFrame();
}

void GXHLE_EndFrame()
{
    XenosHLEGPU::EndFrame();
}

void GXHLE_ClearFromBP()
{
    float r = BP_GetClearColorR();
    float g = BP_GetClearColorG();
    float b = BP_GetClearColorB();
    float a = BP_GetClearColorA();

    XenosHLEGPU::Clear(r, g, b, a);
}


static void ConvertGXVertices(HLEVertex* outVerts, int count)
{
    for (int i = 0; i < count; i++)
    {
        const GXVertex& v = GX_GetVertex(i);

        outVerts[i].x = v.pos.x;
        outVerts[i].y = v.pos.y;
        outVerts[i].z = v.pos.z;

        outVerts[i].nx = v.normal.x;
        outVerts[i].ny = v.normal.y;
        outVerts[i].nz = v.normal.z;

        outVerts[i].u = v.uv.u;
        outVerts[i].v = v.uv.v;

        outVerts[i].color = v.color;
    }
}


void GXHLE_DrawFromCP()
{
    int vertexCount = CP_GetVertexCount();

    if (vertexCount <= 0)
        return;

    static HLEVertex verts[65536];

    ConvertGXVertices(verts, vertexCount);

    XenosHLEGPU::DrawTriangles(verts, vertexCount);
}


void GXHLE_SetViewport()
{
    int x, y, w, h;
    XF_GetViewport(x, y, w, h);

    XenosHLEGPU::SetViewport(x, y, w, h);
}


void GXHLE_CopyEFBToXFB()
{
    // Em HLE agressiva:
    // apresentar frame atual já basta

    XenosHLEGPU::EndFrame();
    XenosHLEGPU::BeginFrame();
}