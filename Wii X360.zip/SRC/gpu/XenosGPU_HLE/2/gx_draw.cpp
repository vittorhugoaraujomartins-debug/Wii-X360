#include "gx_draw.h"
#include <d3d9.h>

extern IDirect3DDevice9* g_d3d;

namespace GXDraw {

static std::vector<GXVertex> g_vertices;
static D3DPRIMITIVETYPE g_primType;

void Begin(uint8_t prim)
{
    g_vertices.clear();

    // GX primitive → D3D
    if (prim == 0x90)      // TRIANGLES
        g_primType = D3DPT_TRIANGLELIST;
    else if (prim == 0x98) // TRIANGLE STRIP
        g_primType = D3DPT_TRIANGLESTRIP;
    else
        g_primType = D3DPT_TRIANGLELIST;
}

void Submit(const GXVertex& v)
{
    g_vertices.push_back(v);
}

void Flush()
{
    if (g_vertices.empty()) return;

    g_d3d->SetFVF(D3DFVF_XYZ | D3DFVF_DIFFUSE);

    int primitiveCount =
        (g_primType == D3DPT_TRIANGLELIST)
        ? g_vertices.size() / 3
        : g_vertices.size() - 2;

    g_d3d->DrawPrimitiveUP(
        g_primType,
        primitiveCount,
        g_vertices.data(),
        sizeof(GXVertex));
}

}