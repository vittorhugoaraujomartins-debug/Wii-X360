#pragma once
#include <vector>
#include "gx_vertex.h"

namespace GXDraw {

void Begin(uint8_t prim);
void Submit(const GXVertex& v);
void Flush();

}