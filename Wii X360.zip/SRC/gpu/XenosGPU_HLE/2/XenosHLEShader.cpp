#include <cstdio>

void HLE_BindBasicShader()
{
    // Shader equivalente a:
    // textura + cor de vértice + iluminação simples

    printf("[XenosHLE] Bind Basic Shader\n");
}