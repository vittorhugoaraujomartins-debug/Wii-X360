#pragma once

#include "../XenosHLE/XenosHLEGPU.h"

void GXHLE_BeginFrame();
void GXHLE_EndFrame();

void GXHLE_ClearFromBP();

void GXHLE_DrawFromCP();