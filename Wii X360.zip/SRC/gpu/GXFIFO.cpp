#include "GXFIFO.h"
#include <cstring>

namespace GXFIFO {

FIFO g_fifo;

void FIFO::Init(uint32_t sizeBytes) {
    buffer.clear();
    buffer.reserve(sizeBytes / 4);
    read_ptr = 0;
}

void FIFO::Reset() {
    buffer.clear();
    read_ptr = 0;
}

void FIFO::WriteU32(uint32_t v) {
    buffer.push_back(v);
}

void FIFO::WriteFloat(float v) {
    uint32_t u;
    std::memcpy(&u, &v, sizeof(uint32_t));
    buffer.push_back(u);
}

bool FIFO::HasData(uint32_t count) const {
    return (read_ptr + count) <= buffer.size();
}

uint32_t FIFO::Read32() {
    if (!HasData(1))
        return 0;
    return buffer[read_ptr++];
}

void FIFO::Execute() {
    read_ptr = 0;

    while (HasData(1)) {
        uint32_t cmd = Read32();

        switch (cmd) {

        case GX_CMD_NOP:
            break;

        case GX_CMD_LOAD_CP:
            if (!HasData(2)) return;
            XenosGPU::SetCommandProcessor(Read32(), Read32());
            break;

        case GX_CMD_LOAD_XF:
            if (!HasData(2)) return;
            XenosGPU::SetTransformUnit(Read32(), Read32());
            break;

        case GX_CMD_DRAW:
            if (!HasData(2)) return;
            XenosGPU::DrawPrimitive(
                static_cast<GX::PrimitiveType>(Read32()),
                Read32()
            );
            break;

        default:
            // comando desconhecido → ignora com segurança
            break;
        }
    }

    // NÃO limpa automaticamente → comportamento mais realista
}

} 

InstrOrder::IOBarrier();
GXFIFO::Push(cmd);


#include "CPUScheduler.h"

void GXFIFO::PushCommand(uint32_t cmd) {
    fifo.push(cmd);

    WiiCPU::CPUScheduler::Schedule(
        WiiCPU::CPUScheduler::GetCycle() + 200,
        WiiCPU::EventType::GPU,
        []() {
            GXFIFO::Execute();
        }
    );
}