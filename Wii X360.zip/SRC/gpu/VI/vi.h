#pragma once

namespace VI {

bool Init();
void Update();

bool IsVBlank();

}