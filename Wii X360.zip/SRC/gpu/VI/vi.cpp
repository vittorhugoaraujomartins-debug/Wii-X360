#include "vi.h"

namespace VI {

static int counter = 0;
static bool vblank = false;

bool Init()
{
    counter = 0;
    vblank = false;
    return true;
}

void Update()
{
    counter++;

    // ~60 Hz fake
    if (counter > 100000)
    {
        vblank = true;
        counter = 0;
    }
}

bool IsVBlank()
{
    bool v = vblank;
    vblank = false;
    return v;
}

}