// ================= CPU COMPLETA =================
#include "XenonCPU.h"
#include "PowerPC.h"
#include "ppc_jit.h"
#include "../MemoryManager.h"
#include <cstring>

namespace WiiCPU {

// Thread-safe fetch de opcode do ROM
static uint32_t FetchOpcode(uint32_t pc) {
    auto rom = WiiX360::MemoryManager::GetRegion(WiiX360::MemoryRegion::ROM);
    if (pc < rom.size) {
        return *(uint32_t*)(rom.base + pc);
    }
    return 0x60000000; // NOP seguro
}

// Atualiza o Step para usar fetch + JIT
void PowerPC::Step() {
    uint32_t opcode = FetchOpcode(pc);

    // Tenta pegar função JIT
    static PPCJIT jit;
    JitFunc func = jit.GetOrCompile(pc);
    func(); // executa o bloco JIT (ou opcode direto)

    pc += 4;
}

void PowerPC::ExecuteInstruction(uint32_t opcode) {
    // Exemplo rápido de execução mínima
    switch (opcode) {
        case 0x60000000: // NOP
            return;
        // Futuras instruções podem ser mapeadas aqui
        default:
            break;
    }
}

} // namespace WiiCPU

// ================= GPU COMPLETA =================
#include "XenosGPU.h"
#include "GX.h"
#include "GXFIFO.h"
#include <xtl.h>
#include <xgraphics.h>
#include <cstring>

static IDirect3DDevice9* g_device = nullptr;
static IDirect3DVertexBuffer9* g_vb = nullptr;
static IDirect3DIndexBuffer9* g_ib = nullptr;

namespace XenosGPU {

// Inicializa GPU usando Direct3D XDK
void Init() {
    g_device = Direct3D_GetDevice();
}

// Libera buffers
void Shutdown() {
    if (g_vb) { g_vb->Release(); g_vb = nullptr; }
    if (g_ib) { g_ib->Release(); g_ib = nullptr; }
}

// Aplica estado GX
void ApplyGXState(const GX::GXState& state) {
    if (!g_device) return;

    g_device->SetRenderState(D3DRS_ZENABLE, state.depthTest);
    g_device->SetRenderState(D3DRS_ALPHATESTENABLE, state.alphaTest);
    g_device->SetRenderState(D3DRS_CULLMODE,
        state.cullFace ? D3DCULL_CCW : D3DCULL_NONE);
}

// Vertex buffer
void UploadVertexBuffer(const void* data, uint32_t size) {
    if (!g_device) return;

    if (g_vb) g_vb->Release();
    g_device->CreateVertexBuffer(size, 0, 0, D3DPOOL_DEFAULT, &g_vb, nullptr);

    void* dst;
    g_vb->Lock(0, size, &dst, 0);
    memcpy(dst, data, size);
    g_vb->Unlock();

    g_device->SetStreamSource(0, g_vb, 0, sizeof(float) * 8);
}

// Index buffer
void UploadIndexBuffer(const void* data, uint32_t size) {
    if (!g_device) return;

    if (g_ib) g_ib->Release();
    g_device->CreateIndexBuffer(size, 0, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_ib, nullptr);

    void* dst;
    g_ib->Lock(0, size, &dst, 0);
    memcpy(dst, data, size);
    g_ib->Unlock();

    g_device->SetIndices(g_ib);
}

// Desenha primitiva
void DrawPrimitive(GX::PrimitiveType prim, uint32_t count) {
    if (!g_device) return;

    D3DPRIMITIVETYPE type = D3DPT_TRIANGLELIST;
    switch (prim) {
        case GX::GX_POINTS: type = D3DPT_POINTLIST; break;
        case GX::GX_LINES: type = D3DPT_LINELIST; break;
        case GX::GX_TRIANGLES: type = D3DPT_TRIANGLELIST; break;
        case GX::GX_TRIANGLE_STRIP: type = D3DPT_TRIANGLESTRIP; break;
    }

    g_device->DrawIndexedPrimitive(
        type,
        0,      // BaseVertexIndex
        0,      // MinIndex
        count,  // NumVertices
        0,      // StartIndex
        count/3 // PrimitiveCount
    );
}

// Comandos GX
void SetCommandProcessor(uint32_t reg, uint32_t value) {
    (void)reg; (void)value; // Stub para CP
}

void SetTransformUnit(uint32_t reg, uint32_t value) {
    (void)reg; (void)value; // Stub para XF
}

// Executa FIFO
void ExecuteGX(const std::vector<uint32_t>& fifo) {
    for (size_t i = 0; i < fifo.size(); i++) {
        uint32_t cmd = fifo[i];
        // Tradutor GX → Xenos real
    }
}

} // namespace XenosGPU