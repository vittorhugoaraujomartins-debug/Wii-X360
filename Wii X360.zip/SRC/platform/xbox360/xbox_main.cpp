#include <xtl.h>
#include "../../core/EmulatorCore.h"
#include "../../BOOT/dol_loader.h"
#include "../../BOOT/wii_boot.h"
#include "../../gpu/Video/video_core.h"

EmulatorCore g_Emu;

void InitXboxVideo()
{
    XVIDEO_MODE videoMode;
    XGetVideoMode(&videoMode);

    VideoCore::Initialize(
        videoMode.dwDisplayWidth,
        videoMode.dwDisplayHeight
    );
}

void BootWii(const char* path)
{
    DolLoader dol;

    if (!dol.Load(path))
    {
        OutputDebugStringA("Failed to load DOL\n");
        return;
    }

    WiiBoot::BootDol(dol);
}

void MainLoop()
{
    while (true)
    {
        g_Emu.RunFrame();

        VideoCore::Present();

        // Sync to 60 FPS
        Sleep(16);
    }
}

VOID __cdecl main()
{
    InitXboxVideo();

    g_Emu.Initialize();

    BootWii("game:\\main.dol");

    MainLoop();
}