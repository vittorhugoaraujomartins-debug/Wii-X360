#include <xtl.h>
// FIXME: include not found in project (left original below):
#include <xgraphics.h>

// FIXME: include not found in project (left original below):
#include <atomic>
// FIXME: include not found in project (left original below):
// === Core ===
// FIXME: include not found in project (left original below):
#include "MemoryManager.h"
#include "ram_manager.h"
#include "XenonCPU.h"
#include "ppc_jit.h"

// === IOS ===
#include "IOS.h"

// === GPU / GX ===
#include "GX.h"
#include "GXFIFO.h"
#include "XenosGPU.h"

// === Optimizations ===
// FIXME: include not found in project (left original below):
#include "optimizations/OptimizationManager.h"

// =======================================================
// GLOBALS
// =======================================================

static std::atomic<bool> g_running{ true };

WiiCPU::XenonCPU g_cpu;
PPCJIT g_jit;

// =======================================================
// CPU THREAD
// =======================================================

void CPUThread() {
    static bool testSent = false;

    while (g_running) {

        // Executa CPU + JIT
        g_cpu.RunFrame();

        // 🔥 TESTE GPU (simula jogo real escrevendo no FIFO)
        if (!testSent) {
            GXFIFO::Write(0x10000000); // BEGIN
            GXFIFO::Write(0x20008080); // v0
            GXFIFO::Write(0x2000FF80); // v1
            GXFIFO::Write(0x200080FF); // v2
            GXFIFO::Write(0x40000000); // END
            testSent = true;
        }

        std::this_thread::yield();
    }
}

// =======================================================
// GPU THREAD
// =======================================================

void GPUThread() {
    while (g_running) {

        if (GXFIFO::HasCommands()) {
            OptimizationManager::BeginFrame();

            // Decodifica GX → chama backend
            GXFIFO::Execute();
            GX_Draw();

            OptimizationManager::EndFrame();
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
    }
}

// =======================================================
// IOS THREAD
// =======================================================

void IOSThread() {
    while (g_running) {
        IOS::Update();
        std::this_thread::sleep_for(std::chrono::milliseconds(4));
    }
}

// =======================================================
// INIT / SHUTDOWN
// =======================================================

bool InitEmulator() {

    if (!WiiX360::MemoryManager::Initialize())
        return false;

    if (!WiiX360::RamManager::Init())
        return false;

    // CPU + JIT
    g_cpu.Initialize();
    g_jit.Reset();

    // GPU backend primeiro
    XenosGPU::Init();
    GX::Init();

    // IOS
    IOS::Init();

    // Optimizations
    OptimizationManager::Init();
    OptimizationManager::PreRenderLoad();

    return true;
}

void ShutdownEmulator() {

    g_running = false;

    OptimizationManager::Shutdown();
    GX::Shutdown();
    XenosGPU::Shutdown();
    IOS::Shutdown();

    WiiX360::RamManager::Shutdown();
    WiiX360::MemoryManager::Shutdown();
}

// =======================================================
// MAIN
// =======================================================

void main() {

    if (!InitEmulator())
        return;

    std::thread cpuThread(CPUThread);
    std::thread gpuThread(GPUThread);
    std::thread iosThread(IOSThread);

    // Loop principal (VBlank + input)
    while (g_running) {

        XVideoWaitForVBlank();

        XINPUT_STATE state{};
        if (XInputGetState(0, &state) == ERROR_SUCCESS) {
            if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_BACK) &&
                (state.Gamepad.wButtons & XINPUT_GAMEPAD_START)) {
                g_running = false;
            }
        }
    }

    cpuThread.join();
    gpuThread.join();
    iosThread.join();

    ShutdownEmulator();
}