#include <xtl.h>
#include <stdint.h>
#include <string.h>


#include "FS/config.h"

char gRomPath[256];

void EmulatorInit() {

    if (!LoadRomPath(gRomPath)) {
        // Primeira execução
        OpenFolderBrowser(gRomPath); // sua UI
        SaveRomPath(gRomPath);
    }

    GameBrowser::Scan(gRomPath);
}

#include "UI/game_browser.h"

void EmulatorInit() {
    char romPath[256];

    if (!LoadRomPath(romPath)) {
        OpenFolderBrowser(romPath);
        SaveRomPath(romPath);
    }

    GameBrowser::Scan(romPath);
} =======================================================
// CORE
// =======================================================
#include "core/cpu_core.h"
#include "core/cpu_state.h"
#include "core/wii_interrupts.h"

// =======================================================
// JIT
// =======================================================
#include "cpu/ppc_jit.h"

// =======================================================
// MEMORY / MMU
// =======================================================
#include "memory/mmu.h"
#include "memory/bat.h"
#include "memory/tlb.h"

// =======================================================
// IOS
// =======================================================
#include "ios/ios.h"
#include "ios/fs_fake.h"
#include "ios/es_fake.h"
#include "ios/ipc.h"

// =======================================================
// GPU / GX
// =======================================================
#include "gpu/gx.h"
#include "gpu/gx_fifo.h"
#include "gpu/efb.h"
#include "gpu/xfb.h"

// =======================================================
// PLATFORM
// =======================================================
#include "platform/xbox360/xbox_video.h"
#include "platform/xbox360/xbox_input.h"

// =======================================================

static volatile bool g_running = true;

PPCJIT g_jit;

// =======================================================
// DETECTA JOGO WII EXTRAÍDO
// =======================================================

bool DetectWiiGame(char* outPath) {
    // Exemplo esperado:
    // game:\wii\title\00010000\XXXXXXXX\content\main.dol

    const char* testPath =
        "game:\\wii\\title\\00010000";

    WIN32_FIND_DATA fd;
    HANDLE h = FindFirstFileA(testPath, &fd);

    if (h == INVALID_HANDLE_VALUE)
        return false;

    strcpy(outPath, "game:\\wii");
    FindClose(h);
    return true;
}

// =======================================================
// THREAD DA CPU
// =======================================================

DWORD WINAPI CPUThread(LPVOID) {

    while (g_running) {

        // Executa CPU por “quantum” de ciclos
        CPU::Step(2000);

        // Interrupções
        CPUInterrupts::Handle();

        // Yield cooperativo
        Sleep(0);
    }

    return 0;
}

// =======================================================
// ENTRY POINT (XBOX)
// =======================================================

extern "C" void __cdecl main() {

    char gamePath[256] = {};

    // ------------------------------
    // INIT PLATAFORMA
    // ------------------------------
    XboxVideo_Init();
    XboxInput_Init();

    // ------------------------------
    // INIT CORE
    // ------------------------------
    CPU::Init();
    MMU_Init();
    BAT_Init();
    TLB_Init();

    // ------------------------------
    // INIT IOS
    // ------------------------------
    IOS_Init();
    FS_Init();
    ES_Init();
    IPC_Init();

    // ------------------------------
    // INIT GPU
    // ------------------------------
    GX_Init();
    GXFIFO_Init();
    EFB_Init();
    XFB_Init();

    // ------------------------------
    // DETECTA JOGO
    // ------------------------------
    if (!DetectWiiGame(gamePath)) {
        // Sem jogo → tela preta segura
        while (1) Sleep(1000);
    }

    // Carrega DOL / boot
    IOS_Boot(gamePath);

    // ------------------------------
    // THREAD CPU
    // ------------------------------
    CreateThread(
        NULL,
        0,
        CPUThread,
        NULL,
        0,
        NULL
    );

    // ------------------------------
    // LOOP PRINCIPAL (GPU + INPUT)
    // ------------------------------
    while (g_running) {

        XboxInput_Update();

        // Executa FIFO GX
        GXFIFO_Process();

        // EFB → XFB → tela
        EFB_BlitToXFB();
        XboxVideo_Present();

        Sleep(1);
    }
}