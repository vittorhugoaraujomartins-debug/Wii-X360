#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

enum class IROp {
    ADD, LOAD, STORE, BRANCH
};

struct IRInstr {
    IROp op;
    uint8_t a, b, c;
    int32_t imm;
};