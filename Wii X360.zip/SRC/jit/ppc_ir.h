#pragma once
#include <cstdint>

enum class IROp {
    ADD, LOAD, STORE, BRANCH
};

struct IRInstr {
    IROp op;
    uint8_t a, b, c;
    int32_t imm;
};