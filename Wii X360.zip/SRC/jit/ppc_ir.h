#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

enum class IROp {
    ADD, LOAD, STORE, BRANCH
};

struct IRInstr {
    IROp op;
    uint8_t a, b, c;
    int32_t imm;
};