// PPCDispatch.cpp

#include "ppc_state.h"
#include "ppc_exceptions.h"
#include "ppc_timer.h"
#include "MMU.h"

void PPC_DispatchSingle(PPCState& s)
{
    if (s.pc >= RAM_SIZE)
    {
        PPC_RaiseException(s, EXC_ISI);
        return;
    }

    uint32_t instr = MMU::Read32(s.pc);
    uint8_t op = instr >> 26;

    switch (op)
    {
        case 17: // SC
            PPC_ExecSC(s);
            return;

        default:
            s.pc += 4;
            break;
    }

    PPC_UpdateTimer(s);
}