#include "ppc_jit_core.h"
#include "ppc_jit_block.h"
#include "ppc_jit_cache.h"

namespace JIT {

static bool g_enabled = true;

void Init() {
    JITCache::Init();
}

void Shutdown() {
    JITCache::Shutdown();
}

void Execute(PPCState& state, uint32_t cycles) {
    while (cycles > 0) {
        JITBlock* block = JITCache::GetBlock(state.pc);

        if (!block) {
            block = JITBlock::Compile(state.pc);
            JITCache::Insert(block);
        }

        cycles -= block->Execute(state);
    }
}

void Invalidate(uint32_t addr, uint32_t size) {
    JITCache::InvalidateRange(addr, size);
}

}