#pragma once
#include <cstdint>

struct PPCState;

namespace JIT {

void Init();
void Shutdown();

// Executa a partir do PC atual
void Execute(PPCState& state, uint32_t cycles);

// Marca região como suja (self-modifying code)
void Invalidate(uint32_t addr, uint32_t size);

}