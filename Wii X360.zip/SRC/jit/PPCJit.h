#pragma once
#include <stdint.h>
#include <unordered_map>

struct PPCState;

class PPCBlockCache;

class PPCJIT {
public:
    void Init(PPCState* cpuState);

    // Executa até "cycles" ciclos
    uint32_t Execute(PPCState& state, uint32_t cycles);

private:
    PPCState* cpu = nullptr;
    PPCBlockCache* cache = nullptr;

    void CompileBlock(uint32_t pc);
};