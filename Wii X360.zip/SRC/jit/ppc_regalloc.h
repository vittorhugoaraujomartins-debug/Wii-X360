#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

// Mapeia registradores PPC → host PPC (Xbox 360)
class PPCRegisterAllocator {
public:
    void Reset();

    int AllocGPR(int ppcReg);
    void FreeGPR(int ppcReg);

private:
    int ppcToHost[32];
    bool hostUsed[32];
};