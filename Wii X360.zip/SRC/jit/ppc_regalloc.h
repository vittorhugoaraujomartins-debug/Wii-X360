#pragma once
#include <cstdint>

// Mapeia registradores PPC → host PPC (Xbox 360)
class PPCRegisterAllocator {
public:
    void Reset();

    int AllocGPR(int ppcReg);
    void FreeGPR(int ppcReg);

private:
    int ppcToHost[32];
    bool hostUsed[32];
};