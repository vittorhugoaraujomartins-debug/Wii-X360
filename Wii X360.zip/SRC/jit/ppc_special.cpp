#pragma once
#include <cstdint>

void TranslatePairedSingle(uint32_t instr);
void TranslateSPR(uint32_t instr);
void TranslateCache(uint32_t instr);
void TranslateSystem(uint32_t instr);