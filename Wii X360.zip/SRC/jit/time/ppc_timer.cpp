#include "ppc_exceptions.h"

void PPC_UpdateTimer(PPCState& s)
{
    if (s.dec > 0)
    {
        s.dec--;

        if (s.dec == 0)
            PPC_RaiseException(s, EXC_DECREMENTER);
    }
}