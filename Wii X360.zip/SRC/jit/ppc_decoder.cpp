#include "ppc_decoder.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


bool PPCDecode(uint32_t instr, PPCDecodedInstr& out) {

    uint32_t opcode = instr >> 26;
    out = {};

    switch (opcode) {

    // ADDI
    case 14:
        out.op  = PPC_OP_ADDI;
        out.rd  = (instr >> 21) & 0x1F;
        out.ra  = (instr >> 16) & 0x1F;
        out.imm = (int16_t)(instr & 0xFFFF);
        return true;

    // LWZ
    case 32:
        out.op  = PPC_OP_LWZ;
        out.rd  = (instr >> 21) & 0x1F;
        out.ra  = (instr >> 16) & 0x1F;
        out.imm = (int16_t)(instr & 0xFFFF);
        return true;

    // STW
    case 36:
        out.op  = PPC_OP_STW;
        out.rd  = (instr >> 21) & 0x1F;
        out.ra  = (instr >> 16) & 0x1F;
        out.imm = (int16_t)(instr & 0xFFFF);
        return true;

    // B / BL
    case 18: {
        out.op = (instr & 1) ? PPC_OP_BL : PPC_OP_B;
        int32_t li = (instr & 0x03FFFFFC);
        if (li & 0x02000000) li |= 0xFC000000;
        out.target = li;
        return true;
    }

    default:
        out.op = PPC_OP_INVALID;
        return false;
    }
}