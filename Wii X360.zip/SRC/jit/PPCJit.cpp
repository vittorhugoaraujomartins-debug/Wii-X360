#include "PPCJit.h"
#include "PPCBlockCache.h"
#include "ppc_state.h"
#include "MMU.h"

static PPCBlockCache gBlockCache;

void PPCJIT::Init(PPCState* cpuState) {
    cpu = cpuState;
    cache = &gBlockCache;
}

// ==============================
// EXECUTE
// ==============================

uint32_t PPCJIT::Execute(PPCState& state, uint32_t cycles)
{
    uint32_t executed = 0;

    while (executed < cycles)
    {
        if (state.exception_pending)
        {
            PPC_RaiseException(state, state.pending_exception);
            state.exception_pending = false;
            break;
        }

        uint32_t pc = state.pc;

        JitFunc func = cache->GetBlock(pc);

        if (!func)
        {
            CompileBlock(pc);
            func = cache->GetBlock(pc);
        }

        if (!func)
            break;

        uint32_t used = func(&state, cycles - executed);
        executed += used;

        // Timer update
        PPC_UpdateTimer(state);

        // Interrupção externa?
        if (!(state.msr & 0x8000)) // EE bit
            continue;

        if (state.external_interrupt)
        {
            PPC_RaiseException(state, EXC_EXTERNAL);
            break;
        }
    }

    return executed;
}



// ==============================
// COMPILER (inicial simples)
// ==============================

static uint32_t JitBlockInterpreter(PPCState* state, uint32_t maxCycles) {

    uint32_t cycles = 0;

    while (cycles < maxCycles) {

        uint32_t opcode = MMU::Read32(state->pc);
        uint32_t primary = opcode >> 26;

        switch (primary) {

        case 14: { // addi
            int rD = (opcode >> 21) & 31;
            int rA = (opcode >> 16) & 31;
            int imm = (int16_t)(opcode & 0xFFFF);

            state->gpr[rD] =
                (rA ? state->gpr[rA] : 0) + imm;

            state->pc += 4;
            break;
        }

        case 18: { // branch
            int32_t offset = opcode & 0x03FFFFFC;
            if (offset & 0x02000000)
                offset |= 0xFC000000;

            state->pc += offset;
            cycles++;
            return cycles; // termina bloco
        }

        default:
            state->pc += 4;
            break;
        }

        cycles++;
    }

    return cycles;
}

void PPCJIT::CompileBlock(uint32_t pc) {

    // VERSÃO 1:
    // Por enquanto usa interpretador encapsulado

    cache->AddBlock(pc, JitBlockInterpreter);
}