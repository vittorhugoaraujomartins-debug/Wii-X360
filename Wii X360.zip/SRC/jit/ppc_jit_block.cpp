#include "ppc_jit_block.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


// Execução interpretada por bloco (fallback real)
static uint32_t ExecBlock_Interp(PPCState& state) {

    uint32_t instr = MMU::Read32(state.pc);
    PPCDecodedInstr d;

    if (!PPCDecode(instr, d)) {
        state.pc += 4;
        return 1;
    }

    switch (d.op) {

    case PPC_OP_ADDI:
        state.GPR[d.rd] = (d.ra ? state.GPR[d.ra] : 0) + d.imm;
        state.pc += 4;
        break;

    case PPC_OP_LWZ:
        state.GPR[d.rd] =
            MMU::Read32(state.GPR[d.ra] + d.imm);
        state.pc += 4;
        break;

    case PPC_OP_STW:
        MMU::Write32(
            state.GPR[d.ra] + d.imm,
            state.GPR[d.rd]
        );
        state.pc += 4;
        break;

    case PPC_OP_B:
        state.pc += d.target;
        break;

    case PPC_OP_BL:
        state.LR = state.pc + 4;
        state.pc += d.target;
        break;

    default:
        state.pc += 4;
        break;
    }

    return 1; // ciclos
}

// --------------------------------------------------

JITBlock* CompileJITBlock(uint32_t pc) {

    JITBlock* block = new JITBlock();
    block->startPC = pc;
    block->endPC   = pc + 4; // 1 instr por enquanto
    block->code    = ExecBlock_Interp;

    return block;
}