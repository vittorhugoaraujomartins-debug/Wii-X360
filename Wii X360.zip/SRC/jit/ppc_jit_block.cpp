#include "ppc_jit_block.h"
#include "PowerPC.h"

uint32_t JITBlock::Execute(PPCState& state) {
    execCount++;
    return code(state);
}

JITBlock* JITBlock::Compile(uint32_t pc) {
    JITBlock* block = new JITBlock{};
    block->startPC = pc;
    block->execCount = 0;

    // 🔴 placeholder inicial
    block->code = [](PPCState& s) -> uint32_t {
        // fallback: interpretar algumas instruções
        for (int i = 0; i < 10; i++) {
            PowerPC::Step(s);
        }
        return 10;
    };

    block->endPC = pc + 40;
    return block;
}

#include "ppc_jit_block.h"
#include "ppc_decoder.h"
#include "MemoryManager.h"

JITBlock* JITBlock::Compile(uint32_t pc) {
    JITBlock* block = new JITBlock{};
    block->startPC = pc;
    block->execCount = 0;

    // Captura instruções PPC
    static PPCInstr decoded[64];
    int count = 0;

    uint32_t curPC = pc;

    while (count < 64) {
        uint32_t instr = WiiMem::Read32(curPC);
        decoded[count] = DecodePPC(instr);

        // Fim de bloco
        if (decoded[count].op == PPCOpcode::B)
            break;

        curPC += 4;
        count++;
    }

    block->endPC = curPC;

    // 🔥 Código JITado (interpretação otimizada)
    block->code = [decoded, count](PPCState& s) -> uint32_t {
        for (int i = 0; i < count; i++) {
            const PPCInstr& in = decoded[i];

            switch (in.op) {
            case PPCOpcode::ADDI:
                s.gpr[in.rd] = s.gpr[in.ra] + in.imm;
                break;

            case PPCOpcode::LWZ: {
                uint32_t addr = s.gpr[in.ra] + in.imm;
                s.gpr[in.rd] = WiiMem::Read32(addr);
                break;
            }

            case PPCOpcode::STW: {
                uint32_t addr = s.gpr[in.ra] + in.imm;
                WiiMem::Write32(addr, s.gpr[in.rd]);
                break;
            }

            case PPCOpcode::B:
                s.pc += in.imm;
                return count;
            default:
                break;
            }

            s.pc += 4;
        }
        return count;
    };

    return block;
}


// Após criar block->code

// Linkagem preguiçosa (lazy)
block->linkedNext = nullptr;
block->linkedBranch = nullptr;


PPCRegCache regCache;
regCache.Reset();


uint32_t addr = regCache.Read(in.ra, s.gpr) + in.imm;
uint32_t v = WiiMem::Read32(addr);
regCache.Write(in.rd, v, s.gpr);

regCache.Flush(s.gpr);