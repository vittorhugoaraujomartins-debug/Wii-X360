#include "ppc_jit_cache.h"
#include "ppc_jit_block.h"

static std::unordered_map<uint32_t, JITBlock*> g_blocks;

namespace JITCache {

void Init() {
    g_blocks.clear();
}

void Shutdown() {
    for (auto& it : g_blocks)
        delete it.second;
    g_blocks.clear();
}

JITBlock* GetBlock(uint32_t pc) {
    auto it = g_blocks.find(pc);
    return it != g_blocks.end() ? it->second : nullptr;
}

void Insert(JITBlock* block) {
    g_blocks[block->startPC] = block;
}

void InvalidateRange(uint32_t addr, uint32_t size) {
    for (auto it = g_blocks.begin(); it != g_blocks.end();) {
        if (it->first >= addr && it->first < addr + size) {
            delete it->second;
            it = g_blocks.erase(it);
        } else {
            ++it;
        }
    }
}

}