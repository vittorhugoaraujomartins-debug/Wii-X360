#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

enum PPCOpcode {
    PPC_OP_INVALID = 0,
    PPC_OP_ADD,
    PPC_OP_ADDI,
    PPC_OP_LWZ,
    PPC_OP_STW,
    PPC_OP_B,
    PPC_OP_BL
};

struct PPCDecodedInstr {
    PPCOpcode op;
    uint8_t rd, ra, rb;
    int16_t imm;
    uint32_t target;
};

bool PPCDecode(uint32_t instr, PPCDecodedInstr& out);