#pragma once
#include <cstdint>

enum class PPCOpcode {
    ADD,
    ADDI,
    LWZ,
    STW,
    B,
    BC,
    UNKNOWN
};

struct PPCInstr {
    PPCOpcode op;
    uint8_t rd, ra, rb;
    int32_t imm;
};

PPCInstr DecodePPC(uint32_t instr);