#pragma once
#include <unordered_map>
#include <cstdint>

struct JITBlock;

namespace JITCache {

void Init();
void Shutdown();

JITBlock* GetBlock(uint32_t pc);
void Insert(JITBlock* block);

void InvalidateRange(uint32_t addr, uint32_t size);

}