#pragma once
#include <cstdint>

struct RegCache {
    uint32_t value;
    bool     dirty;
};

class PPCRegCache {
public:
    void Reset();
    uint32_t Read(uint32_t r, uint32_t* gpr);
    void Write(uint32_t r, uint32_t v, uint32_t* gpr);
    void Flush(uint32_t* gpr);

private:
    RegCache regs[32];
};