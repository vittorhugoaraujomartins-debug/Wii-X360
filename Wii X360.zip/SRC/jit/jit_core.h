#pragma once
#include <stdint.h>
namespace JIT{void Init();void ExecuteBlock(uint32_t pc);}
