#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void PPCRegisterAllocator::Reset() {
    memset(ppcToHost, -1, sizeof(ppcToHost));
    memset(hostUsed, 0, sizeof(hostUsed));
}

int PPCRegisterAllocator::AllocGPR(int ppcReg) {

    if (ppcToHost[ppcReg] != -1)
        return ppcToHost[ppcReg];

    for (int i = 3; i < 31; i++) { // pula r0, r1, r2 (ABI)
        if (!hostUsed[i]) {
            hostUsed[i] = true;
            ppcToHost[ppcReg] = i;
            return i;
        }
    }

    // fallback simples (spill fake por enquanto)
    return -1;
}

void PPCRegisterAllocator::FreeGPR(int ppcReg) {

    int h = ppcToHost[ppcReg];
    if (h != -1) {
        hostUsed[h] = false;
        ppcToHost[ppcReg] = -1;
    }
}