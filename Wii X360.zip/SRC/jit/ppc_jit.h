#pragma once
#include <cstdint>
#include <unordered_map>

struct PPCState;

// ================================
// JIT Block
// ================================
struct JITBlock {
    uint32_t startPC;
    uint32_t endPC;
    uint32_t execCount;

    JITBlock* linkedNext;
    JITBlock* linkedBranch;

    using Func = uint32_t(*)(PPCState&);
    Func code;
};

// ================================
// JIT Core
// ================================
class PPCJIT {
public:
    void Init();
    void Shutdown();

    uint32_t Execute(PPCState& state, uint32_t cycles);

    void Invalidate(uint32_t addr, uint32_t size);
    void Flush();

private:
    JITBlock* GetBlock(uint32_t pc);
    JITBlock* CompileBlock(uint32_t pc);

    std::unordered_map<uint32_t, JITBlock*> blockCache;
};