#pragma once
#include <stdint.h>

uint32_t Memory_Read32(uint32_t addr);
void     Memory_Write32(uint32_t addr, uint32_t v);