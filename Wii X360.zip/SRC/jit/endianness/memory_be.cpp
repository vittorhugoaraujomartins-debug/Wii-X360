#include "memory_be.h"

extern uint8_t gMemory[];

uint32_t Memory_Read32(uint32_t addr)
{
    uint32_t* p = (uint32_t*)(gMemory + addr);
    return *p; // já BE
}

void Memory_Write32(uint32_t addr, uint32_t v)
{
    uint32_t* p = (uint32_t*)(gMemory + addr);
    *p = v;
}


#include "ppc_exceptions.h"

uint32_t Memory_Read32(PPCState& s, uint32_t addr)
{
    if (addr >= RAM_SIZE)
    {
        s.dar = addr;
        s.dsisr = 0x40000000; // read violation
        PPC_RaiseException(s, EXC_DSI);
        return 0;
    }

    return *(uint32_t*)(gMemory + addr);
}