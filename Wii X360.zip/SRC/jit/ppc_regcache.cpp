#include "ppc_regcache.h"
#include <cstring>

void PPCRegCache::Reset() {
    memset(regs, 0, sizeof(regs));
}

uint32_t PPCRegCache::Read(uint32_t r, uint32_t* gpr) {
    if (!regs[r].dirty) {
        regs[r].value = gpr[r];
    }
    return regs[r].value;
}

void PPCRegCache::Write(uint32_t r, uint32_t v, uint32_t* gpr) {
    regs[r].value = v;
    regs[r].dirty = true;
}

void PPCRegCache::Flush(uint32_t* gpr) {
    for (int i = 0; i < 32; i++) {
        if (regs[i].dirty) {
            gpr[i] = regs[i].value;
            regs[i].dirty = false;
        }
    }
}