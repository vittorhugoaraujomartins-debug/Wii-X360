#pragma once
#include "ppc_state.h"

void PPC_ExecBranch(PPCState& s, uint32_t instr);
void PPC_ExecBC(PPCState& s, uint32_t instr);
void PPC_ExecBCLR(PPCState& s, uint32_t instr);
void PPC_ExecBCCTR(PPCState& s, uint32_t instr);