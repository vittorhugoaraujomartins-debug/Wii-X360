// ppc_recompile_block.cpp

#include "ppc_recompile_block.h"
#include "ppc_recompile_instr.h"
#include "ppc_decoder.h"
#include "ppc_branch.h"
#include "memory.h"

static void* AllocExecutable(size_t size)
{
    return XPhysicalAlloc(
        size,
        MAXULONG_PTR,
        0,
        PAGE_EXECUTE_READWRITE
    );
}

JitBlock* RecompileBlockAt(uint32_t startPC)
{
    const int MAX_INSTR = 256;

    uint32_t buffer[MAX_INSTR];
    int count = 0;

    uint32_t pc = startPC;

    while (count < MAX_INSTR)
    {
        uint32_t instr = Memory_Read32(pc);
        buffer[count++] = instr;

        if (PPC_IsBranch(instr))
            break;

        pc += 4;
    }

    size_t codeSize = count * sizeof(uint32_t);
    uint32_t* native = (uint32_t*)AllocExecutable(codeSize);

    if (!native)
        return nullptr;

    for (int i = 0; i < count; i++)
    {
        PPCInstr d = DecodePPC(buffer[i]);

        bool supported;
        uint32_t emitted = RecompilePPC(d, supported);

        if (!supported)
        {
            // fallback leve
            emitted = 0x60000000; // nop
        }

        native[i] = emitted;
    }

    JitBlock* block = new JitBlock();
    block->startPC = startPC;
    block->endPC   = pc;
    block->code    = native;
    block->linkTaken = nullptr;
    block->linkFallthrough = nullptr;

    return block;
}


