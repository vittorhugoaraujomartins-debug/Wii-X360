#pragma once
#include <stdint.h>

typedef void (*RecompiledFunc)();

void Recompiler_Init();
void Recompiler_Reset();

void ExecuteBlock(uint32_t wiiPC);

// Interface opcional
void* LookupRecompiled(uint32_t pc);
void  RegisterBlock(uint32_t pc, void* code);