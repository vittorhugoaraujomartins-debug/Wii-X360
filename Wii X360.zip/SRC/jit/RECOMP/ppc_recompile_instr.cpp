// ppc_recompile_instr.cpp

#include "ppc_recompile_instr.h"

uint32_t RecompilePPC(const PPCInstr& i, bool& supported)
{
    supported = true;

    switch (i.opcode)
    {
        // ADDI
        case 14:
        case 15: // ADDIS
            return i.raw;

        // LOAD
        case 32: // LWZ
        case 33: // LWZU
        case 34: // LBZ
        case 35: // LBZU
        case 40: // LHZ
        case 41: // LHZU
            return i.raw;

        // STORE
        case 36: // STW
        case 37: // STWU
        case 38: // STB
        case 39: // STBU
        case 44: // STH
        case 45: // STHU
            return i.raw;

        // INTEGER EXTENDED
        case 31:
        {
            switch (i.xo)
            {
                case 266: // add
                case 40:  // subf
                case 28:  // and
                case 444: // or
                case 316: // xor
                case 235: // mullw
                case 491: // divw
                case 24:  // slw
                case 536: // srw
                case 792: // sraw
                case 339: // mfcr
                case 467: // mtcrf
                case 19:  // mflr
                case 467: // mtlr
                    return i.raw;

                default:
                    supported = false;
                    return 0x60000000;
            }
        }

        // BRANCH handled outside
        case 18:
        case 16:
        case 19:
            supported = false;
            return 0;

        // FPU
        case 59:
        case 63:
            return i.raw;

        // Paired Single
        case 4:
            return i.raw;

        default:
            supported = false;
            return 0x60000000;
    }
}



