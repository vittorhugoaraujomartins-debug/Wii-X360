// Recompiler.cpp

#include "ppc_recompiler.h"
#include "ppc_recompile_block.h"
#include "memory.h"

#include <xtl.h>
#include <unordered_map>

struct JitBlock
{
    uint32_t startPC;
    uint32_t endPC;
    void*    code;

    JitBlock* linkTaken;
    JitBlock* linkFallthrough;
};

static std::unordered_map<uint32_t, JitBlock*> gBlocks;

static void* AllocExecutable(size_t size)
{
    return XPhysicalAlloc(
        size,
        MAXULONG_PTR,
        0,
        PAGE_EXECUTE_READWRITE
    );
}

void Recompiler_Init()
{
    gBlocks.clear();
}

void Recompiler_Reset()
{
    for (auto& it : gBlocks)
        XPhysicalFree(it.second->code);

    gBlocks.clear();
}

JitBlock* LookupBlock(uint32_t pc)
{
    auto it = gBlocks.find(pc);
    if (it != gBlocks.end())
        return it->second;

    return nullptr;
}

void RegisterBlock(JitBlock* block)
{
    gBlocks[block->startPC] = block;
}


void ExecuteBlock(uint32_t wiiPC)
{
    JitBlock* block = LookupBlock(wiiPC);

    if (!block)
    {
        block = RecompileBlockAt(wiiPC);
        if (!block)
            return;

        RegisterBlock(block);
    }

    ((RecompiledFunc)block->code)();
}



