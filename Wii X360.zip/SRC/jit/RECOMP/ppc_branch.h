#pragma once
#include <stdint.h>

inline bool PPC_IsBranch(uint32_t instr)
{
    uint8_t op = instr >> 26;

    return (op == 18) || // b / bl
           (op == 16);   // bc
}