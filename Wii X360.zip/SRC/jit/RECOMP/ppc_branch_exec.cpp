#include "ppc_branch_exec.h"

static inline int32_t SignExtend26(uint32_t v)
{
    return (int32_t)(v << 6) >> 6;
}

// ==========================================
// B / BL
// ==========================================

void PPC_ExecBranch(PPCState& s, uint32_t instr)
{
    int32_t offset = SignExtend26(instr & 0x03FFFFFC);

    bool link = instr & 1;
    bool abs  = instr & 2;

    uint32_t target =
        abs ? offset : (s.pc + offset);

    if (link)
        s.lr = s.pc + 4;

    s.pc = target;
}

// ==========================================
// BC (branch cond)
// ==========================================

void PPC_ExecBC(PPCState& s, uint32_t instr)
{
    uint32_t bo = (instr >> 21) & 0x1F;
    uint32_t bi = (instr >> 16) & 0x1F;

    int16_t bd = instr & 0xFFFC;
    int32_t offset = (int16_t)bd;

    bool cond = (s.cr >> (31 - bi)) & 1;

    bool take =
        (bo & 0x10) ||            // ignore CR
        (cond == !(bo & 8));      // CR match

    if (!(bo & 4)) // CTR decrement
    {
        s.ctr--;
        if (s.ctr == 0)
            take = false;
    }

    if (take)
        s.pc += offset;
    else
        s.pc += 4;
}

// ==========================================
// BCLR
// ==========================================

void PPC_ExecBCLR(PPCState& s, uint32_t instr)
{
    uint32_t bo = (instr >> 21) & 0x1F;
    uint32_t bi = (instr >> 16) & 0x1F;

    bool cond = (s.cr >> (31 - bi)) & 1;

    bool take =
        (bo & 0x10) ||
        (cond == !(bo & 8));

    if (!(bo & 4))
    {
        s.ctr--;
        if (s.ctr == 0)
            take = false;
    }

    if (take)
        s.pc = s.lr;
    else
        s.pc += 4;
}

// ==========================================
// BCCTR
// ==========================================

void PPC_ExecBCCTR(PPCState& s, uint32_t instr)
{
    uint32_t bo = (instr >> 21) & 0x1F;
    uint32_t bi = (instr >> 16) & 0x1F;

    bool cond = (s.cr >> (31 - bi)) & 1;

    bool take =
        (bo & 0x10) ||
        (cond == !(bo & 8));

    if (take)
        s.pc = s.ctr;
    else
        s.pc += 4;
}