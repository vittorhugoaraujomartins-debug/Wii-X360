#pragma once
#include <stdint.h>

void* RecompileBlockAt(uint32_t wiiPC);