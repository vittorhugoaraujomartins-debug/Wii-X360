#

#pragma once
#include <stdint.h>

struct PPCState
{
    uint32_t gpr[32];

    uint32_t pc;

    // Special registers
    uint32_t lr;
    uint32_t ctr;
    uint32_t cr;
    uint32_t xer;

    // MSR — Machine State Register
    uint32_t msr;

    // Save/Restore regs
    uint32_t srr0;
    uint32_t srr1;

    // Exception registers
    uint32_t dar;   // Data Address Register
    uint32_t dsisr; // DSI status

    // Timer
    uint32_t dec;

    bool exception_pending;
};