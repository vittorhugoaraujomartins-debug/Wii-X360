#pragma once
#include "ppc_decoder.h"

uint32_t RecompilePPC(const PPCInstr& i, bool& supported);