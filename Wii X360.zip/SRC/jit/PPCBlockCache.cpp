#include "PPCBlockCache.h"

void PPCBlockCache::AddBlock(uint32_t pc, JitFunc func) {
    PPCBlock b;
    b.startPC = pc;
    b.func = func;
    blocks[pc] = b;
}

JitFunc PPCBlockCache::GetBlock(uint32_t pc) {
    auto it = blocks.find(pc);
    if (it != blocks.end())
        return it->second.func;
    return nullptr;
}

void PPCBlockCache::Invalidate(uint32_t pc) {
    blocks.erase(pc);
}


static uint32_t JitBlockInterpreter(PPCState* state, uint32_t maxCycles)
{
    uint32_t cycles = 0;

    while (cycles < maxCycles)
    {
        if (state->exception_pending)
            break;

        uint32_t opcode = MMU::Read32(state->pc);
        uint32_t primary = opcode >> 26;

        switch (primary)
        {
            // =========================
            // ADDI
            // =========================
            case 14:
            {
                int rD = (opcode >> 21) & 31;
                int rA = (opcode >> 16) & 31;
                int imm = (int16_t)(opcode & 0xFFFF);

                uint32_t a = (rA ? state->gpr[rA] : 0);
                state->gpr[rD] = a + imm;

                state->pc += 4;
                break;
            }

            // =========================
            // BRANCH
            // =========================
            case 18:
            {
                int32_t offset = opcode & 0x03FFFFFC;

                if (offset & 0x02000000)
                    offset |= 0xFC000000;

                state->pc += offset;
                cycles++;
                return cycles;
            }

            // =========================
            // SYSCALL
            // =========================
            case 17:
            {
                PPC_ExecSC(*state);
                cycles++;
                return cycles;
            }

            default:
                state->pc += 4;
                break;
        }

        cycles++;
    }

    return cycles;
}


// PPCBlockOptimizer.cpp

#include "PPCBlockCache.h"
#include <unordered_map>

static std::unordered_map<uint32_t, int> blockHits;

void RegisterBlockHit(uint32_t pc)
{
    blockHits[pc]++;
}

bool IsHotBlock(uint32_t pc)
{
    return blockHits[pc] > 20;
}


RegisterBlockHit(pc);

if (IsHotBlock(pc))
{
    // futura otimização agressiva
}



