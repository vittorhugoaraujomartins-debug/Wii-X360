#pragma once
#include <cstdint>

namespace JITRegAlloc {

void Reset();
int MapGPR(uint32_t ppcReg);
void Flush();

}