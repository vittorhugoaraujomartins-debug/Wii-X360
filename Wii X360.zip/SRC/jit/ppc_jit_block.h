#pragma once
#include <cstdint>

struct PPCState;

// ================================
// Decoder simples
// ================================
enum class PPCOpcode {
    ADDI,
    LWZ,
    STW,
    B,
    UNKNOWN
};

struct PPCInstr {
    PPCOpcode op;
    uint8_t rd, ra;
    int32_t imm;
};

PPCInstr DecodePPC(uint32_t instr);

// ================================
// Block compiler
// ================================
uint32_t ExecuteInterpreted(PPCState& state);