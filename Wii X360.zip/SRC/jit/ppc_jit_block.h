#pragma once
#include <cstdint>

struct PPCState;

struct JITBlock {
    uint32_t startPC;
    uint32_t endPC;
    uint32_t execCount;

    using Func = uint32_t(*)(PPCState&);
    Func code;

    uint32_t Execute(PPCState& state);
    static JITBlock* Compile(uint32_t pc);
};

struct JITBlock {
    uint32_t startPC;
    uint32_t endPC;
    uint32_t execCount;

    JITBlock* linkedNext = nullptr;
    JITBlock* linkedBranch = nullptr;

    uint32_t (*code)(PPCState&);
};