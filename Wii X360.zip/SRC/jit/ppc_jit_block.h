#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct PPCState;

struct JITBlock {
    uint32_t startPC;
    uint32_t endPC;
    uint32_t execCount = 0;

    JITBlock* linkedNext = nullptr;

    using ExecFn = uint32_t(*)(PPCState&);
    ExecFn code = nullptr;
};