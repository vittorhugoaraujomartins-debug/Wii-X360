#include "ppc_jit_regalloc.h"

static int g_map[32];

namespace JITRegAlloc {

void Reset() {
    for (int i = 0; i < 32; i++)
        g_map[i] = -1;
}

int MapGPR(uint32_t ppcReg) {
    if (g_map[ppcReg] != -1)
        return g_map[ppcReg];

    // placeholder: map 1:1
    g_map[ppcReg] = ppcReg;
    return g_map[ppcReg];
}

void Flush() {
    Reset();
}

}