// ppc_spr.cpp

#include "ppc_state.h"

static inline uint32_t DecodeSPR(uint32_t instr)
{
    return ((instr >> 16) & 0x1F) |
           ((instr >> 6) & 0x3E0);
}

void PPC_ExecSPR(PPCState& s, uint32_t instr)
{
    uint32_t spr = DecodeSPR(instr);
    bool write = instr & (1 << 20);

    uint32_t rs = (instr >> 21) & 0x1F;

    if (write)
    {
        switch (spr)
        {
            case 1:  s.xer = s.gpr[rs]; break;
            case 8:  s.lr  = s.gpr[rs]; break;
            case 9:  s.ctr = s.gpr[rs]; break;
            case 268: s.dec = s.gpr[rs]; break;
        }
    }
    else
    {
        switch (spr)
        {
            case 1:  s.gpr[rs] = s.xer; break;
            case 8:  s.gpr[rs] = s.lr;  break;
            case 9:  s.gpr[rs] = s.ctr; break;
            case 268: s.gpr[rs] = s.dec; break;
            case 287: s.gpr[rs] = 0x00083214; break; // Fake 750CL ID
        }
    }
}