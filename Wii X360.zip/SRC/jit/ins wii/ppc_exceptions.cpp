// ppc_ps_exec.cpp

#include "ppc_state.h"

static inline int RD(uint32_t i) { return (i >> 21) & 0x1F; }
static inline int RA(uint32_t i) { return (i >> 16) & 0x1F; }
static inline int RB(uint32_t i) { return (i >> 11) & 0x1F; }

void PPC_ExecPS(PPCState& s, uint32_t instr)
{
    uint32_t op = (instr >> 1) & 0x1F;

    int rd = RD(instr);
    int ra = RA(instr);
    int rb = RB(instr);

    switch (op)
    {
        case 21: // ps_add
            s.ps[rd][0] = s.ps[ra][0] + s.ps[rb][0];
            s.ps[rd][1] = s.ps[ra][1] + s.ps[rb][1];
            break;

        case 20: // ps_sub
            s.ps[rd][0] = s.ps[ra][0] - s.ps[rb][0];
            s.ps[rd][1] = s.ps[ra][1] - s.ps[rb][1];
            break;

        case 18: // ps_mul
            s.ps[rd][0] = s.ps[ra][0] * s.ps[rb][0];
            s.ps[rd][1] = s.ps[ra][1] * s.ps[rb][1];
            break;

        case 28: // ps_madd
            s.ps[rd][0] += s.ps[ra][0] * s.ps[rb][0];
            s.ps[rd][1] += s.ps[ra][1] * s.ps[rb][1];
            break;

        default:
            break;
    }
}


void PPC_RaiseException(PPCState& s, PPCException type)
{
    s.srr0 = s.pc;
    s.srr1 = s.msr;

    // Clear EE (External Interrupt Enable)
    s.msr &= ~0x8000;

    // Clear IR/DR se necessário
    s.msr &= ~(0x20 | 0x10);

    s.pc = GetVector(type);

    s.exception_pending = false;
}


void PPC_Tick(PPCState& s)
{
    if (s.dec > 0)
    {
        s.dec--;
        if (s.dec == 0)
        {
            PPC_RaiseException(s, EXC_DECREMENTER);
        }
    }
}


