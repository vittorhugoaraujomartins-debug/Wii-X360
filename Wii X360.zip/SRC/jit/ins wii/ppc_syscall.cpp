#include "ppc_exceptions.h"

void PPC_ExecSC(PPCState& s)
{
    PPC_RaiseException(s, EXC_SYSCALL);
}