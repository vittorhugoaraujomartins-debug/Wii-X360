#pragma once
#include "ppc_state.h"

enum PPCException
{
    EXC_DSI,
    EXC_ISI,
    EXC_PROGRAM,
    EXC_EXTERNAL,
    EXC_DECREMENTER,
    EXC_SYSCALL
};

void PPC_RaiseException(PPCState& s, PPCException type);