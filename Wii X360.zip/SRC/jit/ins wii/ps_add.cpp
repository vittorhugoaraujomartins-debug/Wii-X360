#include <cstdio>

void TranslatePairedSingle(uint32_t instr)
{
    uint32_t op = (instr >> 1) & 0x1F;

    switch (op)
    {
        case 21: // ps_add
            printf("Translate ps_add\n");
            // TODO: emitir código VMX
            break;

        case 18: // ps_mul
            printf("Translate ps_mul\n");
            break;

        case 20: // ps_sub
            printf("Translate ps_sub\n");
            break;

        case 28: // ps_madd
            printf("Translate ps_madd\n");
            break;

        default:
            printf("Unknown PS instruction\n");
            break;
    }
}