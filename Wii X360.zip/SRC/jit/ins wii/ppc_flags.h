#pragma once
#include "ppc_state.h"

void PPC_SetCR0(PPCState& s, int32_t result);
void PPC_UpdateXER_OV(PPCState& s, bool overflow);