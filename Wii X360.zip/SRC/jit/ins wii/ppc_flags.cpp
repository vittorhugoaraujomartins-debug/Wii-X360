// ppc_flags.cpp

#include "ppc_flags.h"

// Atualiza campo específico do CR (0–7)
void PPC_SetCRField(PPCState& s, int field, int32_t result)
{
    uint32_t mask = 0xF << ((7 - field) * 4);
    uint32_t newField = 0;

    if (result < 0)  newField |= 0x8; // LT
    if (result > 0)  newField |= 0x4; // GT
    if (result == 0) newField |= 0x2; // EQ

    // SO vem do XER
    if (s.xer & 0x80000000)
        newField |= 0x1;

    s.cr = (s.cr & ~mask) |
           (newField << ((7 - field) * 4));
}

// XER completo
void PPC_UpdateXER(PPCState& s, bool overflow, bool carry)
{
    if (overflow)
    {
        s.xer |= 0x40000000; // OV
        s.xer |= 0x80000000; // SO (sticky)
    }

    if (carry)
        s.xer |= 0x20000000; // CA
}