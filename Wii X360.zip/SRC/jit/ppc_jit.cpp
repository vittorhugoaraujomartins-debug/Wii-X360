#include "ppc_jit.h"
#include "MMU.h"
#include "InstructionOrder.h"

static const int MAX_BLOCK_INSTR = 64;

void PPCJIT::Init() {
    blockCache.clear();
}

void PPCJIT::Shutdown() {
    Flush();
}

void PPCJIT::Flush() {
    for (auto& it : blockCache)
        delete it.second;
    blockCache.clear();
}

void PPCJIT::Invalidate(uint32_t addr, uint32_t size) {
    uint32_t end = addr + size;
    for (auto it = blockCache.begin(); it != blockCache.end();) {
        if (it->first >= addr && it->first < end) {
            delete it->second;
            it = blockCache.erase(it);
        } else {
            ++it;
        }
    }
}

JITBlock* PPCJIT::GetBlock(uint32_t pc) {
    auto it = blockCache.find(pc);
    if (it != blockCache.end())
        return it->second;

    JITBlock* block = CompileBlock(pc);
    blockCache[pc] = block;
    return block;
}

uint32_t PPCJIT::Execute(PPCState& state, uint32_t cycles) {
    while (cycles > 0) {
        JITBlock* block = GetBlock(state.pc);
        block->execCount++;

        cycles -= block->code(state);

        // 🔗 Block Linking
        if (block->linkedNext && state.pc == block->endPC) {
            block = block->linkedNext;
        } else if (!block->linkedNext) {
            block->linkedNext = GetBlock(state.pc);
        }
    }
    return cycles;
}