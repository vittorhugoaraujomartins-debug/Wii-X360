#include "ppc_jit.h"
#include "MMU.h"
#include "InstructionOrder.h"

static const int MAX_BLOCK_INSTR = 64;

void PPCJIT::Init() {
    blockCache.clear();
}

void PPCJIT::Shutdown() {
    Flush();
}

void PPCJIT::Flush() {
    for (auto& it : blockCache)
        delete it.second;
    blockCache.clear();
}

void PPCJIT::Invalidate(uint32_t addr, uint32_t size) {
    uint32_t end = addr + size;
    for (auto it = blockCache.begin(); it != blockCache.end();) {
        if (it->first >= addr && it->first < end) {
            delete it->second;
            it = blockCache.erase(it);
        } else {
            ++it;
        }
    }
}

JITBlock* PPCJIT::GetBlock(uint32_t pc) {
    auto it = blockCache.find(pc);
    if (it != blockCache.end())
        return it->second;

    JITBlock* block = CompileBlock(pc);
    blockCache[pc] = block;
    return block;
}

uint32_t PPCJIT::Execute(PPCState& state, uint32_t cycles) {
    while (cycles > 0) {
        JITBlock* block = GetBlock(state.pc);
        block->execCount++;

        cycles -= block->code(state);

        // 🔗 Block Linking
        if (block->linkedNext && state.pc == block->endPC) {
            block = block->linkedNext;
        } else if (!block->linkedNext) {
            block->linkedNext = GetBlock(state.pc);
        }
    }
    return cycles;
}



#include "ppc_jit.h"
#include "cpu_state.h"
#include "memory.h"
#include <unordered_map>

namespace PPCJIT {

struct JitBlock {
    uint32_t start;
    uint32_t size;
    void (*func)();
};

static std::unordered_map<uint32_t, JitBlock*> blockCache;

static JitBlock* CompileBlock(uint32_t pc);

// ----------------------------------------------------

void Init() {
    blockCache.clear();
}

void Shutdown() {
    FlushCache();
}

// ----------------------------------------------------

void Run() {

    uint32_t pc = gCPU.PC;

    auto it = blockCache.find(pc);
    if (it != blockCache.end()) {
        it->second->func();
        return;
    }

    JitBlock* block = CompileBlock(pc);
    if (!block) return;

    blockCache[pc] = block;
    block->func();
}

// ----------------------------------------------------

void InvalidateRange(uint32_t addr, uint32_t size) {

    uint32_t end = addr + size;

    for (auto it = blockCache.begin(); it != blockCache.end(); ) {
        uint32_t bStart = it->second->start;
        uint32_t bEnd   = bStart + it->second->size;

        if (!(end <= bStart || addr >= bEnd)) {
            delete it->second;
            it = blockCache.erase(it);
        } else {
            ++it;
        }
    }
}

// ----------------------------------------------------

void FlushCache() {
    for (auto& it : blockCache)
        delete it.second;

    blockCache.clear();
}


static void DummyExecutor() {
    // fallback temporário
    gCPU.PC += 4;
}

static JitBlock* CompileBlock(uint32_t pc) {

    JitBlock* block = new JitBlock();
    block->start = pc;
    block->size  = 4; // por enquanto 1 instrução
    block->func  = DummyExecutor;

    return block;
}

}