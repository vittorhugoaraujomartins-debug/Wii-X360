#include "ppc_jit.h"
#include "ppc_jit_block.h"

void PPCJIT::Init() {
    blockCache.clear();
}

void PPCJIT::Shutdown() {
    Flush();
}

void PPCJIT::Flush() {
    for (auto& it : blockCache)
        delete it.second;
    blockCache.clear();
}

void PPCJIT::Invalidate(uint32_t addr, uint32_t size) {
    uint32_t end = addr + size;

    for (auto it = blockCache.begin(); it != blockCache.end();) {
        uint32_t pc = it->first;
        if (pc >= addr && pc < end) {
            delete it->second;
            it = blockCache.erase(it);
        } else {
            ++it;
        }
    }
}

JITBlock* PPCJIT::GetBlock(uint32_t pc) {

    auto it = blockCache.find(pc);
    if (it != blockCache.end())
        return it->second;

    JITBlock* block = CompileJITBlock(pc);
    blockCache[pc] = block;
    return block;
}

uint32_t PPCJIT::Execute(PPCState& state, uint32_t cycles) {

    while (cycles > 0) {

        JITBlock* block = GetBlock(state.pc);
        block->execCount++;

        cycles -= block->code(state);

        // 🔗 block linking
        if (block->linkedNext &&
            state.pc == block->endPC) {

            block = block->linkedNext;

        } else if (!block->linkedNext) {
            block->linkedNext = GetBlock(state.pc);
        }
    }

    return cycles;
}