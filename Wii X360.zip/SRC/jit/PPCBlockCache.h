#pragma once
#include <stdint.h>
#include <unordered_map>

struct PPCState;

using JitFunc = uint32_t(*)(PPCState*, uint32_t);

struct PPCBlock {
    uint32_t startPC;
    JitFunc  func;
};

class PPCBlockCache {
public:
    void AddBlock(uint32_t pc, JitFunc func);
    JitFunc GetBlock(uint32_t pc);
    void Invalidate(uint32_t pc);

private:
    std::unordered_map<uint32_t, PPCBlock> blocks;
};