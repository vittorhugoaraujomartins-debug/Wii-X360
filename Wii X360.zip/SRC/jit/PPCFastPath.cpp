// PPCFastPath.cpp

#include "ppc_state.h"
#include "MMU.h"

inline void ExecFastAddi(PPCState* s, uint32_t op)
{
    int rD = (op >> 21) & 31;
    int rA = (op >> 16) & 31;
    int imm = (int16_t)(op & 0xFFFF);

    s->gpr[rD] = (rA ? s->gpr[rA] : 0) + imm;
}

inline bool ExecFastBranch(PPCState* s, uint32_t op)
{
    int32_t offset = op & 0x03FFFFFC;
    if (offset & 0x02000000)
        offset |= 0xFC000000;

    s->pc += offset;
    return true;
}

void ExecuteFast(PPCState* s)
{
    uint32_t op = MMU::Read32(s, s->pc);
    uint32_t primary = op >> 26;

    switch (primary)
    {
        case 14: ExecFastAddi(s, op); s->pc += 4; break;
        case 18: if (ExecFastBranch(s, op)) return; break;
        default: s->pc += 4; break;
    }
}