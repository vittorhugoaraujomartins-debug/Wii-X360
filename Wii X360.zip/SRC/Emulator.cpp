
#include "Emulator.h"
#include <cstdio>

bool Emulator::Init() {
    running = true;
    printf("Wii Emulator (Xbox 360 native CPU/GPU) init\n");
    return true;
}

void Emulator::Step() {
    // HLE approach:
    // Wii logic mapped directly to Xbox 360 Xenon CPU
}

void Emulator::Shutdown() {
    running = false;
    printf("Shutdown\n");
}

bool Emulator::Running() const {
    return running;
}

bool Emulator::Boot() {
    memory.Init();
    cpu.Reset();
    cpu.SetPC(0x80003100);
    cpu.SetRegister(1, 0x817FFFC0);
    cpu.SetRegister(2, 0x80000000);
    cpu.SetRegister(13, 0x80000000);
    return true;
}
