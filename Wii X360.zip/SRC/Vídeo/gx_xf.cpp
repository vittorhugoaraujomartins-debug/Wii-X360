#include "gx_xf.h"
#include <xgraphics.h>
#include <cstring>

static float g_matrices[64][16];

namespace GXXF {

void LoadMatrix(uint32_t index, const float* mtx) {
    if (index >= 64 || !mtx)
        return;

    memcpy(g_matrices[index], mtx, sizeof(float) * 16);
}

void Apply() {
    IDirect3DDevice9* dev = Direct3D_GetDevice();
    if (!dev) return;

    D3DXMATRIX world, view, proj;

    memcpy(&world, g_matrices[XF_WORLD], sizeof(D3DXMATRIX));
    memcpy(&view,  g_matrices[XF_VIEW],  sizeof(D3DXMATRIX));
    memcpy(&proj,  g_matrices[XF_PROJ],  sizeof(D3DXMATRIX));

    dev->SetTransform(D3DTS_WORLD,      &world);
    dev->SetTransform(D3DTS_VIEW,       &view);
    dev->SetTransform(D3DTS_PROJECTION, &proj);
}

}

// ================================
// LoD via XF (barato e seguro)
// ================================

static float g_lodFactor = 1.0f;

void SetLoDFactor(float f) {
    g_lodFactor = f;
}

void ApplyLoDToMatrix() {
    IDirect3DDevice9* dev = Direct3D_GetDevice();
    if (!dev) return;

    D3DXMATRIX mat;
    memcpy(&mat, g_matrices[0], sizeof(mat));

    mat._11 *= g_lodFactor;
    mat._22 *= g_lodFactor;
    mat._33 *= g_lodFactor;

    dev->SetTransform(D3DTS_WORLD, &mat);
}