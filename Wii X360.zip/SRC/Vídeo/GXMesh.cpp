#include "GXMesh.h"
#include <unordered_set>
#include <cmath>

static inline uint64_t HashVertex(const GXVertex& v) {
    // quantização simples (evita float impreciso)
    int x = (int)(v.x * 1000.0f);
    int y = (int)(v.y * 1000.0f);
    int z = (int)(v.z * 1000.0f);

    return ((uint64_t)(x & 0x1FFFFF) << 42) |
           ((uint64_t)(y & 0x1FFFFF) << 21) |
           ((uint64_t)(z & 0x1FFFFF));
}

void OptimizeGreedyMesh(std::vector<GXVertex>& vertices) {
    if (vertices.size() < 6)
        return;

    // 1️⃣ Remover vértices duplicados (rápido com hash)
    std::unordered_set<uint64_t> seen;
    std::vector<GXVertex> unique;
    unique.reserve(vertices.size());

    for (const auto& v : vertices) {
        uint64_t h = HashVertex(v);
        if (seen.insert(h).second)
            unique.push_back(v);
    }

    vertices.swap(unique);

    // 2️⃣ Agrupar superfícies coplanares simples (axis-aligned)
    std::vector<GXVertex> greedy;
    greedy.reserve(vertices.size());

    const float EPS = 0.0001f;

    for (size_t i = 0; i < vertices.size(); i++) {
        const GXVertex& v = vertices[i];
        bool merged = false;

        for (auto& g : greedy) {
            // Mesma face no eixo Z (exemplo comum em voxel)
            if (fabs(v.z - g.z) < EPS &&
                fabs(v.y - g.y) < EPS &&
                fabs(v.x - g.x) < EPS) {
                merged = true;
                break;
            }
        }

        if (!merged)
            greedy.push_back(v);
    }

    vertices.swap(greedy);
}

void OptimizeGreedyMesh(std::vector<GXVertex>& vertices) {
    if (vertices.size() < 6)
        return;

    std::vector<GXVertex> optimized;
    optimized.reserve(vertices.size());

    for (size_t i = 0; i < vertices.size(); i++) {
        const GXVertex& v = vertices[i];

        bool duplicate = false;
        for (auto& o : optimized) {
            if (fabs(v.x - o.x) < 0.0001f &&
                fabs(v.y - o.y) < 0.0001f &&
                fabs(v.z - o.z) < 0.0001f) {
                duplicate = true;
                break;
            }
        }

        if (!duplicate)
            optimized.push_back(v);
    }

    vertices.swap(optimized);
}