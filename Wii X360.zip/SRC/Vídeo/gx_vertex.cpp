#include "gx_vertex.h"
#include <xgraphics.h>

namespace GXVertex {

static IDirect3DVertexDeclaration9* g_decl = nullptr;

void Init() {
    IDirect3DDevice9* dev = Direct3D_GetDevice();
    if (!dev || g_decl) return;

    static const D3DVERTEXELEMENT9 layout[] = {
        {0, 0,  D3DDECLTYPE_FLOAT3,    D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION, 0},
        {0, 12, D3DDECLTYPE_FLOAT3,    D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_NORMAL,   0},
        {0, 24, D3DDECLTYPE_FLOAT2,    D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD, 0},
        {0, 32, D3DDECLTYPE_D3DCOLOR,  D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR,    0},
        D3DDECL_END()
    };

    dev->CreateVertexDeclaration(layout, &g_decl);
}

void Shutdown() {
    if (g_decl) {
        g_decl->Release();
        g_decl = nullptr;
    }
}

void ApplyLayout() {
    if (!g_decl) Init();

    IDirect3DDevice9* dev = Direct3D_GetDevice();
    if (!dev || !g_decl) return;

    dev->SetVertexDeclaration(g_decl);
}

}