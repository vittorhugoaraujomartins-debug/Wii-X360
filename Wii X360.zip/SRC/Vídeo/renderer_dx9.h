#pragma once
#include <cstdint>

namespace RendererDX9 {
    void Init();
    void OnBPWrite(uint8_t reg, uint32_t value);
    void Draw();
}