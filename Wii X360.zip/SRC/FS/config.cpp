#include <stdio.h>
#include <string.h>
#include "config.h"

bool LoadRomPath(char* outPath) {
    FILE* f = fopen(CONFIG_PATH, "rb");
    if (!f)
        return false;

    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (strncmp(line, "rom_path=", 9) == 0) {
            strcpy(outPath, line + 9);

            size_t len = strlen(outPath);
            if (len && outPath[len - 1] == '\n')
                outPath[len - 1] = 0;

            fclose(f);
            return true;
        }
    }

    fclose(f);
    return false;
}

void SaveRomPath(const char* path) {
    FILE* f = fopen(CONFIG_PATH, "wb");
    if (!f)
        return;

    fprintf(f, "rom_path=%s\n", path);
    fclose(f);
}