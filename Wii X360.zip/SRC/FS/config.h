#pragma once

#define CONFIG_PATH "Hdd1:\\WiiX360\\config.cfg"

bool LoadRomPath(char* outPath);
void SaveRomPath(const char* path);