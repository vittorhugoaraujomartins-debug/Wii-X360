#include "game_browser.h"
#include <stdio.h>
#include <string.h>

static GameEntry gGames[MAX_GAMES];
static int gGameCount = 0;

int GameBrowser::GetGameCount() {
    return gGameCount;
}

GameEntry* GameBrowser::GetGame(int index) {
    if (index < 0 || index >= gGameCount)
        return NULL;
    return &gGames[index];
}

void GameBrowser::Scan(const char* rootPath) {
    gGameCount = 0;
    ScanDirectory(rootPath);
}

void GameBrowser::ScanDirectory(const char* path) {
    if (gGameCount >= MAX_GAMES)
        return;

    char searchPath[MAX_PATH_LEN];
    snprintf(searchPath, sizeof(searchPath), "%s\\*", path);

    WIN32_FIND_DATAA ffd;
    HANDLE hFind = FindFirstFileA(searchPath, &ffd);
    if (hFind == INVALID_HANDLE_VALUE)
        return;

    do {
        if (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
            if (strcmp(ffd.cFileName, ".") == 0 ||
                strcmp(ffd.cFileName, "..") == 0)
                continue;

            char subPath[MAX_PATH_LEN];
            snprintf(subPath, sizeof(subPath), "%s\\%s", path, ffd.cFileName);

            // Procura main.dol
            char dolPath[MAX_PATH_LEN];
            snprintf(dolPath, sizeof(dolPath), "%s\\main.dol", subPath);

            FILE* f = fopen(dolPath, "rb");
            if (f && gGameCount < MAX_GAMES) {
                fclose(f);

                strncpy(gGames[gGameCount].name, ffd.cFileName, sizeof(gGames[gGameCount].name) - 1);
                strncpy(gGames[gGameCount].path, dolPath, sizeof(gGames[gGameCount].path) - 1);
                gGameCount++;
            } else if (f) {
                fclose(f);
            }

            // Continua buscando subpastas
            ScanDirectory(subPath);
        }
    } while (FindNextFileA(hFind, &ffd));

    FindClose(hFind);
}