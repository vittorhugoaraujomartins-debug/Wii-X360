#pragma once
#include <xtl.h>

#define MAX_GAMES 256
#define MAX_PATH_LEN 260

struct GameEntry {
    char name[64];
    char path[MAX_PATH_LEN];
};

class GameBrowser {
public:
    static void Scan(const char* rootPath);
    static int  GetGameCount();
    static GameEntry* GetGame(int index);

private:
    static void ScanDirectory(const char* path);
};