
#pragma once

#include <stdint.h>

#ifdef _XBOX
#include <xtl.h>
#endif

namespace IO
{
    // Botões do Wii (subset inicial)
    enum WiiButton : uint32_t
    {
        WII_A      = 1 << 0,
        WII_B      = 1 << 1,
        WII_PLUS   = 1 << 2,
        WII_MINUS  = 1 << 3,
        WII_HOME   = 1 << 4,
        WII_UP     = 1 << 5,
        WII_DOWN   = 1 << 6,
        WII_LEFT   = 1 << 7,
        WII_RIGHT  = 1 << 8,
        WII_1      = 1 << 9,
        WII_2      = 1 << 10
    };

    struct WiiInputState
    {
        uint32_t buttons;
        float analogX;
        float analogY;
    };

    // Inicializa sistema de input
    bool Init();

    // Atualiza estado do controle
    void Update();

    // Obtém estado atual
    const WiiInputState& GetState();
}