#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct GXVertex;

struct OptimizationFlags {
    bool lod = true;
    bool occlusionCulling = true;
    bool greedyMesh = true;
    bool gpuInstancing = true;
    bool cpuInstancing = true;
    bool preRenderLoad = true;
};

class OptimizationManager {
public:
    static void Init();
    static void Shutdown();
    static void PreRenderLoad();
    static void BeginFrame();
    static void EndFrame();
    static void OptimizeMesh(std::vector<GXVertex>& vertices);
    static OptimizationFlags& GetFlags();

private:
    static OptimizationFlags flags;
    static void ApplyLoD(std::vector<GXVertex>& vertices);
    static void ApplyOcclusionCulling(std::vector<GXVertex>& vertices);
    static void ApplyGreedyMesh(std::vector<GXVertex>& vertices);
    static void SubmitGPUInstancing();
    static void SubmitCPUInstancing();
};