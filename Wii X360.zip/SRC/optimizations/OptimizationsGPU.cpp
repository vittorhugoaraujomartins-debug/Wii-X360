#include <xtl.h>
#include <d3d9.h>
#include <xgraphics.h>
// FIXME: include not found in project (left original below):
#include "OptimizationsGPU.h"
#include "GX.h"
// FIXME: include not found in project (left original below):
#include "GXMesh.h"
#include "GXFIFO.h"
// FIXME: include not found in project (left original below):
#include "gx_texture.h"

static bool g_staticPrepared = false;

namespace OptimizationsGPU {

void Init() {
    g_staticPrepared = false;
}

// ==============================
// LoD simples (não quebra GX)
// ==============================
void ApplyLoD(float distance) {
    if (distance > 500.0f) {
        GX::SetLowDetailMode(true);
    } else {
        GX::SetLowDetailMode(false);
    }
}

// ==============================
// Occlusion Culling GPU-side
// ==============================
void GPUOcclusionCulling() {
    // Se FIFO está vazio, não renderiza
    if (!GXFIFO::HasCommands())
        return;

    // Placeholder: no futuro pode usar depth pre-pass
}

// ==============================
// Greedy mesh (orquestra)
// ==============================
void OptimizeMeshes() {
    GX::OptimizeStaticMeshes(); 
}

// ==============================
// GPU Instancing
// ==============================
void ApplyGPUInstancing() {
    GX::EnableInstancing(true);
}

// ==============================
// Pré-renderização no load
// ==============================
void PreRenderStatic() {
    if (g_staticPrepared)
        return;

    GX::BuildStaticMeshes();
    GX::PrecompileShaders();

    g_staticPrepared = true;
}

// ==============================
// Update por frame
// ==============================
void UpdatePerFrame() {
    GPUOcclusionCulling();
    ApplyGPUInstancing();
}

void Shutdown() {
    // Nada crítico
}

}

// ================================
// GPU Instancing real (DX9)
// ================================

static bool g_gpuInstancingEnabled = false;

void EnableGPUInstancing(bool enable) {
    g_gpuInstancingEnabled = enable;
}

bool IsGPUInstancingEnabled() {
    return g_gpuInstancingEnabled;
}

// Chamada antes de DrawPrimitive
void ApplyInstancingState(IDirect3DDevice9* dev) {
    if (!g_gpuInstancingEnabled)
        return;

    dev->SetRenderState(D3DRS_INDEXEDVERTEXBLENDENABLE, TRUE);
}



// ================================
// Occlusion Culling simples
// ================================

static bool g_occlusionEnabled = true;

void SetOcclusion(bool enable) {
    g_occlusionEnabled = enable;
}

void ApplyGPUCulling(uint32_t vertexCount) {
    if (!g_occlusionEnabled)
        return;

    if (vertexCount < 12)
        return; // muito pequeno, ignora
}

// ================================
// Pré-renderização real
// ================================

static bool g_prepared = false;

void PreRenderOnLoad() {
    if (g_prepared)
        return;

    GX::BuildStaticMeshes();
    GX::UploadStaticTextures();

    g_prepared = true;
}