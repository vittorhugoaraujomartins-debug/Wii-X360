#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):

OptimizationFlags OptimizationManager::flags;

void OptimizationManager::Init() {}
void OptimizationManager::Shutdown() {}
OptimizationFlags& OptimizationManager::GetFlags() { return flags; }

void OptimizationManager::PreRenderLoad() {
    if (!flags.preRenderLoad) return;
}

void OptimizationManager::BeginFrame() {}
void OptimizationManager::EndFrame() {
    if (flags.gpuInstancing) SubmitGPUInstancing();
    if (flags.cpuInstancing) SubmitCPUInstancing();
}

void OptimizationManager::OptimizeMesh(std::vector<GXVertex>& vertices) {
    if (flags.lod) ApplyLoD(vertices);
    if (flags.occlusionCulling) ApplyOcclusionCulling(vertices);
    if (flags.greedyMesh) ApplyGreedyMesh(vertices);
}

void OptimizationManager::ApplyLoD(std::vector<GXVertex>& vertices) {
    if (vertices.size() > 4000) vertices.resize(vertices.size() / 2);
}

void OptimizationManager::ApplyOcclusionCulling(std::vector<GXVertex>&) {}
void OptimizationManager::ApplyGreedyMesh(std::vector<GXVertex>& vertices) {
    OptimizeGreedyMesh(vertices);
}

void OptimizationManager::SubmitGPUInstancing() {}
void OptimizationManager::SubmitCPUInstancing() {}