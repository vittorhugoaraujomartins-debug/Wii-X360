
#include "cpu.h"
void CPU::TickDEC(int cycles){
    if(DEC>0){
        DEC-=cycles;
        if(DEC<=0){
            RaiseIRQ(IRQ_DEC);
            DEC=0; // latch until reloaded
        }
    }
}
