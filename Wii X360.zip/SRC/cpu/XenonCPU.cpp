#include "XenonCPU.h"

namespace WiiCPU {

void XenonCPU::Initialize() {
    cpu.Reset();
}

void XenonCPU::RunFrame() {

JIT::Execute(cpu.state, cycles);
   
 // Wii ~ 729 MHz
    // Aproximação segura: ~12 milhões de instruções/frame (60 FPS)
    const uint32_t instructionsPerFrame = 12000000;

    for (uint32_t i = 0; i < instructionsPerFrame; i++) {
        cpu.Step();
    }
}

void XenonCPU::Shutdown() {
    // Futuro: flush JIT, salvar estado
}

}

#include "CPUScheduler.h"

void XenonCPU::RunCycles(uint32_t cycles) {
    const uint32_t SLICE = 256; // slice pequeno = ordem garantida

    uint32_t remaining = cycles;

    while (remaining > 0) {
        uint32_t step = (remaining > SLICE) ? SLICE : remaining;

        Execute(step); // sua execução PPC/JIT atual
        WiiCPU::CPUScheduler::Tick(step);

        remaining -= step;
    }
}


void XenonCPU::Initialize() {
    scheduler.Reset();
}

void XenonCPU::RunCycles(uint32_t cycles) {
    scheduler.AddCycles(cycles);

    while (scheduler.CanExecute(1)) {
        ExecuteInstruction();
    }
}


void XenonCPU::ExecuteInstruction() {
    uint32_t pc = state.pc;

    uint32_t opcode = MMU::Read32(pc);

    uint32_t cost = InstructionCycles(opcode);

    // ⚠️ Garante ordem
    scheduler.Step(cost);

    state.pc += 4;

    // JIT ou Interpreter
    if (jit.IsCompiled(pc)) {
        jit.ExecuteBlock(pc);
    } else {
        Interpreter::Execute(opcode, state);
    }
}


uint32_t XenonCPU::InstructionCycles(uint32_t opcode) {
    if ((opcode & 0xFC000000) == 0x80000000) return 2; // load
    if ((opcode & 0xFC000000) == 0x90000000) return 2; // store
    if ((opcode & 0x48000000) == 0x48000000) return 3; // branch
    return 1; // ALU
}


void XenonCPU::CheckInterrupts() {
    if (!flags.EE)
        return;

    if (!irqController.HasPending())
        return;

    // Salva estado
    state.srr0 = state.pc;
    state.srr1 = state.msr;

    // Desabilita interrupções
    flags.EE = false;

    // Vai para vetor
    state.pc = irqController.GetVector();
}

while (scheduler.CanExecute(1)) {
    CheckInterrupts();
    ExecuteInstruction();
}