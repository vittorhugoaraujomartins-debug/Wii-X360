
#include "cpu.h"
static inline uint32_t mask(int mb,int me){
    if(mb<=me) return ((0xFFFFFFFF>>mb)&(0xFFFFFFFF<<(31-me)));
    return ((0xFFFFFFFF>>mb)|(0xFFFFFFFF<<(31-me)));
}
uint32_t CPU::RLWINM(uint32_t v,int sh,int mb,int me){
    return ((v<<sh)|(v>>(32-sh))) & mask(mb,me);
}
