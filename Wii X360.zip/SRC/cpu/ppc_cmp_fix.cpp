
#include "cpu.h"
void CPU::UpdateCR(int64_t a, int64_t b, int crf){
    uint32_t f=0;
    if(a < b) f=0x8;
    else if(a > b) f=0x4;
    else f=0x2;
    CR &= ~(0xF << (28-crf*4));
    CR |= (f << (28-crf*4));
}
