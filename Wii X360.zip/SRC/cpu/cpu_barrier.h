#pragma once

inline void CPU_MemoryBarrier() {
#if defined(XBOX360)
    __asm { eieio } // PPC barrier
#endif
}