#pragma once
#include <cstdint>

namespace WiiCPU {

using JitFunc = void(*)();

class PowerPC {
public:
    void Reset();
    void Step();

    uint32_t GetPC() const { return pc; }
    void SetPC(uint32_t v) { pc = v; }

    // Debug / helpers
    bool IsNOP(uint32_t opcode) const;
    bool IsBranch(uint32_t opcode) const;

private:
    uint32_t pc = 0;
    uint32_t gpr[32]{};
    double   fpr[32]{};

    void ExecuteInstruction(uint32_t opcode);
};

void RaiseException(uint32_t vector);

}


struct PPCState {
    uint32_t gpr[32];
    double   fpr[32];

    uint32_t pc;
    uint32_t lr;
    uint32_t ctr;

    uint32_t srr0;
    uint32_t srr1;

    uint32_t msr;
    uint32_t cr;
    uint32_t xer;

    uint32_t dec;   // Decrementer
};



#include "MMU.h"

class PowerPC {
public:
    MMU mmu;
};

uint32_t phys;
MMUFault fault;

if (!mmu.Translate(pc, phys, false, true, fault)) {
    RaiseISI(pc);
    return;
}


if (!mmu.Translate(addr, phys, isWrite, false, fault)) {
    RaiseDSI(addr);
    return;
}