#pragma once
#include "ppc_state.h"

namespace WiiCPU {

class PowerPC {
public:

    PPCState state;

    void Reset();
    void Step();
    void Execute(uint32_t opcode);
};

}