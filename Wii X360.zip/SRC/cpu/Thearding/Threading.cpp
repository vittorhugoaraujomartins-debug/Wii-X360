
#include "threading.h"
#include "XenonCPU.h"

namespace WiiCPU {

HANDLE Threading::cpuThread = nullptr;
bool Threading::running = false;
static XenonCPU g_cpu;

void Threading::Initialize() {
    g_cpu.Initialize();
}

void Threading::Shutdown() {
    StopCPUThread();
}

void Threading::StartCPUThread() {
    if (running) return;

    running = true;
    cpuThread = CreateThread(
        nullptr,
        0,
        CPUThreadProc,
        nullptr,
        0,
        nullptr
    );
}

void Threading::StopCPUThread() {
    running = false;
    if (cpuThread) {
        WaitForSingleObject(cpuThread, INFINITE);
        CloseHandle(cpuThread);
        cpuThread = nullptr;
    }
}

DWORD WINAPI Threading::CPUThreadProc(LPVOID) {
    while (running) {
        g_cpu.RunFrame();
        Sleep(1);
    }
    return 0;
}

}
