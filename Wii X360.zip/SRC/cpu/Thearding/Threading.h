
#pragma once
#include <xtl.h>

namespace WiiCPU {

class Threading {
public:
    static void Initialize();
    static void Shutdown();

    static void StartCPUThread();
    static void StopCPUThread();

private:
    static HANDLE cpuThread;
    static bool running;

    static DWORD WINAPI CPUThreadProc(LPVOID param);
};

}