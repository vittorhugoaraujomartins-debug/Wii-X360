
#include "cpu.h"
void CPU::ApplyBranch(uint32_t target, bool link){
    if(link) LR = PC + 4;
    PC = target;
    nextPC = PC; // prevent double advance
}
