#include "PowerPC.h"
#include "MMU.h"
#include "IOS.h"
#include "ppc_jit.h"

namespace WiiCPU {

static PPCJIT g_jit;

// ================= RESET =================

void PowerPC::Reset() {
    pc = 0x80000000;
    for (int i = 0; i < 32; i++) {
        gpr[i] = 0;
        fpr[i] = 0.0;
    }
}

// ================= STEP =================

void PowerPC::Step() {

    // ---------- FAST PATH (JIT) ----------
    if (JitFunc fn = g_jit.GetOrCompile(pc)) {
        fn();          // bloco JIT já ajusta o PC
        return;
    }

    // ---------- INTERPRETADOR ----------
    uint32_t opcode = MMU::Read32(pc);
    ExecuteInstruction(opcode);
}

// ================= EXECUTE =================

void PowerPC::ExecuteInstruction(uint32_t opcode) {

    // NOP (ori r0,r0,0)
    if (opcode == 0x60000000) {
        pc += 4;
        return;
    }

    uint32_t primary = opcode >> 26;

    switch (primary) {

    // ================= LOAD / STORE =================

    case 32: { // lwz
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        uint32_t addr = (rA ? gpr[rA] : 0) + imm;
        gpr[rD] = MMU::Read32(addr);
        pc += 4;
        break;
    }

    case 36: { // stw
        int rS = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        uint32_t addr = (rA ? gpr[rA] : 0) + imm;
        MMU::Write32(addr, gpr[rS]);
        MMU::InvalidateRange(addr, 4);
        pc += 4;
        break;
    }

    // ================= ARITH =================

    case 14: { // addi
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        gpr[rD] = (rA ? gpr[rA] : 0) + imm;
        pc += 4;
        break;
    }

    case 31: {
        uint32_t subop = (opcode >> 1) & 0x3FF;
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int rB = (opcode >> 11) & 31;

        switch (subop) {
        case 266: // add
            gpr[rD] = gpr[rA] + gpr[rB];
            break;
        case 40: // subf
            gpr[rD] = gpr[rB] - gpr[rA];
            break;
        case 235: // mullw
            gpr[rD] = (int32_t)gpr[rA] * (int32_t)gpr[rB];
            break;
        default:
            break;
        }
        pc += 4;
        break;
    }

    // ================= BRANCH =================

    case 18: { // b / bl
        int32_t offset = (opcode & 0x03FFFFFC);
        if (offset & 0x02000000)
            offset |= 0xFC000000;

        bool link = opcode & 1;
        if (link)
            gpr[8] = pc + 4; // LR

        pc += offset;
        break;
    }

    case 19: { // blr
        uint32_t subop = (opcode >> 1) & 0x3FF;
        if (subop == 16) {
            pc = gpr[8];
            return;
        }
        pc += 4;
        break;
    }

    // ================= SYSTEM =================

    case 17: { // sc
        IOS::HandleIPC(0, nullptr);
        pc += 4;
        break;
    }

    default:
        // Instrução não implementada → skip seguro
        pc += 4;
        break;
    }
}

// ================= HELPERS =================

bool PowerPC::IsNOP(uint32_t opcode) const {
    return opcode == 0x60000000;
}

bool PowerPC::IsBranch(uint32_t opcode) const {
    return (opcode & 0x48000000) == 0x48000000;
}

void RaiseException(uint32_t vector) {
    // Simplificado
    // real: SRR0 / SRR1
}

} // namespace WiiCPU

void PowerPC::Run(int cycles) {
    for (int i = 0; i < cycles; i++) {

        // Busca instrução
        uint32_t instr = Memory::Read32(state.pc);

        // Tenta JIT primeiro
        if (JIT::IsBlockCompiled(state.pc)) {
            JIT::ExecuteBlock(state.pc);
        } else {
            // Fallback HLE
            ExecuteInstruction(instr);
        }

        // Avança PC
        state.pc += 4;

        // Interrupções
        CPUInterrupts::Check();

        // Yield cooperativo (IOS)
        if ((i & 0xFF) == 0) {
            IOSYield::Yield();
        }
    }
}

void PowerPC::ExecuteInstruction(uint32_t instr) {
    uint32_t opcode = instr >> 26;

    switch (opcode) {

        case 18: // b
            state.pc += (instr & 0x03FFFFFC);
            break;

        case 19: // blr
            state.pc = state.lr;
            break;

        default:
            // Ignora instruções desconhecidas (HLE)
            break;
    }
}