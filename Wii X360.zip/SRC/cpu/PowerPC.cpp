#include "PowerPC.h"
#include "MMU.h"
#include "IOS.h"

namespace WiiCPU {

// ---------- helpers ----------

static inline uint32_t RotL(uint32_t v, int s) {
    return (v << s) | (v >> (32 - s));
}

static inline uint32_t Mask(int mb, int me) {
    if (mb <= me)
        return (0xFFFFFFFF >> mb) & (0xFFFFFFFF << (31 - me));
    return (0xFFFFFFFF >> mb) | (0xFFFFFFFF << (31 - me));
}

// ---------- reset ----------

void PowerPC::Reset() {

    state = {};
    state.pc = 0x80000000;
    state.running = true;
}

// ---------- step ----------

void PowerPC::Step() {

    uint32_t opcode = MMU::Read32(state.pc);
    Execute(opcode);
}

// ---------- execute ----------

void PowerPC::Execute(uint32_t op) {

    uint32_t primary = op >> 26;

    switch (primary) {

    // ---------- ADDI ----------
    case 14: {
        int rD = (op >> 21) & 31;
        int rA = (op >> 16) & 31;
        int imm = (int16_t)(op & 0xFFFF);

        state.gpr[rD] = (rA ? state.gpr[rA] : 0) + imm;
        state.pc += 4;
        break;
    }

    // ---------- LWZ ----------
    case 32: {
        int rD = (op >> 21) & 31;
        int rA = (op >> 16) & 31;
        int imm = (int16_t)(op & 0xFFFF);

        uint32_t addr = (rA ? state.gpr[rA] : 0) + imm;
        state.gpr[rD] = MMU::Read32(addr);

        state.pc += 4;
        break;
    }

    // ---------- STW ----------
    case 36: {
        int rS = (op >> 21) & 31;
        int rA = (op >> 16) & 31;
        int imm = (int16_t)(op & 0xFFFF);

        uint32_t addr = (rA ? state.gpr[rA] : 0) + imm;
        MMU::Write32(addr, state.gpr[rS]);

        state.pc += 4;
        break;
    }

    // ---------- ORI ----------
    case 24: {
        int rS = (op >> 21) & 31;
        int rA = (op >> 16) & 31;
        uint16_t imm = op & 0xFFFF;

        state.gpr[rA] = state.gpr[rS] | imm;
        state.pc += 4;
        break;
    }

    // ---------- ANDI. ----------
    case 28: {
        int rS = (op >> 21) & 31;
        int rA = (op >> 16) & 31;
        uint16_t imm = op & 0xFFFF;

        uint32_t res = state.gpr[rS] & imm;
        state.gpr[rA] = res;

        state.cr.lt = (int32_t(res) < 0);
        state.cr.gt = (int32_t(res) > 0);
        state.cr.eq = (res == 0);

        state.pc += 4;
        break;
    }

    // ---------- B / BL ----------
    case 18: {
        int32_t offset = op & 0x03FFFFFC;
        if (offset & 0x02000000)
            offset |= 0xFC000000;

        if (op & 1)
            state.lr = state.pc + 4;

        state.pc += offset;
        break;
    }

    // ---------- SC (syscall → IOS) ----------
    case 17: {
        IOS::HandleIPC(0, nullptr);
        state.pc += 4;
        break;
    }

    // ---------- BC ----------
    case 16: {

        int32_t offset = op & 0xFFFC;
        if (offset & 0x8000)
            offset |= 0xFFFF0000;

        if (state.cr.eq)
            state.pc += offset;
        else
            state.pc += 4;

        break;
    }

    // ---------- EXTENDED ----------
    case 31: {

        uint32_t sub = (op >> 1) & 0x3FF;

        // MFLR
        if (sub == 339) {
            int rD = (op >> 21) & 31;
            state.gpr[rD] = state.lr;
            state.pc += 4;
            return;
        }

        // MTLR
        if (sub == 467) {
            int rS = (op >> 21) & 31;
            state.lr = state.gpr[rS];
            state.pc += 4;
            return;
        }

        // SUBF
        if (sub == 40) {
            int rD = (op >> 21) & 31;
            int rA = (op >> 16) & 31;
            int rB = (op >> 11) & 31;

            state.gpr[rD] = state.gpr[rB] - state.gpr[rA];
            state.pc += 4;
            return;
        }

        break;
    }

    // ---------- UNKNOWN ----------
    default:
        state.pc += 4;
        break;
    }
}

}