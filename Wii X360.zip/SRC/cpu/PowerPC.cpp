#include "PowerPC.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):

namespace WiiCPU {

static inline uint32_t RotL(uint32_t v, uint32_t s) {
    return (v << s) | (v >> (32 - s));
}

static inline uint32_t Mask(uint32_t mb, uint32_t me) {
    if (mb <= me) {
        return ((0xFFFFFFFF >> mb) & (0xFFFFFFFF << (31 - me)));
    } else {
        return ((0xFFFFFFFF >> mb) | (0xFFFFFFFF << (31 - me)));
    }
}
// ================= RESET =================

void PowerPC::Reset() {
    state.pc = 0x80000000;

    for (int i = 0; i < 32; i++) {
        state.gpr[i] = 0;
        state.fpr[i] = 0.0;
    }
}

// ================= STEP =================

void PowerPC::Step() {
    uint32_t opcode = MMU::Read32(state.pc);
    ExecuteInstruction(opcode);
}

// ================= EXECUTE =================

void PowerPC::ExecuteInstruction(uint32_t opcode) {

    // NOP
    if (opcode == 0x60000000) {
        state.pc += 4;
        return;
  case 31: {
    uint32_t subop = (opcode >> 1) & 0x3FF;

    // LWZX
    if (subop == 23) {
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int rB = (opcode >> 11) & 31;

        uint32_t addr =
            (rA ? state.gpr[rA] : 0) + state.gpr[rB];

        state.gpr[rD] = MMU::Read32(addr);
        state.pc += 4;
        return;
    }

    // STWX
    if (subop == 151) {
        int rS = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int rB = (opcode >> 11) & 31;

        uint32_t addr =
            (rA ? state.gpr[rA] : 0) + state.gpr[rB];

        MMU::Write32(addr, state.gpr[rS]);
        MMU::InvalidateRange(addr, 4);
        state.pc += 4;
        return;
    }

    // SUBF
    if (subop == 40) {
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int rB = (opcode >> 11) & 31;

        int32_t a = (int32_t)state.gpr[rA];
        int32_t b = (int32_t)state.gpr[rB];
        int32_t res = b - a;

        state.gpr[rD] = (uint32_t)res;

        // Atualiza CR se tiver ponto
        if (opcode & 1) {
            state.cr.lt = (res < 0);
            state.cr.gt = (res > 0);
            state.cr.eq = (res == 0);
        }

        state.pc += 4;
        return;
    }

    // MFLR
    if (subop == 339) {
        int rD = (opcode >> 21) & 31;
        state.gpr[rD] = state.lr;
        state.pc += 4;
        return;
    }

    // MTLR
    if (subop == 467) {
        int rS = (opcode >> 21) & 31;
        state.lr = state.gpr[rS];
        state.pc += 4;
        return;
    }

    break;
}
    break;
}

  }

    uint32_t primary = opcode >> 26;

    switch (primary) {

    case 32: { // lwz
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        uint32_t addr = (rA ? state.gpr[rA] : 0) + imm;
        state.gpr[rD] = MMU::Read32(addr);
        state.pc += 4;
        break;
    }

    case 36: { // stw
        int rS = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        uint32_t addr = (rA ? state.gpr[rA] : 0) + imm;
        MMU::Write32(addr, state.gpr[rS]);
        MMU::InvalidateRange(addr, 4);
        state.pc += 4;
        break;
    }

    case 14: { // addi
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        state.gpr[rD] = (rA ? state.gpr[rA] : 0) + imm;
        state.pc += 4;
        break;
    }

    case 18: { // b / bl
        int32_t offset = opcode & 0x03FFFFFC;
        if (offset & 0x02000000)
            offset |= 0xFC000000;

        if (opcode & 1)
            state.lr = state.pc + 4;

        state.pc += offset;
        break;
    }

    case 19: { // blr
        uint32_t subop = (opcode >> 1) & 0x3FF;
        if (subop == 16) {
            state.pc = state.lr;
            return;
        }
        state.pc += 4;
        break;
    }

    case 17: { // sc
        IOS::HandleIPC(0, nullptr);
        state.pc += 4;
        break;
    }

    default:
        state.pc += 4;
        break;
    }
}

if (subop == 32) { // CMPL
    int ra = (opcode >> 16) & 31;
    int rb = (opcode >> 11) & 31;

    uint32_t a = state.gpr[ra];
    uint32_t b = state.gpr[rb];

    state.cr.lt = (a < b);
    state.cr.gt = (a > b);
    state.cr.eq = (a == b);

    state.pc += 4;
    return;
}


case 16: { // BC
    uint32_t BO = (opcode >> 21) & 0x1F;
    uint32_t BI = (opcode >> 16) & 0x1F;

    int32_t offset = opcode & 0xFFFC;
    if (offset & 0x8000)
        offset |= 0xFFFF0000;

    bool take = false;

    switch (BI) {
    case 0: take = state.cr.lt; break;
    case 1: take = state.cr.gt; break;
    case 2: take = state.cr.eq; break;
    default: take = false; break;
    }

    if (take) {
        state.pc += offset;
    } else {
        state.pc += 4;
    }

    return;
}

case 28: { // ANDI.
    int rS = (opcode >> 21) & 31;
    int rA = (opcode >> 16) & 31;
    uint16_t imm = opcode & 0xFFFF;

    uint32_t res = state.gpr[rS] & imm;
    state.gpr[rA] = res;

    // Atualiza CR
    state.cr.lt = ((int32_t)res < 0);
    state.cr.gt = ((int32_t)res > 0);
    state.cr.eq = (res == 0);

    state.pc += 4;
    return;
}

case 24: { // ORI
    int rS = (opcode >> 21) & 31;
    int rA = (opcode >> 16) & 31;
    uint16_t imm = opcode & 0xFFFF;

    state.gpr[rA] = state.gpr[rS] | imm;
    state.pc += 4;
    return;
}

case 21: { // RLWINM
    int rS = (opcode >> 21) & 31;
    int rA = (opcode >> 16) & 31;
    int SH = (opcode >> 11) & 31;
    int MB = (opcode >> 6) & 31;
    int ME = (opcode >> 1) & 31;

    uint32_t v = state.gpr[rS];
    uint32_t res = RotL(v, SH) & Mask(MB, ME);

    state.gpr[rA] = res;

    // Atualiza CR se tiver ponto (.)
    if (opcode & 1) {
        state.cr.lt = ((int32_t)res < 0);
        state.cr.gt = ((int32_t)res > 0);
        state.cr.eq = (res == 0);
    }

    state.pc += 4;
    return;
}
// ================= RUN =================

void PowerPC::Run(int cycles) {
    for (int i = 0; i < cycles; i++) {
        Step();
        CPUInterrupts::Handle();
    }
}
scheduler.Step(cost);
timer.Tick(cost);

if (timer.Expired()) {
    irqController.Raise(WiiInterrupt::DEC);
}
if (flags.EE && irqController.HasPending()) {
    cpu.state.srr0 = cpu.state.pc;
    cpu.state.srr1 = cpu.state.msr;
    flags.EE = false;

    cpu.state.pc = irqController.GetVector();
}

} // namespace WiiCPU

case 17: { // sc
    IOS::HandleIPC(0, nullptr);
    state.pc += 4;
    break;
}


#include "core/scheduler/event_scheduler.h"

EventScheduler* eventScheduler = nullptr;
uint64_t global_cycles = 0;