#include <xtl.h>
#include "PowerPC.h"
#include "MMU.h"
#include "IOS.h"
// FIXME: include not found in project (left original below):
#include "CPUInterrupts.h"

namespace WiiCPU {

// ================= RESET =================

void PowerPC::Reset() {
    state.pc = 0x80000000;

    for (int i = 0; i < 32; i++) {
        state.gpr[i] = 0;
        state.fpr[i] = 0.0;
    }
}

// ================= STEP =================

void PowerPC::Step() {
    uint32_t opcode = MMU::Read32(state.pc);
    ExecuteInstruction(opcode);
}

// ================= EXECUTE =================

void PowerPC::ExecuteInstruction(uint32_t opcode) {

    // NOP
    if (opcode == 0x60000000) {
        state.pc += 4;
        return;
    }

    uint32_t primary = opcode >> 26;

    switch (primary) {

    case 32: { // lwz
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        uint32_t addr = (rA ? state.gpr[rA] : 0) + imm;
        state.gpr[rD] = MMU::Read32(addr);
        state.pc += 4;
        break;
    }

    case 36: { // stw
        int rS = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        uint32_t addr = (rA ? state.gpr[rA] : 0) + imm;
        MMU::Write32(addr, state.gpr[rS]);
        MMU::InvalidateRange(addr, 4);
        state.pc += 4;
        break;
    }

    case 14: { // addi
        int rD = (opcode >> 21) & 31;
        int rA = (opcode >> 16) & 31;
        int imm = (int16_t)(opcode & 0xFFFF);
        state.gpr[rD] = (rA ? state.gpr[rA] : 0) + imm;
        state.pc += 4;
        break;
    }

    case 18: { // b / bl
        int32_t offset = opcode & 0x03FFFFFC;
        if (offset & 0x02000000)
            offset |= 0xFC000000;

        if (opcode & 1)
            state.lr = state.pc + 4;

        state.pc += offset;
        break;
    }

    case 19: { // blr
        uint32_t subop = (opcode >> 1) & 0x3FF;
        if (subop == 16) {
            state.pc = state.lr;
            return;
        }
        state.pc += 4;
        break;
    }

    case 17: { // sc
        IOS::HandleIPC(0, nullptr);
        state.pc += 4;
        break;
    }

    default:
        state.pc += 4;
        break;
    }
}

// ================= RUN =================

void PowerPC::Run(int cycles) {
    for (int i = 0; i < cycles; i++) {
        Step();
        CPUInterrupts::Handle();
    }
}

} // namespace WiiCPU

case 17: { // sc
    IOS::HandleIPC(0, nullptr);
    state.pc += 4;
    break;
}