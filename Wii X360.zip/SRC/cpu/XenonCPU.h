#pragma once
#include "PowerPC.h"

namespace WiiCPU {

class XenonCPU {
public:
    void Initialize();
    void RunFrame();
    void Shutdown();

private:
    PowerPC cpu;
};

}

#include "cpu_scheduler.h"

class XenonCPU {
public:
    void Initialize();
    void RunCycles(uint32_t cycles);

private:
    CPUScheduler scheduler;

    void ExecuteInstruction();
    uint32_t InstructionCycles(uint32_t opcode);
};