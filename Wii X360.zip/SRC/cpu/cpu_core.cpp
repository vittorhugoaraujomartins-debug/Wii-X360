#include "cpu_state.h"
#include "ppc_jit.h"

// =======================================================
// INTERRUPÇÕES PPC
// =======================================================

enum PPCInterrupt {
    INT_NONE,
    INT_EXTERNAL,
    INT_SYSTEM_CALL,
    INT_PROGRAM,
    INT_FP_EXCEPTION,
    INT_TIMER
};

namespace CPUInterrupts {

static PPCInterrupt pending = INT_NONE;

void Raise(PPCInterrupt t) {
    pending = t;
}

void Handle() {
    if (pending == INT_NONE)
        return;

    // Salva estado (simplificado)
    gCPU.SRR0 = gCPU.PC;
    gCPU.SRR1 = gCPU.MSR;

    // Desabilita interrupções
    gCPU.MSR &= ~0x8000;

    switch (pending) {
        case INT_EXTERNAL:      gCPU.PC = 0x00000500; break;
        case INT_SYSTEM_CALL:   gCPU.PC = 0x00000C00; break;
        case INT_PROGRAM:       gCPU.PC = 0x00000700; break;
        case INT_FP_EXCEPTION:  gCPU.PC = 0x00000800; break;
        case INT_TIMER:         gCPU.PC = 0x00000900; break;
        default: break;
    }

    pending = INT_NONE;
}

} // namespace CPUInterrupts

// =======================================================
// ORDEM DE INSTRUÇÕES / BARREIRAS
// =======================================================

namespace InstrOrder {

// Garante visibilidade de memória
inline void MemoryBarrier() {
#if defined(XBOX360)
    __asm { eieio }
#else
    __sync_synchronize();
#endif
}

// Ordem para MMIO / GX / FIFO
inline void IOBarrier() {
#if defined(XBOX360)
    __asm { eieio }
#else
    __sync_synchronize();
#endif
}

// Código auto-modificante
inline void CodeBarrier(uint32_t addr, uint32_t size) {
#if defined(XBOX360)
    __asm { eieio }
#endif
    __sync_synchronize();

    // Invalida JIT
    PPCJIT::InvalidateRange(addr, size);
}

} // namespace InstrOrder



#include "cpu_core.h"
#include "cpu_state.h"
#include "memory_access.h"
#include "ppc_decoder.h"
#include "ppc_jit.h"

extern PPCJIT g_jit;

namespace CPU {

static bool g_useJIT = true;

void Init() {
    Reset();
}

void Reset() {
    CPU_Reset();
}

static inline void ExecuteInterp(uint32_t instr) {
    PPCInstr d = DecodePPC(instr);

    switch (d.op) {

    case PPCOpcode::ADDI:
        gCPU.GPR[d.rd] = gCPU.GPR[d.ra] + d.imm;
        gCPU.PC += 4;
        break;

    case PPCOpcode::LWZ: {
        uint32_t addr = gCPU.GPR[d.ra] + d.imm;
        gCPU.GPR[d.rd] = MemRead32(addr);
        gCPU.PC += 4;
        break;
    }

    case PPCOpcode::STW: {
        uint32_t addr = gCPU.GPR[d.ra] + d.imm;
        MemWrite32(addr, gCPU.GPR[d.rd]);
        gCPU.PC += 4;
        break;
    }

    case PPCOpcode::B:
        gCPU.PC += d.imm;
        break;

    default:
        // instrução desconhecida → avança
        gCPU.PC += 4;
        break;
    }
}

void Step(uint32_t cycles) {
    while (cycles--) {

        if (g_useJIT) {
            auto fn = g_jit.GetOrCompile(gCPU.PC);
            fn(); // executa bloco PPC
            continue;
        }

        uint32_t instr = MemRead32(gCPU.PC);
        ExecuteInterp(instr);
    }
}

void RaiseInterrupt(uint32_t vector) {
    gCPU.LR = gCPU.PC;
    gCPU.PC = vector;
}

}

