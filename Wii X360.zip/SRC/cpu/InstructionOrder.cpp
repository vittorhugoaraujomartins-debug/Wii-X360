#include "InstructionOrder.h"
#include <xtl.h>

namespace InstrOrder {

inline void MemoryBarrier() {
    // Barrier real do PowerPC do Xbox
    __sync_synchronize();
}

inline void IOBarrier() {
    // Garante ordem de escrita para GPU / MMIO
    __sync_synchronize();
}

inline void CodeBarrier(uint32_t addr, uint32_t size) {
    // Força visibilidade + invalida JIT
    __sync_synchronize();
    PPCJIT::InvalidateRange(addr, size);
}

}