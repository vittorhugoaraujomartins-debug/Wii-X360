#include "XenonCPU.h"
#include "MMU.h"

namespace WiiCPU {

void XenonCPU::Initialize() {
    cpu.Reset();
    scheduler.Reset();
}

void XenonCPU::RunCycles(uint32_t cycles) {
    scheduler.AddCycles(cycles);

    while (scheduler.CanExecute(1)) {
        uint32_t pc = cpu.state.pc;

        // JIT por bloco
        if (jit.IsCompiled(pc)) {
            uint32_t cost = jit.ExecuteBlock(pc);
            scheduler.Step(cost);
        } else {
            uint32_t opcode = MMU::Read32(pc);
            uint32_t cost = InstructionCycles(opcode);

            scheduler.Step(cost);
            cpu.ExecuteInstruction(opcode);
        }

        CheckInterrupts();
    }
}

uint32_t XenonCPU::InstructionCycles(uint32_t opcode) {
    if ((opcode & 0xFC000000) == 0x80000000) return 2;
    if ((opcode & 0xFC000000) == 0x90000000) return 2;
    if ((opcode & 0x48000000) == 0x48000000) return 3;
    return 1;
}

void XenonCPU::CheckInterrupts() {
    if (!flags.EE)
        return;

    if (!irqController.HasPending())
        return;

    cpu.state.srr0 = cpu.state.pc;
    cpu.state.srr1 = cpu.state.msr;

    flags.EE = false;
    cpu.state.pc = irqController.GetVector();
}

}