#include "XenonCPU.h"
#include "MMU.h"

namespace WiiCPU {

void XenonCPU::Initialize()
{
    memset(&state, 0, sizeof(state));
    state.running = true;

    scheduler.Reset();
}

void XenonCPU::RunCycles(uint32_t cycles)
{
    scheduler.AddCycles(cycles);

    while (scheduler.CanExecute(1) && state.running)
    {
        uint32_t pc = state.pc;

        // 🔥 Tenta bloco recompilado
        if (jit.IsCompiled(pc))
        {
            uint32_t cost = jit.ExecuteBlock(pc, &state);
            scheduler.Step(cost);
        }
        else
        {
            // Fallback interpretado
            uint32_t opcode = MMU::Read32(pc);

            uint32_t cost = InstructionCycles(opcode);
            scheduler.Step(cost);

            jit.CompileBlock(pc);  // compila para próxima vez
            InterpretInstruction(opcode);
        }

        CheckInterrupts();
    }
}


void InterpretInstruction(uint32_t op)
{
    uint32_t primary = op >> 26;

    switch (primary)
    {
        case 14: // addi
        {
            uint32_t rt = (op >> 21) & 31;
            uint32_t ra = (op >> 16) & 31;
            int16_t imm = op & 0xFFFF;

            state.gpr[rt] = state.gpr[ra] + imm;
            state.pc += 4;
            break;
        }

        case 18: // branch
        {
            int32_t offset = (op & 0x03FFFFFC);
            state.pc += offset;
            break;
        }

        default:
            state.pc += 4;
            break;
    }
}



int IOS_SendSync(int device, int cmd, void* in, void* out) {

    IPCMessage msg;
    msg.device = device;
    msg.cmd = cmd;
    msg.in = in;
    msg.out = out;
    msg.blocking = true;

    g_IOS.SendIPC(&msg);

    // BLOQUEIO REAL
    while (!g_IOS.IsCompleted(&msg)) {
        CPU::WaitForInterrupt();
    }

    return msg.result;
}