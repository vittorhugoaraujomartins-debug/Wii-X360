#include "ppc_cpu.h"
#include "MMU.h"
#include "cpu_interrupts.h"
#include "ppc_decoder.h"

CPUState gCPU;

namespace PPC {

void Init() {
    Reset();
}

void Reset() {
    for (int i = 0; i < 32; i++)
        gCPU.GPR[i] = 0;

    gCPU.PC  = 0x80000000; // entry point Wii
    gCPU.LR  = 0;
    gCPU.CTR = 0;
    gCPU.XER = 0;
    gCPU.MSR = 0;
}

static inline void AdvancePC() {
    gCPU.PC += 4;
}

CPUResult Step() {
    // 🔹 interrupções primeiro (como no hardware)
    CPUInterrupts::Handle();

    uint32_t instr = MMU::Read32(gCPU.PC);
    PPCInstr d = DecodePPC(instr);

    switch (d.op) {

    case PPCOpcode::ADDI:
        gCPU.GPR[d.rd] = gCPU.GPR[d.ra] + d.imm;
        AdvancePC();
        break;

    case PPCOpcode::LWZ: {
        uint32_t addr = gCPU.GPR[d.ra] + d.imm;
        gCPU.GPR[d.rd] = MMU::Read32(addr);
        AdvancePC();
        break;
    }

    case PPCOpcode::STW: {
        uint32_t addr = gCPU.GPR[d.ra] + d.imm;
        MMU::Write32(addr, gCPU.GPR[d.rd]);
        AdvancePC();
        break;
    }

    case PPCOpcode::B:
        gCPU.PC += d.imm;
        return CPUResult::Branch;

    case PPCOpcode::UNKNOWN:
    default:
        // exceção de instrução inválida
        CPUInterrupts::Raise(INT_PROGRAM);
        return CPUResult::Exception;
    }

    return CPUResult::Continue;
}

void Run(uint32_t cycles) {
    while (cycles--) {
        CPUResult r = Step();
        if (r == CPUResult::Exception)
            break;
    }
}

}