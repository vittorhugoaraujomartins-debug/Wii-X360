#include <xtl.h>
#include "ppc_cpu.h"
#include "MMU.h"
// FIXME: include not found in project (left original below):
#include "cpu_interrupts.h"
#include "ppc_decoder.h"

CPUState gCPU;

namespace PPC {

void Init() {
    Reset();
}

void Reset() {
    for (int i = 0; i < 32; i++)
        gCPU.GPR[i] = 0;

    gCPU.PC  = 0x80000000; // entry point Wii
    gCPU.LR  = 0;
    gCPU.CTR = 0;
    gCPU.XER = 0;
    gCPU.MSR = 0;
}

static inline void AdvancePC() {
    gCPU.PC += 4;
}

CPUResult Step() {
    // 🔹 interrupções primeiro (como no hardware)
    CPUInterrupts::Handle();

    uint32_t instr = MMU::Read32(gCPU.PC);
    PPCInstr d = DecodePPC(instr);

    switch (d.op) {

    case PPCOpcode::ADDI:
        gCPU.GPR[d.rd] = gCPU.GPR[d.ra] + d.imm;
        AdvancePC();
        break;

    case PPCOpcode::LWZ: {
        uint32_t addr = gCPU.GPR[d.ra] + d.imm;
        gCPU.GPR[d.rd] = MMU::Read32(addr);
        AdvancePC();
        break;
    }

    case PPCOpcode::STW: {
        uint32_t addr = gCPU.GPR[d.ra] + d.imm;
        MMU::Write32(addr, gCPU.GPR[d.rd]);
        AdvancePC();
        break;
    }

    case PPCOpcode::B:
        gCPU.PC += d.imm;
        return CPUResult::Branch;

    case PPCOpcode::UNKNOWN:
    default:
        // exceção de instrução inválida
        CPUInterrupts::Raise(INT_PROGRAM);
        return CPUResult::Exception;
    }

    return CPUResult::Continue;
}

void Run(uint32_t cycles) {
    while (cycles--) {
        CPUResult r = Step();
        if (r == CPUResult::Exception)
            break;
    }
}

}


#include "ppc_cpu.h"
#include "ppc_decoder.h"
// FIXME: include not found in project (left original below):
#include "MemoryAccess.h"

void PPCCPU::Reset() {
    state = {};
    state.running = true;
    state.pc = 0x80000000;
}

void PPCCPU::Step() {
    uint32_t instr = MemoryAccess::Read32(state.pc);
    state.pc += 4;

    PPCInstr d = DecodePPC(instr);

    switch (d.op) {
        case PPCOpcode::ADDI:
            state.gpr[d.rd] = state.gpr[d.ra] + d.imm;
            break;

        case PPCOpcode::LWZ: {
            uint32_t addr = state.gpr[d.ra] + d.imm;
            state.gpr[d.rd] = MemoryAccess::Read32(addr);
            break;
        }

        case PPCOpcode::STW: {
            uint32_t addr = state.gpr[d.ra] + d.imm;
            MemoryAccess::Write32(addr, state.gpr[d.rd]);
            break;
        }

        case PPCOpcode::B:
            state.pc += d.imm;
            break;

        default:
            // fallback seguro
            break;
    }
}


