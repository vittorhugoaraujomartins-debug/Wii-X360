#pragma once
#include <stdint.h>

struct PPC_CR_Field {
    uint8_t lt;
    uint8_t gt;
    uint8_t eq;
    uint8_t so;
};

struct PPCState
{
    uint32_t gpr[32];
    double   fpr[32];

    uint32_t pc;
    uint32_t lr;
    uint32_t ctr;

    uint32_t srr0;
    uint32_t srr1;

    uint32_t msr;
    uint32_t xer;

    PPC_CR_Field cr[8];

    bool running;
};




struct PPC_CR {
    bool lt;
    bool gt;
    bool eq;
    bool so;
};

struct PPCState {

    uint32_t gpr[32];
    double   fpr[32];

    uint32_t pc;
    uint32_t lr;
    uint32_t ctr;

    uint32_t cr_raw;
    PPC_CR   cr;

    uint32_t xer;
    uint32_t msr;

    uint32_t srr0;
    uint32_t srr1;

    uint32_t dec;

    bool running;
};