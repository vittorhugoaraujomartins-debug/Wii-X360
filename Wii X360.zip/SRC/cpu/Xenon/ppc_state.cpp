#include "ppc_state.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once
#include <stdint.h>

struct PPC_CR {
    bool lt;
    bool gt;
    bool eq;
    bool so;
};

struct PPCState {
    uint32_t gpr[32];
    double   fpr[32];

    uint32_t pc;
    uint32_t lr;
    uint32_t ctr;

    uint32_t srr0;
    uint32_t srr1;

    uint32_t msr;
    PPC_CR   cr;

    uint32_t xer;
};