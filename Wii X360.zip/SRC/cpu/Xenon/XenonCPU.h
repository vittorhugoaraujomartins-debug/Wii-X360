#pragma once
#include <stdint.h>

namespace WiiCPU {

class XenonCPU {
public:
    void Initialize();
    void RunCycles(uint32_t cycles);

private:
    PowerPC cpu;
    CPUScheduler scheduler;
    PPCJIT jit;
    IRQController irqController;

    uint32_t InstructionCycles(uint32_t opcode);
    void CheckInterrupts();
};

}