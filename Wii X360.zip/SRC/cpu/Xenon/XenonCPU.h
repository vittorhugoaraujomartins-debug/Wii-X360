#pragma once
#include <stdint.h>
#include "ppc_state.h"

namespace WiiCPU {

class XenonCPU {
public:
    void Initialize();
    void RunCycles(uint32_t cycles);

private:
    PPCState state;
    CPUScheduler scheduler;
    PPCJIT jit;
    IRQController irqController;

    uint32_t InstructionCycles(uint32_t opcode);
    void CheckInterrupts();
};

}