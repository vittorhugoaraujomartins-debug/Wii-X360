#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include "PowerPC.h"

namespace WiiCPU {

class XenonCPU {
public:
    void Initialize();
    void RunFrame();
    void Shutdown();

private:
    PowerPC cpu;
};

}

// FIXME: include not found in project (left original below):
#include "cpu_scheduler.h"

class XenonCPU {
public:
    void Initialize();
    void RunCycles(uint32_t cycles);

private:
    CPUScheduler scheduler;

    void ExecuteInstruction();
    uint32_t InstructionCycles(uint32_t opcode);
};