#pragma once
#include <cstdint>
#include "cpu_state.h"

enum class CPUResult {
    Continue,
    Branch,
    Exception,
    Halt
};

namespace PPC {

void Init();
void Reset();

CPUResult Step();          // executa 1 instrução
void Run(uint32_t cycles); // executa N ciclos

}