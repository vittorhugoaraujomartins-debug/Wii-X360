#pragma once
#include <cstdint>
#include "cpu_state.h"

enum class CPUResult {
    Continue,
    Branch,
    Exception,
    Halt
};

namespace PPC {

void Init();
void Reset();

CPUResult Step();          // executa 1 instrução
void Run(uint32_t cycles); // executa N ciclos

}

#pragma once
#include "ppc_state.h"

class PPCCPU {
public:
    void Reset();
    void Step();

    PPCState& GetState() { return state; }

private:
    PPCState state;
};