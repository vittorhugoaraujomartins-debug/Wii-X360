#include "ppc_decoder.h"

PPCInstr DecodePPC(uint32_t i) {
    PPCInstr d{};
    d.op = PPCOpcode::INVALID;

    uint32_t op = i >> 26;

    switch (op) {
        case 14: // ADDI
            d.op  = PPCOpcode::ADDI;
            d.rd  = (i >> 21) & 31;
            d.ra  = (i >> 16) & 31;
            d.imm = (int16_t)(i & 0xFFFF);
            break;

        case 32: // LWZ
            d.op  = PPCOpcode::LWZ;
            d.rd  = (i >> 21) & 31;
            d.ra  = (i >> 16) & 31;
            d.imm = (int16_t)(i & 0xFFFF);
            break;

        case 36: // STW
            d.op  = PPCOpcode::STW;
            d.rd  = (i >> 21) & 31;
            d.ra  = (i >> 16) & 31;
            d.imm = (int16_t)(i & 0xFFFF);
            break;

        case 18: // B
            d.op = PPCOpcode::B;
            d.imm = (int32_t)(i & 0x03FFFFFC);
            break;
    }

    return d;
}