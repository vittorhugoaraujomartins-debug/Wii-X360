#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

namespace PPC {

void Execute(uint32_t cycles);

}