#pragma once
#include <cstdint>

namespace PPC {

void Execute(uint32_t cycles);

}