#include "ppc_exec.h"
#include "ppc_cpu.h"
#include "ppc_jit.h"

namespace PPC {

void Execute(uint32_t cycles) {

    while (cycles > 0) {

        // 🔥 Se JIT existir, usa
        if (PPCJIT::IsBlockCompiled(gCPU.PC)) {
            auto fn = PPCJIT::GetOrCompile(gCPU.PC);
            fn();
            cycles -= 4; // estimativa
            continue;
        }

        // fallback interpreter
        PPC::Run(1);
        cycles--;
    }
}

}