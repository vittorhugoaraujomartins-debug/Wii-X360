#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

enum class PPCOpcode {
    INVALID,

    ADD, ADDI,
    SUB,
    OR, ORI,
    LWZ, STW,
    B, BL, BC,
};

struct PPCInstr {
    PPCOpcode op;
    uint8_t rd, ra, rb;
    int32_t imm;
};

PPCInstr DecodePPC(uint32_t instr);