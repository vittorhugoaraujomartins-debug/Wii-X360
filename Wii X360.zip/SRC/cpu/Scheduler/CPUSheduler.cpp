#include "CPUScheduler.h"

namespace WiiCPU {

uint64_t CPUScheduler::g_cycle = 0;
std::vector<ScheduledEvent> CPUScheduler::g_events;

void CPUScheduler::Init() {
    g_cycle = 0;
    g_events.clear();
}

void CPUScheduler::Reset() {
    Init();
}

uint64_t CPUScheduler::GetCycle() {
    return g_cycle;
}

void CPUScheduler::Tick(uint32_t cycles) {
    g_cycle += cycles;

    for (auto it = g_events.begin(); it != g_events.end(); ) {
        if (it->cycle <= g_cycle) {
            it->callback();
            it = g_events.erase(it);
        } else {
            ++it;
        }
    }
}

void CPUScheduler::Schedule(uint64_t cycle, EventType type, std::function<void()> cb) {
    ScheduledEvent ev;
    ev.cycle = cycle;
    ev.type  = type;
    ev.callback = cb;

    g_events.push_back(ev);
}

}