#include "cpu_scheduler.h"

void CPUScheduler::Reset() {
    currentCycles = 0;
    budgetCycles  = 0;
}

void CPUScheduler::AddCycles(uint32_t c) {
    budgetCycles += c;
}

bool CPUScheduler::CanExecute(uint32_t c) const {
    return currentCycles + c <= budgetCycles;
}

void CPUScheduler::Step(uint32_t c) {
    currentCycles += c;
}