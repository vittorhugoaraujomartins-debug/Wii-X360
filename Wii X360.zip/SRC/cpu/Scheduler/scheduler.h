#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

struct PPCState;
class PPCJIT;

class PPCScheduler {
public:
    void Init(PPCState* state, PPCJIT* jit);
    void StepFrame(uint32_t cycles);

private:
    PPCState* cpu = nullptr;
    PPCJIT*   jit = nullptr;
};