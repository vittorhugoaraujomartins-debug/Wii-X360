#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct PPCState;
class PPCJIT;

class PPCScheduler {
public:
    void Init(PPCState* state, PPCJIT* jit);
    void StepFrame(uint32_t cycles);

private:
    PPCState* cpu = nullptr;
    PPCJIT*   jit = nullptr;
};

#pragma once

#include <stdint.h>
#include <vector>
#include <functional>

struct PPCState;
class PPCJIT;

enum class SchedulerEventType {
    VBlank,
    Timer,
    DSP,
    IRQ
};

struct SchedulerEvent {
    uint64_t cycle;
    SchedulerEventType type;
    uint32_t param;
};

class PPCScheduler {
public:
    void Init(PPCState* state, PPCJIT* jit);

    void StepFrame(uint32_t cycles);

    // Eventos
    void ScheduleEvent(uint64_t cyclesFromNow,
                       SchedulerEventType type,
                       uint32_t param = 0);

    uint64_t GetCurrentCycle() const { return currentCycle; }

private:
    void ProcessEvents();
    void HandleEvent(const SchedulerEvent& ev);

    PPCState* cpu = nullptr;
    PPCJIT*   jit = nullptr;

    uint64_t currentCycle = 0;

    std::vector<SchedulerEvent> events;
};