#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

struct PPCState;
class PPCJIT;

class PPCScheduler {
public:
    void Init(PPCState* state, PPCJIT* jit);
    void StepFrame(uint32_t cycles);

private:
    PPCState* cpu = nullptr;
    PPCJIT*   jit = nullptr;
};