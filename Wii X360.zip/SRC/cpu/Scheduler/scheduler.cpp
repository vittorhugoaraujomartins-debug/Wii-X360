#include "scheduler.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


static const uint32_t CYCLES_PER_FRAME = 486000; 
// ~486k ≈ 729MHz / 60 / simplificado

void PPCScheduler::Init(PPCState* state, PPCJIT* j) {
    cpu = state;
    jit = j;
}

void PPCScheduler::StepFrame(uint32_t cycles) {

    uint32_t remaining = cycles;

    while (remaining > 0) {
        // Prioridade: JIT
        if (jit) {
            remaining = jit->Execute(*cpu, remaining);
        } else {
            // Fallback interpretado
            PowerPC cpuInterp;
            cpuInterp.Step();
            remaining--;
        }
    }
}