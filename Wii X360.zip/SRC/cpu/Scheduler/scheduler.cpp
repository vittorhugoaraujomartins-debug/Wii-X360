#include "scheduler.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


static const uint32_t CYCLES_PER_FRAME = 486000; 
// ~486k ≈ 729MHz / 60 / simplificado

void PPCScheduler::Init(PPCState* state, PPCJIT* j) {
    cpu = state;
    jit = j;
}

void PPCScheduler::StepFrame(uint32_t cycles) {

    uint32_t remaining = cycles;

    while (remaining > 0) {
        // Prioridade: JIT
        if (jit) {
            remaining = jit->Execute(*cpu, remaining);
        } else {
            // Fallback interpretado
            PowerPC cpuInterp;
            cpuInterp.Step();
            remaining--;
        }
    }
}

struct Event {
    uint64_t cycle;
    void (*callback)();
};


void PPCScheduler::StepFrame(uint32_t cycles) {
    uint64_t target = global_cycles + cycles;

    while (global_cycles < target) {

        uint64_t next_event = eventQueue.PeekCycle();
        uint64_t slice = min(target, next_event) - global_cycles;

        // Executa CPU até o próximo evento
        uint32_t executed = jit->Execute(*cpu, (uint32_t)slice);
        global_cycles += executed;

        // Se chegou em um evento, dispara
        if (global_cycles == next_event) {
            DispatchEvent();
        }
    }
}

#include "scheduler.h"
#include "ppc_state.h"
#include "ppc_jit.h"
#include <algorithm>

// ================= INIT =================

void PPCScheduler::Init(PPCState* state, PPCJIT* j) {
    cpu = state;
    jit = j;
    currentCycle = 0;
    events.clear();
}

// ================= EVENT SYSTEM =================

void PPCScheduler::ScheduleEvent(uint64_t cyclesFromNow,
                                 SchedulerEventType type,
                                 uint32_t param) {
    SchedulerEvent ev;
    ev.cycle = currentCycle + cyclesFromNow;
    ev.type  = type;
    ev.param = param;

    events.push_back(ev);

    // Mantém ordenado por ciclo (fila simples, rápida)
    std::sort(events.begin(), events.end(),
        [](const SchedulerEvent& a, const SchedulerEvent& b) {
            return a.cycle < b.cycle;
        });
}

// ================= MAIN LOOP =================

void PPCScheduler::StepFrame(uint32_t cycles) {
    uint64_t targetCycle = currentCycle + cycles;

    while (currentCycle < targetCycle) {

        uint64_t nextEventCycle =
            events.empty() ? targetCycle : events.front().cycle;

        uint64_t sliceEnd = std::min(nextEventCycle, targetCycle);
        uint32_t sliceCycles = (uint32_t)(sliceEnd - currentCycle);

        if (sliceCycles > 0) {
            if (jit) {
                uint32_t executed = jit->Execute(*cpu, sliceCycles);
                currentCycle += executed;
            } else {
                cpu->Step();
                currentCycle++;
            }
        }

        // Processa eventos vencidos
        ProcessEvents();
    }
}

// ================= EVENT DISPATCH =================

void PPCScheduler::ProcessEvents() {
    while (!events.empty() && events.front().cycle <= currentCycle) {
        SchedulerEvent ev = events.front();
        events.erase(events.begin());
        HandleEvent(ev);
    }
}

// ================= EVENT HANDLER =================

void PPCScheduler::HandleEvent(const SchedulerEvent& ev) {
    switch (ev.type) {

        case SchedulerEventType::VBlank:
            cpu->RaiseIRQ(PPC_IRQ_VBLANK);
            // Agenda próximo VBlank (~60Hz)
            ScheduleEvent(486000, SchedulerEventType::VBlank);
            break;

        case SchedulerEventType::Timer:
            cpu->RaiseIRQ(PPC_IRQ_TIMER);
            break;

        case SchedulerEventType::DSP:
            cpu->RaiseIRQ(PPC_IRQ_DSP);
            // DSP roda em clock próprio
            ScheduleEvent(243000, SchedulerEventType::DSP);
            break;

        case SchedulerEventType::IRQ:
            cpu->RaiseIRQ(ev.param);
            break;
    }
}