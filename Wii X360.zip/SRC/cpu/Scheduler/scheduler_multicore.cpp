#include "scheduler.h"
#include <xtl.h>

static HANDLE threadCPU;
static HANDLE threadGPU;
static HANDLE threadIOS;

static volatile bool running = true;

PPCScheduler* gScheduler = nullptr;
PPCState*     gCPU = nullptr;
PPCJIT*       gJIT = nullptr;



DWORD WINAPI CPUThread(LPVOID) {

    while (running) {

        uint32_t slice = 2000;

        if (gJIT)
            gJIT->Execute(*gCPU, slice);
        else
            gCPU->Step();

        gScheduler->AdvanceCycles(slice);
    }

    return 0;
}



DWORD WINAPI GPUThread(LPVOID) {

    while (running) {

        GX::ProcessFIFO();
        DSP::StepAudio();

        Sleep(0);
    }

    return 0;
}


DWORD WINAPI IOSThread(LPVOID) {

    while (running) {

        IOS::ProcessIPC();
        IOS::UpdateDevices();

        Sleep(0);
    }

    return 0;
}



void PPCScheduler::StartMulticore(PPCState* cpu, PPCJIT* jit) {

    gCPU = cpu;
    gJIT = jit;
    gScheduler = this;

    threadCPU = CreateThread(
        0, 0, CPUThread, 0, 0, 0);

    threadGPU = CreateThread(
        0, 0, GPUThread, 0, 0, 0);

    threadIOS = CreateThread(
        0, 0, IOSThread, 0, 0, 0);
}



void PPCScheduler::StopMulticore() {

    running = false;

    WaitForSingleObject(threadCPU, INFINITE);
    WaitForSingleObject(threadGPU, INFINITE);
    WaitForSingleObject(threadIOS, INFINITE);
}