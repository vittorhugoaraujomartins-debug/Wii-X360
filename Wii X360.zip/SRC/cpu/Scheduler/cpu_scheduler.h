#pragma once
#include <cstdint>

class CPUScheduler {
public:
    void Reset();
    void AddCycles(uint32_t c);
    bool CanExecute(uint32_t c) const;
    void Step(uint32_t c);

private:
    uint64_t currentCycles = 0;
    uint64_t budgetCycles  = 0;
};