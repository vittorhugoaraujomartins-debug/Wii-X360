#pragma once
#include <cstdint>
#include <functional>
#include <vector>

namespace WiiCPU {

enum class EventType {
    IOS,
    GPU,
    Timer,
};

struct ScheduledEvent {
    uint64_t cycle;
    EventType type;
    std::function<void()> callback;
};

class CPUScheduler {
public:
    static void Init();
    static void Reset();

    static void Tick(uint32_t cycles);
    static uint64_t GetCycle();

    static void Schedule(uint64_t cycle, EventType type, std::function<void()> cb);

private:
    static uint64_t g_cycle;
    static std::vector<ScheduledEvent> g_events;
};

}