#pragma once
#include <stdint.h>
struct PPCFlags{bool CR0,CR1,SO,OV,CA;};
struct CPUState{
 uint32_t GPR[32];
 double FPR[32];
 uint32_t PC,LR,CTR,XER,MSR;
 PPCFlags flags;
};
extern CPUState gCPU;
