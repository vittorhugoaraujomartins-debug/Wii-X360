#include "cpu.h"
int CPU::SafeStep() {
    int c = Step();
    return (c<=0)?1:c;
}
