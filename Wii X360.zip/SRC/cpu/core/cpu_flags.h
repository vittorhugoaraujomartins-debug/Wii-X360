#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

struct CPUFlags {
    // MSR
    bool EE;   // External Interrupt Enable
    bool PR;   // Privilege
    bool FP;   // Floating Point
    bool IR;   // Instruction Relocate
    bool DR;   // Data Relocate

    // Estado de interrupção
    bool interruptPending;
};