#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void WiiInterruptController::Reset() {
    pendingMask = 0;
}

void WiiInterruptController::Raise(WiiInterrupt irq) {
    pendingMask |= (1 << ((uint32_t)irq >> 8));
}

void WiiInterruptController::Clear(WiiInterrupt irq) {
    pendingMask &= ~(1 << ((uint32_t)irq >> 8));
}

bool WiiInterruptController::HasPending() const {
    return pendingMask != 0;
}

uint32_t WiiInterruptController::GetVector() const {
    if (pendingMask & (1 << 5)) return 0x500; // VI
    if (pendingMask & (1 << 6)) return 0x600; // PI
    if (pendingMask & (1 << 7)) return 0x700; // DSP
    if (pendingMask & (1 << 9)) return 0x900; // IPC/DEC
    return 0;
}