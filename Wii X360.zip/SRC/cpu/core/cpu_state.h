#pragma once
#include <cstdint>

// ================= FLAGS PPC =================

struct PPCFlags {
    bool CR0;
    bool CR1;
    bool SO;
    bool OV;
    bool CA;
};

// ================= ESTADO DO CPU =================

struct CPUState {
    uint32_t GPR[32];
    double   FPR[32];

    uint32_t PC;
    uint32_t LR;
    uint32_t CTR;
    uint32_t XER;
    uint32_t MSR;

    uint32_t SRR0;
    uint32_t SRR1;

    PPCFlags flags;
};

// Estado global (CPU única)
extern CPUState gCPU;

#pragma once
#include <cstdint>

struct PPCFlags {
    bool CR0;
    bool SO;
    bool OV;
    bool CA;
};

struct CPUState {
    uint32_t GPR[32];
    double   FPR[32];

    uint32_t PC;
    uint32_t LR;
    uint32_t CTR;
    uint32_t XER;
    uint32_t MSR;

    PPCFlags flags;
};

extern CPUState gCPU;