#include "cpu_timer.h"

void CPUTimer::Reset() {
    dec = 0;
}

void CPUTimer::Tick(uint32_t cycles) {
    dec -= cycles;
}

bool CPUTimer::InterruptPending() const {
    return dec <= 0;
}