#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void CPUTimer::Reset() {
    dec = 0;
}

void CPUTimer::Tick(uint32_t cycles) {
    dec -= cycles;
}

bool CPUTimer::InterruptPending() const {
    return dec <= 0;
}

void CPUTimer::Reset() {
    dec = 0;
}

void CPUTimer::Tick(uint32_t cycles) {
    dec -= cycles;
}

bool CPUTimer::Expired() const {
    return dec <= 0;
}

#include "cpu_timer.h"
#include "wii_interrupts.h"

void CPUTimer::Reset() {
    dec = 0x10000;
}

void CPUTimer::Tick(uint32_t cycles) {
    dec -= cycles;
    if (dec <= 0) {
        WiiInterruptController::Raise(WiiInterrupt::DEC);
        dec += 0x10000; // período fake, mas estável
    }
}