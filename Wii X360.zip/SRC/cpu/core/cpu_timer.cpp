#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void CPUTimer::Reset() {
    dec = 0;
}

void CPUTimer::Tick(uint32_t cycles) {
    dec -= cycles;
}

bool CPUTimer::InterruptPending() const {
    return dec <= 0;
}

void CPUTimer::Reset() {
    dec = 0;
}

void CPUTimer::Tick(uint32_t cycles) {
    dec -= cycles;
}

bool CPUTimer::Expired() const {
    return dec <= 0;
}