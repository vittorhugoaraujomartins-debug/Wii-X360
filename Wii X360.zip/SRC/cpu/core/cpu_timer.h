#pragma once
#include <stdint.h>

class CPUTimer {
public:
    void Reset();
    void Tick(uint32_t cycles);

    bool Expired() const;

private:
    int32_t dec = 0;
};