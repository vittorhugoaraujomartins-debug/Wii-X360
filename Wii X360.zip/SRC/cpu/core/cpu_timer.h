#pragma once
#include <stdint.h>

class CPUTimer {
public:
    void Reset();
    void Tick(uint32_t cycles);

private:
    int32_t dec;
};