#pragma once
#include <cstdint>

class CPUTimer {
public:
    void Reset();
    void Tick(uint32_t cycles);
    bool InterruptPending() const;

private:
    int32_t dec = 0;
};