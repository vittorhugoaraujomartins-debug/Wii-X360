#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>

class CPUTimer {
public:
    void Reset();
    void Tick(uint32_t cycles);
    bool InterruptPending() const;

private:
    int32_t dec = 0;
};