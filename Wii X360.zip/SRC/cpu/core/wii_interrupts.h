#pragma once
#include <stdint.h>

enum class WiiInterrupt : uint32_t {
    VI  = 0x500,
    PI  = 0x600,
    DSP = 0x700,
    IPC = 0x900,
    DEC = 0x900
};

class WiiInterruptController {
public:
    void Reset();

    void Raise(WiiInterrupt irq);
    void Clear(WiiInterrupt irq);

    bool HasPending() const;
    uint32_t GetVector() const;

private:
    uint32_t pendingMask = 0;
};


#pragma once
#include <stdint.h>

enum class WiiInterrupt : uint32_t {
    VI  = 0x500,
    PI  = 0x600,
    DSP = 0x700,
    IPC = 0x900,
    DEC = 0x900
};

class WiiInterruptController {
public:
    void Reset();
    void Raise(WiiInterrupt irq);
    void Clear(WiiInterrupt irq);

    bool HasPending() const;
    uint32_t GetVector() const;

private:
    uint32_t pendingMask;
};