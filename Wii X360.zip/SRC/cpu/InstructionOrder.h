#pragma once
#include <cstdint>

namespace InstrOrder {

    // Garante que todas as escritas anteriores foram vistas
    inline void MemoryBarrier();

    // Para IO / FIFO / GX
    inline void IOBarrier();

    // Para self-modifying code
    inline void CodeBarrier(uint32_t addr, uint32_t size);
}