
#include "cpu.h"
uint32_t CPU::ANDI(uint32_t a,uint16_t imm){ return a & imm; }
uint32_t CPU::ORI(uint32_t a,uint16_t imm){ return (a & 0xFFFF0000) | imm; }
