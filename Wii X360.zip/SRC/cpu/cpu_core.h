#pragma once
#include <cstdint>

namespace CPU {

void Init();
void Reset();

// Executa N ciclos
void Step(uint32_t cycles);

// Interrupções
void RaiseInterrupt(uint32_t vector);

}