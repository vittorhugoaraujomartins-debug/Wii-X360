
#include "mmu.h"
uint32_t MMU::PageMask(int size){
    if(size==4*1024) return 0xFFFFF000;
    if(size==64*1024) return 0xFFFF0000;
    if(size==1024*1024) return 0xFFF00000;
    return 0xFFFFF000;
}
