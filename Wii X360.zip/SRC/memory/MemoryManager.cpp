#include "MemoryManager.h"
#include "memory_map.h"

bool MemoryManager::Init() {
    return WiiMem::Init();
}

void MemoryManager::Shutdown() {
    WiiMem::Shutdown();
}

uint8_t* MemoryManager::Translate(uint32_t addr) {
    return WiiMem::Translate(addr);
}

MemoryRegionInfo MemoryManager::GetRegion(MemoryRegion region) {
    using namespace WiiMem;

    switch (region) {
        case MemoryRegion::MEM1:
            return { Translate(MEM1_START), MEM1_SIZE };

        case MemoryRegion::MEM2:
            return { Translate(MEM2_START), MEM2_SIZE };

        case MemoryRegion::ROM:
            return { Translate(ROM_START), ROM_SIZE };

        default:
            return { nullptr, 0 };
    }
}

// =========================
// Read
// =========================

uint8_t MemoryManager::Read8(uint32_t addr) {
    return WiiMem::Read8(addr);
}

uint16_t MemoryManager::Read16(uint32_t addr) {
    return WiiMem::Read16(addr);
}

uint32_t MemoryManager::Read32(uint32_t addr) {
    return WiiMem::Read32(addr);
}

// =========================
// Write
// =========================

void MemoryManager::Write8(uint32_t addr, uint8_t v) {
    WiiMem::Write8(addr, v);
}

void MemoryManager::Write16(uint32_t addr, uint16_t v) {
    WiiMem::Write16(addr, v);
JIT::Invalidate(addr, sizeof(T));
}

void MemoryManager::Write32(uint32_t addr, uint32_t v) {
    WiiMem::Write32(addr, v);
}
