#pragma once
#include <cstdint>

namespace WiiX360 {

struct RamBlock {
    uint8_t* base;
    uint32_t size;
};

class RamManager {
public:
    static bool Init();
    static void Shutdown();

    static RamBlock GetCpuRam();
    static RamBlock GetCpuCache();
    static RamBlock GetGpuRam();
    static RamBlock GetGpuCache();
    static RamBlock GetSyncBuffer();

private:
    static uint8_t* ramBase;
};

}