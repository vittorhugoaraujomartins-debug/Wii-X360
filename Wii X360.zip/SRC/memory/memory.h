#pragma once
#include <stdint.h>
#include <vector>

class WiiMemory {
public:
    void Init();
    void Reset();

    uint8_t* GetPointer(uint32_t physicalAddr);

    static const uint32_t MEM1_SIZE = 24 * 1024 * 1024;
    static const uint32_t MEM2_SIZE = 64 * 1024 * 1024;

private:
    std::vector<uint8_t> mem1;
    std::vector<uint8_t> mem2;
};