#pragma once
#include <cstdint>

enum class MemoryRegion {
    MEM1,
    MEM2,
    ROM
};

struct MemoryRegionInfo {
    uint8_t* base;
    uint32_t size;
};

class MemoryManager {
public:
    static bool Init();
    static void Shutdown();

    static uint8_t* Translate(uint32_t addr);

    static MemoryRegionInfo GetRegion(MemoryRegion region);

    // Leitura segura (Big Endian)
    static uint8_t  Read8(uint32_t addr);
    static uint16_t Read16(uint32_t addr);
    static uint32_t Read32(uint32_t addr);

    // Escrita segura + invalidação JIT
    static void Write8(uint32_t addr, uint8_t v);
    static void Write16(uint32_t addr, uint16_t v);
    static void Write32(uint32_t addr, uint32_t v);
};
