#include "memory.h"

void WiiMemory::Init() {
    mem1.resize(MEM1_SIZE);
    mem2.resize(MEM2_SIZE);
}

void WiiMemory::Reset() {
    memset(mem1.data(), 0, MEM1_SIZE);
    memset(mem2.data(), 0, MEM2_SIZE);
}

uint8_t* WiiMemory::GetPointer(uint32_t pa) {
    if (pa < MEM1_SIZE)
        return &mem1[pa];

    if (pa >= 0x10000000 &&
        pa < 0x10000000 + MEM2_SIZE)
        return &mem2[pa - 0x10000000];

    return nullptr;
}