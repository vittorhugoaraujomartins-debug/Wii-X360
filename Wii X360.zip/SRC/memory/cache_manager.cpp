#include "cache_manager.h"

void CacheManager::InvalidateRange(uint32_t address, uint32_t size)
{
    for (uint32_t i = 0; i < size; i += 32) // 32-byte cache line
    {
        InvalidateLine(address + i);
    }
}

void CacheManager::FlushRange(uint32_t address, uint32_t size)
{
    // Write-back logic here
}

void CacheManager::InvalidateLine(uint32_t address)
{
    // Mark line invalid in your cache table
}