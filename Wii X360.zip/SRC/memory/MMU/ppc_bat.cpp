#include "ppc_bat.h"

static inline uint32_t BATBlockSize(uint32_t batu) {
    uint32_t bl = (batu >> 2) & 0x7FF;
    return (bl + 1) << 17; // tamanho real do bloco
}

void PPCBATUnit::Reset() {
    for (int i = 0; i < 4; i++) {
        ibat[i] = {};
        dbat[i] = {};
    }
}

bool PPCBATUnit::Translate(
    uint32_t ea,
    uint32_t& pa,
    bool isInstruction
) const {
    const PPCBAT* bat = isInstruction ? ibat : dbat;

    for (int i = 0; i < 4; i++) {
        uint32_t batu = bat[i].batu;
        uint32_t batl = bat[i].batl;

        if (!(batu & 0x1)) // válido?
            continue;

        uint32_t baseEA = batu & 0xFFFE0000;
        uint32_t size   = BATBlockSize(batu);

        if (ea >= baseEA && ea < baseEA + size) {
            uint32_t basePA = batl & 0xFFFE0000;
            pa = basePA + (ea - baseEA);
            return true;
        }
    }

    return false;
}