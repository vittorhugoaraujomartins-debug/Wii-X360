#include "wii_memory.h"
#include <stdlib.h>
#include <string.h>

namespace WiiMem {

static uint8_t* mem1 = nullptr;
static uint8_t* mem2 = nullptr;

bool Init()
{
    mem1 = (uint8_t*)malloc(MEM1_SIZE);
    mem2 = (uint8_t*)malloc(MEM2_SIZE);

    if (!mem1 || !mem2)
        return false;

    memset(mem1, 0, MEM1_SIZE);
    memset(mem2, 0, MEM2_SIZE);

    return true;
}

void Shutdown()
{
    if (mem1) free(mem1);
    if (mem2) free(mem2);
}

uint8_t* GetPointer(uint32_t addr)
{
    if (addr >= MEM1_BASE && addr < MEM1_BASE + MEM1_SIZE)
        return mem1 + (addr - MEM1_BASE);

    if (addr >= MEM2_BASE && addr < MEM2_BASE + MEM2_SIZE)
        return mem2 + (addr - MEM2_BASE);

    return nullptr;
}

uint32_t Read32(uint32_t addr)
{
    uint8_t* p = GetPointer(addr);
    if (!p) return 0;

    return (p[0] << 24) | (p[1] << 16) |
           (p[2] << 8)  | p[3];
}

void Write32(uint32_t addr, uint32_t v)
{
    uint8_t* p = GetPointer(addr);
    if (!p) return;

    p[0] = (v >> 24) & 0xFF;
    p[1] = (v >> 16) & 0xFF;
    p[2] = (v >> 8)  & 0xFF;
    p[3] = v & 0xFF;
}

}



if (pa >= o 0xCC000000 && pa < 0x0D000000)
{
    MMIO::Write32(pa, value);
    return;
}