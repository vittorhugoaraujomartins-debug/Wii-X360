#pragma once
#include <stdint.h>

struct PPCTLBEntry {
    uint32_t eaBase;
    uint32_t paBase;
    uint32_t size;
    bool valid;
};

class PPCTLB {
public:
    void Reset();

    bool Translate(uint32_t ea, uint32_t& pa) const;

private:
    PPCTLBEntry entries[16];
};