#pragma once
#include <stdint.h>

bool TLB_Translate(uint32_t va, uint32_t& pa, bool isWrite);

#pragma once
#include <stdint.h>

enum MemPerm {
    MEM_R = 1,
    MEM_W = 2,
    MEM_X = 4
};

struct TLBEntry {
    uint32_t vaddr;
    uint32_t paddr;
    uint32_t size;
    uint8_t  perm;
};

void TLB_Reset();
void TLB_Map(uint32_t vaddr, uint32_t paddr, uint32_t size, uint8_t perm);
TLBEntry* TLB_Find(uint32_t addr);