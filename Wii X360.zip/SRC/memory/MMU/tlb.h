#pragma once
#include <stdint.h>

bool TLB_Translate(uint32_t va, uint32_t& pa, bool isWrite);