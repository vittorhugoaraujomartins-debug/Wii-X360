#pragma once
#include <stdint.h>

struct PPCBAT {
    uint32_t batu; // upper
    uint32_t batl; // lower
};

class PPCBATUnit {
public:
    void Reset();

    // IBAT / DBAT
    PPCBAT ibat[4];
    PPCBAT dbat[4];

    bool Translate(
        uint32_t ea,
        uint32_t& pa,
        bool isInstruction
    ) const;
};