#pragma once
#include <stdint.h>

namespace MMU {

// ===== RAM DO WII =====
extern uint8_t* MEM1; // 24 MB
extern uint8_t* MEM2; // 64 MB

bool InitMemory();
void ShutdownMemory();

}