#pragma once
#include <stdint.h>

struct BAT {
    uint32_t bepi;
    uint32_t brpn;
    uint32_t size;
    bool valid;
};

void BAT_Reset();
bool BAT_Translate(uint32_t va, uint32_t& pa, bool isInstr);