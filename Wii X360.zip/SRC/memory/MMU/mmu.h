#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once
// FIXME: include not found in project (left original below):

enum class MMUFault {
    None,
    ISI,
    DSI
};

class MMU {
public:
    void Reset();

    bool Translate(uint32_t ea, uint32_t& pa,
                   bool isWrite, bool isExec,
                   MMUFault& fault);

    BAT& GetBAT() { return bat; }

private:
    BAT bat;
};