#pragma once
#include <cstdint>
#include <functional>

class PPCState;

namespace MMU
{
    constexpr uint32_t MEM1_SIZE = 24 * 1024 * 1024;
    constexpr uint32_t MEM2_SIZE = 64 * 1024 * 1024;

    void Init();

    uint8_t  Read8(PPCState* cpu, uint32_t addr);
    uint16_t Read16(PPCState* cpu, uint32_t addr);
    uint32_t Read32(PPCState* cpu, uint32_t addr);

    void Write8(PPCState* cpu, uint32_t addr, uint8_t val);
    void Write16(PPCState* cpu, uint32_t addr, uint16_t val);
    void Write32(PPCState* cpu, uint32_t addr, uint32_t val);

    void InvalidateCode(uint32_t physAddr);

    bool Translate(PPCState* cpu,
                   uint32_t ea,
                   uint32_t& phys,
                   bool isWrite,
                   bool isExec);
}