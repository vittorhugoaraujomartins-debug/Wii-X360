#include "mmu_memory.h"
#include <stdlib.h>
#include <string.h>

namespace MMU {

uint8_t* MEM1 = nullptr;
uint8_t* MEM2 = nullptr;

bool InitMemory() {

    MEM1 = (uint8_t*)malloc(24 * 1024 * 1024);
    MEM2 = (uint8_t*)malloc(64 * 1024 * 1024);

    if (!MEM1 || !MEM2) return false;

    memset(MEM1, 0, 24 * 1024 * 1024);
    memset(MEM2, 0, 64 * 1024 * 1024);

    return true;
}

void ShutdownMemory() {
    free(MEM1);
    free(MEM2);
}

}