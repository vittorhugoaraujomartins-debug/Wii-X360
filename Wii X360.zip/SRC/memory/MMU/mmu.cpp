#include "MMU.h"
#include "ppc_state.h"
#include "ppc_exceptions.h"
#include <cstring>

static uint8_t MEM1[MMU::MEM1_SIZE];
static uint8_t MEM2[MMU::MEM2_SIZE];

namespace
{
    inline uint32_t ToPhysical(uint32_t addr)
    {
        // Remove espelhamento 0x80000000 / 0x90000000
        if (addr >= 0x80000000 && addr < 0xA0000000)
            return addr - 0x80000000;

        return addr;
    }

    inline uint32_t ReadBE32(uint8_t* base, uint32_t p)
    {
        return (base[p] << 24) |
               (base[p + 1] << 16) |
               (base[p + 2] << 8) |
               (base[p + 3]);
    }

    inline void WriteBE32(uint8_t* base, uint32_t p, uint32_t v)
    {
        base[p]     = (v >> 24) & 0xFF;
        base[p + 1] = (v >> 16) & 0xFF;
        base[p + 2] = (v >> 8) & 0xFF;
        base[p + 3] = v & 0xFF;
    }
}



uint32_t MMU::Read32(PPCState* cpu, uint32_t addr)
{
    uint32_t phys;
    if (!Translate(cpu, addr, phys, false, false))
    {
        PPC_RaiseException(*cpu, EXC_DSI);
        return 0;
    }

    if (phys < MEM1_SIZE)
        return ReadBE32(MEM1, phys);

    if (phys >= 0x10000000 &&
        phys < 0x10000000 + MEM2_SIZE)
        return ReadBE32(MEM2, phys - 0x10000000);

    return 0;
}


void MMU::Write32(PPCState* cpu, uint32_t addr, uint32_t val)
{
    uint32_t phys;
    if (!Translate(cpu, addr, phys, true, false))
    {
        PPC_RaiseException(*cpu, EXC_DSI);
        return;
    }

    if (phys < MEM1_SIZE)
    {
        WriteBE32(MEM1, phys, val);
        InvalidateCode(phys);
        return;
    }

    if (phys >= 0x10000000 &&
        phys < 0x10000000 + MEM2_SIZE)
    {
        WriteBE32(MEM2, phys - 0x10000000, val);
        InvalidateCode(phys);
        return;
    }
}


extern PPCBlockCache gBlockCache;

void MMU::InvalidateCode(uint32_t physAddr)
{
    gBlockCache.Invalidate(physAddr);
}



