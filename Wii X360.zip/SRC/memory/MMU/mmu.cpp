#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void MMU::Reset() {
    bat.Reset();
}

bool MMU::Translate(uint32_t ea, uint32_t& pa,
                    bool isWrite, bool isExec,
                    MMUFault& fault) {


bool MMU::Translate(
    uint32_t ea,
    uint32_t& pa,
    bool isWrite,
    bool isInstruction,
    MMUFault& fault
bool MMU::Translate(
    uint32_t ea,
    uint32_t& pa,
    bool isWrite,
    bool isInstruction,
    MMUFault& fault {
    // 1️⃣ BAT
    if (bat.Translate(ea, pa, isInstruction))
        return true;

    // 2️⃣ TLB
    if (tlb.Translate(ea, pa))
        return true;

    fault = isInstruction ? MMUFault::ISI : MMUFault::DSI;
    return false;
}
    if (bat.Translate(ea, pa, isWrite, isExec)) {
        fault = MMUFault::None;
        return true;
 
) {
    // 🔹 BAT primeiro
    if (bat.Translate(ea, pa, isInstruction)) {
        return true;
    }

    // 🔹 Depois TLB (futuro)
    // 🔹 Depois page table (futuro)

    fault = isInstruction ? MMUFault::ISI : MMUFault::DSI;
    return false;
}   }

    // Espelhamento Wii clássico
    if ((ea & 0xF0000000) == 0x80000000 ||
        (ea & 0xF0000000) == 0x90000000) {
        pa = ea & 0x1FFFFFFF;
        fault = MMUFault::None;
        return true;
    }

    fault = isExec ? MMUFault::ISI : MMUFault::DSI;
    return false;
}

    // Mapeia 0x80000000 → 0x00000000 (256MB)
    bat.dbat[0].batu = 0x80000000 | 0x1; // válido
    bat.dbat[0].batl = 0x00000002;

    bat.ibat[0] = bat.dbat[0];
}

void MMU::Reset() {
    bat.Reset();
    tlb.Reset();
}


#include "mmu.h"
#include "tlb.h"

bool MMU_Check(uint32_t addr, AccessType type) {
    auto* e = TLB_Find(addr);
    if (!e) return false;

    if (type == ACCESS_READ  && !(e->perm & MEM_R)) return false;
    if (type == ACCESS_WRITE && !(e->perm & MEM_W)) return false;
    if (type == ACCESS_EXEC  && !(e->perm & MEM_X)) return false;

    return true;
}

uint32_t MMU_Translate(uint32_t addr) {
    auto* e = TLB_Find(addr);
    if (!e) return 0;

    return e->paddr + (addr - e->vaddr);
}