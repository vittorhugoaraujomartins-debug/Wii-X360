#include "ppc_tlb.h"

void PPCTLB::Reset() {
    for (int i = 0; i < 16; i++) {
        entries[i].valid = false;
    }

    // 🔹 TLB fake identity (256MB)
    entries[0] = {
        0x00000000,
        0x00000000,
        0x10000000, // 256MB
        true
    };
}

bool PPCTLB::Translate(uint32_t ea, uint32_t& pa) const {
    for (int i = 0; i < 16; i++) {
        const /*auto*/& e = entries[i];
        if (!e.valid) continue;

        if (ea >= e.eaBase && ea < e.eaBase + e.size) {
            pa = e.paBase + (ea - e.eaBase);
            return true;
        }
    }
    return false;
}