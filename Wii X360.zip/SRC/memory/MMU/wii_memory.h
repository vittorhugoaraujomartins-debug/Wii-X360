#pragma once
#include <stdint.h>

namespace WiiMem {

// MEM1 = 24MB
static const uint32_t MEM1_BASE = 0x80000000;
static const uint32_t MEM1_SIZE = 24 * 1024 * 1024;

// MEM2 = 64MB
static const uint32_t MEM2_BASE = 0x90000000;
static const uint32_t MEM2_SIZE = 64 * 1024 * 1024;

bool Init();
void Shutdown();

uint8_t* GetPointer(uint32_t addr);

uint32_t Read32(uint32_t addr);
void Write32(uint32_t addr, uint32_t value);

}