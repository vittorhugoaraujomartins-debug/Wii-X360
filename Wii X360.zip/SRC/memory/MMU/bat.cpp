#include "bat.h"

static BAT ibat[4];
static BAT dbat[4];

void BAT_Reset() {
    for (int i = 0; i < 4; i++) {
        ibat[i] = {};
        dbat[i] = {};
    }

    // Mapeamento padrão Wii
    dbat[0] = { 0x80000000 >> 17, 0x80000000 >> 17, 256 * 1024 * 1024, true };
    ibat[0] = dbat[0];
}

bool BAT_Translate(uint32_t va, uint32_t& pa, bool isInstr) {
    BAT* b = isInstr ? ibat : dbat;

    for (int i = 0; i < 4; i++) {
        if (!b[i].valid) continue;

        uint32_t base = b[i].bepi << 17;
        if (va >= base && va < base + b[i].size) {
            pa = (b[i].brpn << 17) | (va & (b[i].size - 1));
            return true;
        }
    }
    return false;
}