#include "tlb.h"

bool TLB_Translate(uint32_t va, uint32_t& pa, bool isWrite) {
    // Stub: identidade
    pa = va;
    return true;
}