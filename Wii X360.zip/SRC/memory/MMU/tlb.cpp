#include "tlb.h"

bool TLB_Translate(uint32_t va, uint32_t& pa, bool isWrite) {
    // Stub: identidade
    pa = va;
    return true;
}

#include "tlb.h"

static TLBEntry g_tlb[16];
static int g_tlbCount = 0;

void TLB_Reset() {
    g_tlbCount = 0;
}

void TLB_Map(uint32_t vaddr, uint32_t paddr, uint32_t size, uint8_t perm) {
    if (g_tlbCount >= 16)
        return;

    g_tlb[g_tlbCount++] = { vaddr, paddr, size, perm };
}

TLBEntry* TLB_Find(uint32_t addr) {
    for (int i = 0; i < g_tlbCount; i++) {
        /*auto*/& e = g_tlb[i];
        if (addr >= e.vaddr && addr < e.vaddr + e.size)
            return &e;
    }
    return NULL;
}