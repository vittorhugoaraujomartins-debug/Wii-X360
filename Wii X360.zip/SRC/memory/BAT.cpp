#include "BAT.h"

static uint32_t DecodeBATSize(uint32_t bl) {
    // BL encoding: size = 128KB << BL
    return 0x20000 << bl;
}

void BAT::Reset() {
    for (int i = 0; i < 4; i++) {
        ibat[i] = {};
        dbat[i] = {};
    }
}

void BAT::WriteIBAT(int index, uint32_t upper, uint32_t lower) {
    BATEntry& b = ibat[index];
    b.valid = (upper & 0x1) != 0;
    b.bepi = upper & 0xFFFE0000;
    b.brpn = lower & 0xFFFE0000;
    b.size = DecodeBATSize((upper >> 2) & 0xF);
    b.writable = (lower & 0x2) != 0;
    b.executable = true;
}

void BAT::WriteDBAT(int index, uint32_t upper, uint32_t lower) {
    BATEntry& b = dbat[index];
    b.valid = (upper & 0x1) != 0;
    b.bepi = upper & 0xFFFE0000;
    b.brpn = lower & 0xFFFE0000;
    b.size = DecodeBATSize((upper >> 2) & 0xF);
    b.writable = (lower & 0x2) != 0;
    b.executable = false;
}

bool BAT::Translate(uint32_t ea, uint32_t& pa, bool isWrite, bool isExec) const {
    const BATEntry* table = isExec ? ibat : dbat;

    for (int i = 0; i < 4; i++) {
        const BATEntry& b = table[i];
        if (!b.valid) continue;

        if ((ea & ~(b.size - 1)) == b.bepi) {
            if (isWrite && !b.writable) return false;
            if (isExec && !b.executable) return false;

            pa = b.brpn | (ea & (b.size - 1));
            return true;
        }
    }
    return false;
}