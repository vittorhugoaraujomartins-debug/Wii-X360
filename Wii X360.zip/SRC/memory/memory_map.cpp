#include "memory_map.h"
#include "ppc_jit.h"
#include <cstdlib>
#include <cstring>
#include <fstream>

namespace WiiMem {

static uint8_t* mem1 = nullptr;
static uint8_t* mem2 = nullptr;
static uint8_t* rom  = nullptr;

static inline uint16_t Swap16(uint16_t v) {
    return (v >> 8) | (v << 8);
}

static inline uint32_t Swap32(uint32_t v) {
    return __builtin_bswap32(v);
}

// =========================
// Init / Shutdown
// =========================

bool Init() {
    mem1 = (uint8_t*)malloc(MEM1_SIZE);
    mem2 = (uint8_t*)malloc(MEM2_SIZE);
    rom  = (uint8_t*)malloc(ROM_SIZE);

    if (!mem1 || !mem2 || !rom)
        return false;

    memset(mem1, 0, MEM1_SIZE);
    memset(mem2, 0, MEM2_SIZE);
    memset(rom,  0, ROM_SIZE);

    return true;
}

void Shutdown() {
    free(mem1); mem1 = nullptr;
    free(mem2); mem2 = nullptr;
    free(rom);  rom  = nullptr;
}

// =========================
// Address translation
// =========================

uint8_t* Translate(uint32_t addr) {
    if (addr >= MEM1_START && addr < MEM1_START + MEM1_SIZE)
        return mem1 + (addr - MEM1_START);

    if (addr >= MEM2_START && addr < MEM2_START + MEM2_SIZE)
        return mem2 + (addr - MEM2_START);

    if (addr >= ROM_START && addr < ROM_START + ROM_SIZE)
        return rom + (addr - ROM_START);

    return nullptr;
}

bool IsValidAddress(uint32_t addr) {
    return Translate(addr) != nullptr;
}

// =========================
// Read
// =========================

uint8_t Read8(uint32_t addr) {
    uint8_t* p = Translate(addr);
    return p ? *p : 0;
}

uint16_t Read16(uint32_t addr) {
    uint8_t* p = Translate(addr);
    if (!p) return 0;

    uint16_t v;
    memcpy(&v, p, 2);
    return Swap16(v);
}

uint32_t Read32(uint32_t addr) {
    uint8_t* p = Translate(addr);
    if (!p) return 0;

    uint32_t v;
    memcpy(&v, p, 4);
    return Swap32(v);
}

// =========================
// Write + JIT invalidation
// =========================

extern PPCJIT g_jit;

void Write8(uint32_t addr, uint8_t v) {
    uint8_t* p = Translate(addr);
    if (!p) return;

    *p = v;
    g_jit.InvalidateRange(addr, 1);
}

void Write16(uint32_t addr, uint16_t v) {
    uint8_t* p = Translate(addr);
    if (!p) return;

    uint16_t sv = Swap16(v);
    memcpy(p, &sv, 2);
    g_jit.InvalidateRange(addr, 2);
}

void Write32(uint32_t addr, uint32_t v) {
    uint8_t* p = Translate(addr);
    if (!p) return;

    uint32_t sv = Swap32(v);
    memcpy(p, &sv, 4);
    g_jit.InvalidateRange(addr, 4);
}

// =========================
// ROM
// =========================

bool LoadROM(const char* path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open())
        return false;

    file.read((char*)rom, ROM_SIZE);
    file.close();
    return true;
}

}


#include "memory_map.h"
#include "ram_manager.h"

namespace memorymap {

Region Resolve(uint32_t pa) {
    if (pa < 0x01800000)
        return MEM1;

    if (pa >= 0x10000000 && pa < 0x14000000)
        return MEM2;

    return INVALID;
}

uint8_t* GetPointer(uint32_t pa) {
    if (pa < 0x01800000)
        return WiiX360::RamManager::GetMEM1() + pa;

    if (pa >= 0x10000000 && pa < 0x14000000)
        return WiiX360::RamManager::GetMEM2() + (pa - 0x10000000);

    return nullptr;
}

}