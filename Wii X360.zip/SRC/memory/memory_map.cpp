#include "memory_map.h"

static uint8_t* g_base = nullptr;

void MemoryMap::Init(uint8_t* base) {
    g_base = base;
}

MemoryMap::Region MemoryMap::Resolve(uint32_t pa) {
    if (pa < 0x01800000) return Region::MEM1;
    if (pa >= 0x10000000 && pa < 0x14000000) return Region::MEM2;
    return Region::INVALID;
}

uint8_t* MemoryMap::Translate(uint32_t pa) {
    switch (Resolve(pa)) {
    case Region::MEM1: return g_base + pa;
    case Region::MEM2: return g_base + (pa - 0x10000000);
    default: return nullptr;
    }
}