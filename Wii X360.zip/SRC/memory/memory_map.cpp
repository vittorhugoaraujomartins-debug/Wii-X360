#include "memory_map.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


static uint8_t* g_base = nullptr;

void MemoryMap::Init(uint8_t* base) {
    g_base = base;
}

MemoryMap::Region MemoryMap::Resolve(uint32_t pa) {
    if (pa < 0x01800000) return Region::MEM1;
    if (pa >= 0x10000000 && pa < 0x14000000) return Region::MEM2;
    return Region::INVALID;
}

uint8_t* MemoryMap::Translate(uint32_t pa) {
    switch (Resolve(pa)) {
    case Region::MEM1: return g_base + pa;
    case Region::MEM2: return g_base + (pa - 0x10000000);
    default: return nullptr;
    }
}

// FIXME: include not found in project (left original below):

namespace Memory {

bool Init() {
    return WiiMem::Init();
}

void Shutdown() {
    WiiMem::Shutdown();
}

uint8_t Read8(uint32_t addr) {
    return WiiMem::Read8(addr);
}

uint16_t Read16(uint32_t addr) {
    return WiiMem::Read16(addr);
}

uint32_t Read32(uint32_t addr) {
    return WiiMem::Read32(addr);
}

void Write8(uint32_t addr, uint8_t v) {
    WiiMem::Write8(addr, v);
    PPCJIT::InvalidateRange(addr, 1);
}

void Write16(uint32_t addr, uint16_t v) {
    WiiMem::Write16(addr, v);
    PPCJIT::InvalidateRange(addr, 2);
}

void Write32(uint32_t addr, uint32_t v) {
    WiiMem::Write32(addr, v);
    PPCJIT::InvalidateRange(addr, 4);
}

}