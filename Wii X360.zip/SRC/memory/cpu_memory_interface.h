#pragma once
#include <stdint.h>

namespace CPU {

uint8_t  Read8(uint32_t addr);
uint32_t Read32(uint32_t addr);

void Write8(uint32_t addr, uint8_t v);
void Write32(uint32_t addr, uint32_t v);

}