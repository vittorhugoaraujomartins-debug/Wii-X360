#include "cpu_memory_interface.h"
#include "mmu_translate.h"

namespace CPU {

uint8_t Read8(uint32_t addr) {
    return MMU::Read8(addr);
}

uint32_t Read32(uint32_t addr) {
    return MMU::Read32(addr);
}

void Write8(uint32_t addr, uint8_t v) {
    MMU::Write8(addr, v);
}

void Write32(uint32_t addr, uint32_t v) {
    MMU::Write32(addr, v);
}

}