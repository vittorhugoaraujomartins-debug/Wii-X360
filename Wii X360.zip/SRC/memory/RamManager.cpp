#include "ram_manager.h"
#include <xtl.h>

namespace WiiX360 {

uint8_t* RamManager::ramBase = nullptr;

static RamBlock cpuRam;
static RamBlock cpuCache;
static RamBlock gpuRam;
static RamBlock gpuCache;
static RamBlock syncBuffer;

bool RamManager::Init() {
    // Xbox 360: 512 MB
    ramBase = (uint8_t*)XPhysicalAlloc(
        0x20000000,        // 512 MB
        MAXULONG_PTR,
        0,
        PAGE_READWRITE
    );

    if (!ramBase)
        return false;

    uint32_t offset = 0;

    cpuRam = { ramBase + offset, 0x10000000 }; // 256 MB
    offset += cpuRam.size;

    cpuCache = { ramBase + offset, 0x04000000 }; // 64 MB
    offset += cpuCache.size;

    gpuRam = { ramBase + offset, 0x08000000 }; // 128 MB
    offset += gpuRam.size;

    gpuCache = { ramBase + offset, 0x04000000 }; // 64 MB
    offset += gpuCache.size;

    syncBuffer = { ramBase + offset, 0x02000000 }; // 32 MB

    return true;
}

RamBlock RamManager::GetCpuRam()     { return cpuRam; }
RamBlock RamManager::GetCpuCache()   { return cpuCache; }
RamBlock RamManager::GetGpuRam()     { return gpuRam; }
RamBlock RamManager::GetGpuCache()   { return gpuCache; }
RamBlock RamManager::GetSyncBuffer() { return syncBuffer; }

void RamManager::Shutdown() {
    if (ramBase) {
        XPhysicalFree(ramBase);
        ramBase = nullptr;
    }
}

}