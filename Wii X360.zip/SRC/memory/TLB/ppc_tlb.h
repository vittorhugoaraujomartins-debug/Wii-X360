#pragma once
#include <stdint.h>

struct PPCTLBEntry {
    uint32_t eaBase;
    uint32_t paBase;
    uint32_t size;
    uint8_t  perm;
    bool     valid;
};

class PPCTLB {
public:
    void Reset();
    void Map(uint32_t ea, uint32_t pa,
             uint32_t size, uint8_t perm);

    bool Translate(uint32_t ea,
                   uint32_t& pa,
                   bool isWrite,
                   bool isExec) const;

private:
    PPCTLBEntry entries[32];
};



namespace MMU {

struct TLBEntry {
    uint32_t vaddr;
    uint32_t paddr;
    uint32_t size;
    bool valid;
};

extern TLBEntry TLB[64];

uint32_t TranslateTLB(uint32_t addr);

}