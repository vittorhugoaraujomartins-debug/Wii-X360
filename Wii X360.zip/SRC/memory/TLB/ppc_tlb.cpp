#include "ppc_tlb.h"

void PPCTLB::Reset() {
    for (int i = 0; i < 32; i++)
        entries[i].valid = false;
}

void PPCTLB::Map(uint32_t ea,
                 uint32_t pa,
                 uint32_t size,
                 uint8_t perm)
{
    for (int i = 0; i < 32; i++) {
        if (!entries[i].valid) {
            entries[i] = { ea, pa, size, perm, true };
            return;
        }
    }
}

bool PPCTLB::Translate(uint32_t ea,
                       uint32_t& pa,
                       bool isWrite,
                       bool isExec) const
{
    for (int i = 0; i < 32; i++) {
        const auto& e = entries[i];
        if (!e.valid)
            continue;

        if (ea >= e.eaBase &&
            ea < e.eaBase + e.size)
        {
            if (isWrite && !(e.perm & 2))
                return false;
            if (isExec && !(e.perm & 4))
                return false;

            pa = e.paBase + (ea - e.eaBase);
            return true;
        }
    }

    return false;
}




#include "ppc_tlb.h"

namespace MMU {

TLBEntry TLB[64];

uint32_t TranslateTLB(uint32_t addr) {

    for (int i = 0; i < 64; i++) {

        if (!TLB[i].valid) continue;

        uint32_t base = TLB[i].vaddr;

        if (addr >= base && addr < base + TLB[i].size) {

            uint32_t offset = addr - base;
            return TLB[i].paddr + offset;
        }
    }

    return 0xFFFFFFFF;
}

}