#include "MemoryAccess.h"
#include "MMU.h"
#include "memory_map.h"
#include <cstring>

extern MMU g_mmu;

static inline uint32_t BSWAP16(uint16_t v) {
    return (v >> 8) | (v << 8);
}

static inline uint32_t BSWAP32(uint32_t v) {
    return __builtin_bswap32(v);
}

namespace MemoryAccess {

uint8_t Read8(uint32_t ea) {
    uint32_t pa;
    MMUFault f;
    if (!g_mmu.Translate(ea, pa, false, false, f))
        return 0;

    uint8_t* ptr = memory_map::GetPointer(pa);
    return ptr ? *ptr : 0;
}

uint16_t Read16(uint32_t ea) {
    uint32_t pa;
    MMUFault f;
    if (!g_mmu.Translate(ea, pa, false, false, f))
        return 0;

    uint16_t v;
    memcpy(&v, memory_map::GetPointer(pa), 2);
    return BSWAP16(v);
}

uint32_t Read32(uint32_t ea) {
    uint32_t pa;
    MMUFault f;
    if (!g_mmu.Translate(ea, pa, false, false, f))
        return 0;

    uint32_t v;
    memcpy(&v, memory_map::GetPointer(pa), 4);
    return BSWAP32(v);
}

void Write32(uint32_t ea, uint32_t v) {
    uint32_t pa;
    MMUFault f;
    if (!g_mmu.Translate(ea, pa, true, false, f))
        return;

    v = BSWAP32(v);
    memcpy(memory_map::GetPointer(pa), &v, 4);
}

}