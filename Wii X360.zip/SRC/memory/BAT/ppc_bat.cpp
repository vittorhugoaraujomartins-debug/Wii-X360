#include "ppc_bat.h"

static inline uint32_t BATBlockSize(uint32_t batu) {
    uint32_t bl = (batu >> 2) & 0x7FF;
    return (bl + 1) << 17;
}

void PPCBATUnit::Reset() {
    memset(ibat, 0, sizeof(ibat));
    memset(dbat, 0, sizeof(dbat));
}

void PPCBATUnit::SetupWiiDefaults() {
    // Mapeia 0x80000000 → 0x00000000 (MEM1 espelho)
    dbat[0].batu = 0x80000000 | 0x1;
    dbat[0].batl = 0x00000000;

    ibat[0] = dbat[0];
}

bool PPCBATUnit::Translate(uint32_t ea,
                           uint32_t& pa,
                           bool isInstruction) const
{
    const PPCBAT* bat = isInstruction ? ibat : dbat;

    for (int i = 0; i < 4; i++) {
        if (!(bat[i].batu & 0x1))
            continue;

        uint32_t baseEA = bat[i].batu & 0xFFFE0000;
        uint32_t size   = BATBlockSize(bat[i].batu);
        uint32_t basePA = bat[i].batl & 0xFFFE0000;

        if (ea >= baseEA && ea < baseEA + size) {
            pa = basePA + (ea - baseEA);
            return true;
        }
    }

    return false;
}




#include "ppc_bat.h"

namespace MMU {

BAT IBAT[4];
BAT DBAT[4];

uint32_t TranslateBAT(uint32_t addr, bool dataAccess) {

    BAT* table = dataAccess ? DBAT : IBAT;

    for (int i = 0; i < 4; i++) {

        if (!table[i].valid) continue;

        uint32_t base = table[i].bepi;
        uint32_t size = table[i].size;

        if (addr >= base && addr < base + size) {

            uint32_t offset = addr - base;
            return table[i].brpn + offset;
        }
    }

    return 0xFFFFFFFF; // falhou
}

}