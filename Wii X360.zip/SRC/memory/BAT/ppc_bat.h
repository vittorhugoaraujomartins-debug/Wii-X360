#pragma once
#include <stdint.h>

struct PPCBAT {
    uint32_t batu;
    uint32_t batl;
};

class PPCBATUnit {
public:
    void Reset();
    void SetupWiiDefaults();

    bool Translate(uint32_t ea, uint32_t& pa, bool isInstruction) const;

private:
    PPCBAT ibat[4];
    PPCBAT dbat[4];
};



struct BAT {
    uint32_t bepi;  // virtual base
    uint32_t brpn;  // physical base
    uint32_t size;  // tamanho
    bool valid;
};

extern BAT IBAT[4];
extern BAT DBAT[4];

uint32_t TranslateBAT(uint32_t addr, bool dataAccess);

}