#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace WiiX360 {

struct RamBlock {
    uint8_t* base;
    uint32_t size;
};

class RamManager {
public:
    static bool Init();
    static void Shutdown();

    static uint8_t* Base();

private:
    static uint8_t* ramBase;
};

}