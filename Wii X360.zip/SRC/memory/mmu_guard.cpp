#include "mmu.h"
uint8_t MMU::ReadSafe(uint32_t a) {
    return memory[a & (MEM_SIZE-1)];
}
