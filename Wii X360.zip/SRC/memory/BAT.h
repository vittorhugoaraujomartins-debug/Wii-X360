#pragma once
#include <cstdint>

struct BATEntry {
    uint32_t bepi;   // Effective page index
    uint32_t brpn;   // Real page number
    uint32_t size;   // Block size
    bool valid;
    bool writable;
    bool executable;
};

class BAT {
public:
    void Reset();
    void WriteIBAT(int index, uint32_t upper, uint32_t lower);
    void WriteDBAT(int index, uint32_t upper, uint32_t lower);

    bool Translate(uint32_t ea, uint32_t& pa, bool isWrite, bool isExec) const;

private:
    BATEntry ibat[4];
    BATEntry dbat[4];
};