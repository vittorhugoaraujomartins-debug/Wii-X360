#include "MMU.h"
#include "memory_map.h"
#include "ppc_jit.h"
#include <cstring>

namespace MMU {

// ===============================
// Tradução de endereço (Wii real)
// ===============================
uint8_t* Translate(uint32_t addr, MMUAccess) {
    // Espelhamento clássico do Wii
    // 0x80000000 - 0x817FFFFF → MEM1
    // 0x90000000 - 0x93FFFFFF → MEM2

    addr &= 0x1FFFFFFF;
    return WiiMem::Translate(addr | 0x80000000);
}

// ===============================
// Read
// ===============================

uint8_t Read8(uint32_t addr) {
    uint8_t* p = Translate(addr, MMUAccess::Read);
    return p ? *p : 0;
}

uint16_t Read16(uint32_t addr) {
    uint8_t* p = Translate(addr, MMUAccess::Read);
    if (!p) return 0;

    uint16_t v;
    memcpy(&v, p, 2);
    return __builtin_bswap16(v);
}

uint32_t Read32(uint32_t addr) {
    uint8_t* p = Translate(addr, MMUAccess::Read);
    if (!p) return 0;

    uint32_t v;
    memcpy(&v, p, 4);
    return __builtin_bswap32(v);
}

// ===============================
// Write
// ===============================

void Write8(uint32_t addr, uint8_t v) {
    uint8_t* p = Translate(addr, MMUAccess::Write);
    if (p) *p = v;
}

void Write16(uint32_t addr, uint16_t v) {
    uint8_t* p = Translate(addr, MMUAccess::Write);
    if (!p) return;

    v = __builtin_bswap16(v);
    memcpy(p, &v, 2);
}

void Write32(uint32_t addr, uint32_t v) {
    uint8_t* p = Translate(addr, MMUAccess::Write);
    if (!p) return;

    v = __builtin_bswap32(v);
    memcpy(p, &v, 4);

    // 🔥 Self-modifying code
    PPCJIT::InvalidateRange(addr, 4);
}

// ===============================
// JIT
// ===============================

void InvalidateRange(uint32_t addr, uint32_t size) {
    PPCJIT::InvalidateRange(addr, size);
}

}

void MMU::Write32(uint32_t addr, uint32_t v) {
    uint32_t* p = (uint32_t*)Translate(addr);
    if (!p) return;

    *p = __builtin_bswap32(v);

    InstrOrder::MemoryBarrier();
    PPCJIT::InvalidateRange(addr, 4);
}


#include "MMU.h"

void MMU::Reset() {
    bat.Reset();
}

bool MMU::Translate(uint32_t ea, uint32_t& pa,
                    bool isWrite, bool isExec,
                    MMUFault& fault) {
    // MMU desativada (MSR[DR/IR] desligados)
    if (!isWrite && !isExec) {
        pa = ea;
        fault = MMUFault::None;
        return true;
    }

    if (bat.Translate(ea, pa, isWrite, isExec)) {
        fault = MMUFault::None;
        return true;
    }

    fault = isExec ? MMUFault::ISI : MMUFault::DSI;
    return false;
}

// Espelhamento do Wii
if ((pa & 0xF0000000) == 0x80000000 ||
    (pa & 0xF0000000) == 0x90000000 ||
    (pa & 0xF0000000) == 0xC0000000) {
    pa &= 0x1FFFFFFF;
}