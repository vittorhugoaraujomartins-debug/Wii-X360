#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


void MMU::Reset() {
    bat.Reset();
}

bool MMU::Translate(uint32_t ea, uint32_t& pa,
                    bool isWrite, bool isExec,
                    MMUFault& fault) {

    if (bat.Translate(ea, pa, isWrite, isExec)) {
        fault = MMUFault::None;
        return true;
    }

    // Espelhamento Wii clássico
    if ((ea & 0xF0000000) == 0x80000000 ||
        (ea & 0xF0000000) == 0x90000000) {
        pa = ea & 0x1FFFFFFF;
        fault = MMUFault::None;
        return true;
    }

    fault = isExec ? MMUFault::ISI : MMUFault::DSI;
    return false;
}