#pragma once
#include <cstdint>

namespace MemoryAccess {

uint8_t  Read8(uint32_t ea);
uint16_t Read16(uint32_t ea);
uint32_t Read32(uint32_t ea);

void Write8(uint32_t ea, uint8_t v);
void Write16(uint32_t ea, uint16_t v);
void Write32(uint32_t ea, uint32_t v);

}