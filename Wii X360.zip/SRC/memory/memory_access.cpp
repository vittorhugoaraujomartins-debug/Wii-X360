#include <xtl.h>
#include "memory_access.h"
#include "mmu.h"
#include "memory_map.h"
#include "ppc_jit.h"
#include <cstring>

extern MMU g_mmu;
extern PPCJIT g_jit;

static inline uint16_t SW16(uint16_t v) { return (v >> 8) | (v << 8); }
static inline uint32_t SW32(uint32_t v) { return __builtin_bswap32(v); }

uint32_t TranslateEA(uint32_t ea, bool write, bool exec) {
    uint32_t pa;
    MMUFault f;
    if (!g_mmu.Translate(ea, pa, write, exec, f))
        return 0xFFFFFFFF;
    return pa;
}

uint32_t MemRead32(uint32_t ea) {
    uint32_t pa = TranslateEA(ea, false, false);
    uint8_t* p = MemoryMap::Translate(pa);
    if (!p) return 0;

    uint32_t v;
    memcpy(&v, p, 4);
    return SW32(v);
}

void MemWrite32(uint32_t ea, uint32_t v) {
    uint32_t pa = TranslateEA(ea, true, false);
    uint8_t* p = MemoryMap::Translate(pa);
    if (!p) return;

    v = SW32(v);
    memcpy(p, &v, 4);

    // 🔥 self-modifying code
    g_jit.Invalidate(pa, 4);
}