#include "mmu_translate.h"
#include "ppc_bat.h"
#include "ppc_tlb.h"
#include "mmu_memory.h"

namespace MMU {

// ================================
// HARDWARE STUB REGISTERS
// ================================

static uint8_t HW_REGS[0x01000000];   // Hollywood
static uint8_t EXI_REGS[0x01000000];
static uint8_t DSP_REGS[0x00010000];
static uint8_t IPC_REGS[0x00010000];

// ================================
// Tradução principal
// ================================

uint32_t Translate(uint32_t vaddr, bool dataAccess)
{
    // 1️⃣ BAT
    uint32_t p = TranslateBAT(vaddr, dataAccess);
    if (p != 0xFFFFFFFF)
        return p;

    // 2️⃣ TLB
    p = TranslateTLB(vaddr);
    if (p != 0xFFFFFFFF)
        return p;

    // 3️⃣ Espelhos Wii clássicos
    if ((vaddr & 0xF0000000) == 0x80000000)
        return vaddr & 0x1FFFFFFF;

    if ((vaddr & 0xF0000000) == 0x90000000)
        return vaddr & 0x1FFFFFFF;

    // 4️⃣ Identidade fallback
    return vaddr;
}

// =====================================
// READ
// =====================================

uint8_t Read8(uint32_t addr)
{
    uint32_t p = Translate(addr, true);

    // MEM1
    if (p < 0x01800000)
        return MEM1[p];

    // MEM2
    if (p >= 0x10000000 && p < 0x14000000)
        return MEM2[p - 0x10000000];

    // Hollywood
    if (p >= 0x0C000000 && p < 0x0D000000)
        return HW_REGS[p - 0x0C000000];

    // EXI
    if (p >= 0x0D000000 && p < 0x0D800000)
        return EXI_REGS[p - 0x0D000000];

    // IPC
    if (p >= 0x0D400000 && p < 0x0D410000)
        return IPC_REGS[p - 0x0D400000];

    // DSP
    if (p >= 0x0D800000 && p < 0x0D810000)
        return DSP_REGS[p - 0x0D800000];

    return 0;
}

uint32_t Read32(uint32_t addr)
{
    uint32_t p = Translate(addr, true);

    // MEM1
    if (p < 0x01800000)
        return *(uint32_t*)&MEM1[p];

    // MEM2
    if (p >= 0x10000000 && p < 0x14000000)
        return *(uint32_t*)&MEM2[p - 0x10000000];

    // Hardware
    if (p >= 0x0C000000 && p < 0x0D000000)
        return *(uint32_t*)&HW_REGS[p - 0x0C000000];

    return 0;
}

// =====================================
// WRITE
// =====================================

void Write8(uint32_t addr, uint8_t val)
{
    uint32_t p = Translate(addr, true);

    if (p < 0x01800000)
        MEM1[p] = val;

    else if (p >= 0x10000000 && p < 0x14000000)
        MEM2[p - 0x10000000] = val;

    else if (p >= 0x0C000000 && p < 0x0D000000)
        HW_REGS[p - 0x0C000000] = val;

    else if (p >= 0x0D000000 && p < 0x0D800000)
        EXI_REGS[p - 0x0D000000] = val;

    else if (p >= 0x0D400000 && p < 0x0D410000)
        IPC_REGS[p - 0x0D400000] = val;

    else if (p >= 0x0D800000 && p < 0x0D810000)
        DSP_REGS[p - 0x0D800000] = val;
}

void Write32(uint32_t addr, uint32_t val)
{
    uint32_t p = Translate(addr, true);

    if (p < 0x01800000)
        *(uint32_t*)&MEM1[p] = val;

    else if (p >= 0x10000000 && p < 0x14000000)
        *(uint32_t*)&MEM2[p - 0x10000000] = val;

    else if (p >= 0x0C000000 && p < 0x0D000000)
        *(uint32_t*)&HW_REGS[p - 0x0C000000] = val;
}

}


bool MMU::Translate(PPCState* cpu,
                    uint32_t ea,
                    uint32_t& phys,
                    bool isWrite,
                    bool isExec)
{
    // =========================
    // 1️⃣ MSR Relocation Check
    // =========================

    if (isExec && !(cpu->msr & (1 << 5))) // IR bit
    {
        phys = ToPhysical(ea);
        return true;
    }

    if (!isExec && !(cpu->msr & (1 << 4))) // DR bit
    {
        phys = ToPhysical(ea);
        return true;
    }

    // =========================
    // 2️⃣ BAT (simplificado HLE)
    // =========================
    for (auto& bat : cpu->dbat)
    {
        if (!bat.valid) continue;

        if ((ea & bat.mask) == bat.eaBase)
        {
            phys = bat.paBase | (ea & ~bat.mask);
            return true;
        }
    }

    // =========================
    // 3️⃣ TLB
    // =========================
    for (auto& tlb : cpu->tlb)
    {
        if (!tlb.valid) continue;

        if (ea >= tlb.ea && ea < tlb.ea + tlb.size)
        {
            if (isWrite && !tlb.write)
                return false;

            phys = tlb.pa + (ea - tlb.ea);
            return true;
        }
    }

    // =========================
    // 4️⃣ Fallback identity
    // =========================

    phys = ToPhysical(ea);
    return true;
}


