#pragma once
#include <cstdint>

namespace MemoryMap {

enum class Region {
    MEM1,
    MEM2,
    ROM,
    INVALID
};

void Init(uint8_t* base);
uint8_t* Translate(uint32_t pa);
Region Resolve(uint32_t pa);

}