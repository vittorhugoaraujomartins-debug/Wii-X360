#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace MemoryMap {

enum class Region {
    MEM1,
    MEM2,
    ROM,
    INVALID
};

void Init(uint8_t* base);
uint8_t* Translate(uint32_t pa);
Region Resolve(uint32_t pa);

}

#pragma once

namespace Memory {

bool Init();
void Shutdown();

uint8_t  Read8(uint32_t addr);
uint16_t Read16(uint32_t addr);
uint32_t Read32(uint32_t addr);

void Write8(uint32_t addr, uint8_t v);
void Write16(uint32_t addr, uint16_t v);
void Write32(uint32_t addr, uint32_t v);

}