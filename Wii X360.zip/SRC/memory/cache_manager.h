#pragma once
#include <cstdint>

class CacheManager
{
public:
    void InvalidateRange(uint32_t address, uint32_t size);
    void FlushRange(uint32_t address, uint32_t size);

private:
    void InvalidateLine(uint32_t address);
};