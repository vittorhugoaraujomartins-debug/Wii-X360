
#include "mmu.h"
bool MMU::CheckPerm(uint32_t addr,bool write,bool exec){
    /*auto*/ &e = BAT[addr>>17];
    if(write && !e.w) return false;
    if(exec && !e.x) return false;
    return true;
}
