#pragma once
#include <cstdint>

uint8_t  MemRead8(uint32_t ea);
uint16_t MemRead16(uint32_t ea);
uint32_t MemRead32(uint32_t ea);

void MemWrite8(uint32_t ea, uint8_t v);
void MemWrite16(uint32_t ea, uint16_t v);
void MemWrite32(uint32_t ea, uint32_t v);