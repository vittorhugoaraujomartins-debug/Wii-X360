#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

#pragma once
#include <cstdint>
// FIXME: include not found in project (left original below):
#include "BAT.h"

enum class MMUFault {
    None,
    ISI,
    DSI
};

class MMU {
public:
    void Reset();

    bool Translate(uint32_t ea, uint32_t& pa,
                   bool isWrite, bool isExec,
                   MMUFault& fault);

    BAT& GetBAT() { return bat; }

private:
    BAT bat;
};