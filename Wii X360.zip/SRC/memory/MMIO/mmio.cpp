#include "mmio.h"
#include "vi.h"
#include "gx_fifo.h"

namespace MMIO {

// VI registers
static uint32_t VI_STATUS = 0;
static uint32_t VI_FB_ADDR = 0;

// GX FIFO registers
static uint32_t GX_FIFO_BASE = 0;

void Init()
{
    VI_STATUS = 0;
    VI_FB_ADDR = 0;
    GX_FIFO_BASE = 0;
}

uint32_t Read32(uint32_t addr)
{
    // VI
    if (addr >= 0x0C000000 && addr < 0x0C000100)
    {
        switch (addr & 0xFF)
        {
            case 0x00: return VI_STATUS;
            case 0x04: return VI_FB_ADDR;
        }
    }

    return 0;
}

void Write32(uint32_t addr, uint32_t value)
{
    // =========================
    // VIDEO INTERFACE
    // =========================
    if (addr >= 0x0C000000 && addr < 0x0C000100)
    {
        switch (addr & 0xFF)
        {
            case 0x00:
                VI_STATUS = value;
                break;

            case 0x04:
                VI_FB_ADDR = value;
                break;
        }
        return;
    }

    // =========================
    // GX FIFO BASE
    // =========================
    if (addr == 0x0C008000)
    {
        GX_FIFO_BASE = value;
        GXFIFO::SetBase(value);
        return;
    }
}

}