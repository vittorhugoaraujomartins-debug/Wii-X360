#pragma once
#include <stdint.h>

namespace MMIO {

uint32_t Read32(uint32_t addr);
void Write32(uint32_t addr, uint32_t value);

void Init();

}