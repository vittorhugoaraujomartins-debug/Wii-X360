
#pragma once

class Emulator {
public:
    bool Init();
    void Step();
    void Shutdown();
    bool Running() const;

private:
    bool running;
};

#include "memory/MemoryManager.h"
MemoryManager memory;
