#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>



#pragma once

namespace Audio {

    // Taxa padrão do Wii
    static const uint32_t DSP_SAMPLE_RATE = 32000;

    class DSP {
    public:
        DSP();
        ~DSP();

        // Inicializa buffers e estado interno
        bool Initialize(uint32_t sampleRate = DSP_SAMPLE_RATE);

        // Reset completo do DSP
        void Reset();

        // Envia amostras PCM vindas da CPU emulada
        void PushSamples(const int16_t* samples, uint32_t count);

        // Processa áudio (mixagem, volume, filtros simples)
        void Process();

        // Copia áudio pronto para o backend do Xbox (XAudio2 / DirectSound)
        uint32_t PopSamples(int16_t* outBuffer, uint32_t maxSamples);

        // Controle básico
        void SetVolume(float volume);
        void SetMuted(bool muted);

    private:
        std::vector<int16_t> m_inputBuffer;
        std::vector<int16_t> m_outputBuffer;

        uint32_t m_sampleRate;
        float m_volume;
        bool m_muted;

        // Ponteiros de leitura/escrita
        uint32_t m_readPos;
        uint32_t m_writePos;

        void MixSamples();
    };

} // namespace Audio