#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>



namespace Audio {

    DSP::DSP()
        : m_sampleRate(DSP_SAMPLE_RATE),
          m_volume(1.0f),
          m_muted(false),
          m_readPos(0),
          m_writePos(0) {}

    DSP::~DSP() {}

    bool DSP::Initialize(uint32_t sampleRate) {
        m_sampleRate = sampleRate;

        // Buffers relativamente grandes para evitar underflow
        m_inputBuffer.resize(65536);
        m_outputBuffer.resize(65536);

        Reset();
        return true;
    }

    void DSP::Reset() {
        std::fill(m_inputBuffer.begin(), m_inputBuffer.end(), 0);
        std::fill(m_outputBuffer.begin(), m_outputBuffer.end(), 0);
        m_readPos = 0;
        m_writePos = 0;
    }

    void DSP::SetVolume(float volume) {
        m_volume = std::max(0.0f, std::min(volume, 2.0f));
    }

    void DSP::SetMuted(bool muted) {
        m_muted = muted;
    }

    void DSP::PushSamples(const int16_t* samples, uint32_t count) {
        if (!samples || count == 0)
            return;

        for (uint32_t i = 0; i < count; i++) {
            m_inputBuffer[m_writePos] = samples[i];
            m_writePos = (m_writePos + 1) % m_inputBuffer.size();
        }
    }

    void DSP::MixSamples() {
        // Processa tudo que tem no buffer de entrada
        while (m_readPos != m_writePos) {
            int16_t sample = m_inputBuffer[m_readPos];
            m_readPos = (m_readPos + 1) % m_inputBuffer.size();

            if (m_muted) {
                sample = 0;
            } else {
                float s = static_cast<float>(sample) * m_volume;
                s = std::max(-32768.0f, std::min(s, 32767.0f));
                sample = static_cast<int16_t>(s);
            }

            m_outputBuffer.push_back(sample);
            if (m_outputBuffer.size() >= 65536) {
                m_outputBuffer.erase(m_outputBuffer.begin(),
                                     m_outputBuffer.begin() + 1024);
            }
        }
    }

    void DSP::Process() {
        MixSamples();
    }

    uint32_t DSP::PopSamples(int16_t* outBuffer, uint32_t maxSamples) {
        if (!outBuffer || maxSamples == 0)
            return 0;

        uint32_t available = static_cast<uint32_t>(m_outputBuffer.size());
        uint32_t toCopy = std::min(available, maxSamples);

        memcpy(outBuffer, m_outputBuffer.data(),
               toCopy * sizeof(int16_t));

        m_outputBuffer.erase(m_outputBuffer.begin(),
                             m_outputBuffer.begin() + toCopy);

        return toCopy;
    }

} // namespace Audio