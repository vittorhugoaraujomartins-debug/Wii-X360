
#include "FS.h"
#include <filesystem>
namespace fs = std::filesystem;

static std::string g_root;

bool FS::Init(const std::string& rootPath) {
    g_root = rootPath;
    return fs::exists(rootPath);
}

bool FS::Exists(const std::string& path) {
    return fs::exists(g_root + path);
}
