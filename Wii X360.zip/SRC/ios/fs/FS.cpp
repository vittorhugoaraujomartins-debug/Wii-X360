#include "FS.h"
bool FS::Init(){return true;}

// --- Build/XEX compatibility stub ---

// HLE default success
