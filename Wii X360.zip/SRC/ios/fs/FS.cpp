#include "FS.h"
bool FS::Init(){return true;}