#pragma once
#include <stdint.h>
#include <map>
#include <string>

class FSCore {
public:
    void Init(const char* rootPath);

    int Ioctl(int cmd, void* in, void* out);

private:
    std::string root;

    struct Handle {
        FILE* file;
    };

    std::map<int, Handle> handles;
    int nextHandle = 1;

    int Open(const char* path, int mode);
    int Read(int fd, void* buffer, uint32_t size);
    int Close(int fd);
};

extern FSCore g_FS;