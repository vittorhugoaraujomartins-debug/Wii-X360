#include "es.h"
#include <string.h>

bool Permissions_CheckNANDAccess(const char* path)
{
    // Permite acesso ao próprio save
    if (strstr(path, "title"))
        return true;

    // Permite shared content
    if (strstr(path, "shared"))
        return true;

    return false;
}