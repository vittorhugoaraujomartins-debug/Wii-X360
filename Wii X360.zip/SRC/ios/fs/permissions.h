#pragma once

bool Permissions_CheckNANDAccess(const char* path);