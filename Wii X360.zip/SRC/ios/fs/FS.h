#pragma once
#include <stdint.h>
#include <string>
#include <map>
#include <stdio.h>

struct FSHandle
{
    FILE* file;
    uint32_t offset;
};

class FSDevice
{
public:
    void Init(const std::string& root);

    int Open(const char* path);
    int Read(int fd, void* buffer, uint32_t size);
    int Seek(int fd, uint32_t offset);
    int Close(int fd);

    int Ioctl(int cmd, void* in, void* out);
    int Ioctlv(int cmd, struct IPCVector* vec, int count);

private:
    std::string m_root;

    std::map<int, FSHandle> m_handles;
    int m_nextFd = 1;

    std::string BuildPath(const char* wiiPath);
};

extern FSDevice g_FSDevice;