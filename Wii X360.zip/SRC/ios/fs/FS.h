#pragma once
class FS{public: static bool Init();};