
#pragma once
#include <string>
class FS {
public:
    static bool Init(const std::string& rootPath);
    static bool Exists(const std::string& path);
};
