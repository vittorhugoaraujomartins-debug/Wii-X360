#include "fs_core.h"
#include <stdio.h>
#include <string.h>

FSCore g_FS;

void FSCore::Init(const char* rootPath) {
    root = rootPath;
}

int FSCore::Ioctl(int cmd, void* in, void* out) {

    switch (cmd) {

    case 0x01: // Open
        return Open((const char*)in, 0);

    case 0x02: { // Read
        int* p = (int*)in;
        int fd = p[0];
        uint32_t size = p[1];
        return Read(fd, out, size);
    }

    case 0x03: // Close
        return Close(*(int*)in);

    default:
        return -1;
    }
}




int FSCore::Open(const char* path, int mode) {

    char full[512];
    snprintf(full, sizeof(full), "%s/%s", root.c_str(), path);

    FILE* f = fopen(full, "rb");
    if (!f) return -1;

    int fd = nextHandle++;
    handles[fd] = { f };

    return fd;
}

int FSCore::Read(int fd, void* buffer, uint32_t size) {

    auto it = handles.find(fd);
    if (it == handles.end()) return -1;

    return fread(buffer, 1, size, it->second.file);
}

int FSCore::Close(int fd) {

    auto it = handles.find(fd);
    if (it == handles.end()) return -1;

    fclose(it->second.file);
    handles.erase(it);

    return 0;
}