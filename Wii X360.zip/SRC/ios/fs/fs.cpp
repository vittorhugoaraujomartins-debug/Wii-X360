int FS_Open(const char* path)
{
    return NAND_Open(path);
}

int FS_Read(int fd, void* buffer, int size)
{
    return NAND_Read(fd, buffer, size);
}

int FS_Close(int fd)
{
    return NAND_Close(fd);
}


int FS_Ioctl(int cmd, void* in, void* out)
{
    switch(cmd)
    {
        case 0x10: // Open
            return FS_Open((const char*)in);

        case 0x11: // Read
        {
            int* p = (int*)in;
            return FS_Read(p[0], out, p[1]);
        }

        case 0x12: // Close
            return FS_Close(*(int*)in);
    }

    return -1;
}


int FS_OpenSave(const char* filename)
{
    char path[256];
    char base[200];

    NAND_GetSavePath(base);

    sprintf(path, "%s%s", base, filename);

    return NAND_Open(path);
}


int FS_Open(const char* path)
{
    return Host_OpenFile(path);
}


int FS_Open(const char* path)
{
    char realPath[256];

    sprintf(realPath, "WiiNAND/%s", path);

    return Host_OpenFile(realPath);
}



#include "FS.h"
#include <filesystem>

namespace fs = std::filesystem;

FileSystem::FileSystem(const std::string& root)
    : m_root(root)
{
}

std::string FileSystem::BuildPath(const std::string& wii_path)
{
    if (wii_path.empty())
        return m_root;

    if (wii_path[0] == '/')
        return m_root + wii_path;

    return m_root + "/" + wii_path;
}



FSResult FileSystem::Open(const std::string& path, Fd& out_fd)
{
    std::string host_path = BuildPath(path);

    Handle h;
    h.file.open(host_path, std::ios::binary);

    if (!h.file.is_open())
        return FSResult::NotFound;

    Fd fd = m_next_fd++;
    h.open = true;

    m_handles[fd] = std::move(h);
    out_fd = fd;

    return FSResult::OK;
}




FSResult FileSystem::Read(Fd fd, void* buffer, uint32_t size, uint32_t& read_bytes)
{
    auto it = m_handles.find(fd);
    if (it == m_handles.end())
        return FSResult::Invalid;

    Handle& h = it->second;

    h.file.read(reinterpret_cast<char*>(buffer), size);
    read_bytes = (uint32_t)h.file.gcount();

    if (read_bytes == 0)
        return FSResult::EndOfFile;

    return FSResult::OK;
}





FSResult FileSystem::Seek(Fd fd, uint32_t offset)
{
    auto it = m_handles.find(fd);
    if (it == m_handles.end())
        return FSResult::Invalid;

    it->second.file.seekg(offset, std::ios::beg);

    return FSResult::OK;
}FSResult FileSystem::Close(Fd fd)
{
    auto it = m_handles.find(fd);
    if (it == m_handles.end())
        return FSResult::Invalid;

    it->second.file.close();
    m_handles.erase(it);

    return FSResult::OK;
}





FSResult FileSystem::ReadDirectory(
    const std::string& path,
    std::vector<std::string>& out)
{
    std::string host_path = BuildPath(path);

    if (!fs::exists(host_path))
        return FSResult::NotFound;

    for (auto& entry : fs::directory_iterator(host_path))
    {
        out.push_back(entry.path().filename().string());
    }

    return FSResult::OK;
}





#include "FS.h"
#include "es.h"
#include "ipc_core.h"
#include <stdio.h>

FSDevice g_FSDevice;

void FSDevice::Init(const std::string& root)
{
    m_root = root;
}




std::string FSDevice::BuildPath(const char* wiiPath)
{
    if (!wiiPath || wiiPath[0] == 0)
        return m_root;

    std::string path = m_root;

    if (wiiPath[0] != '/')
        path += "/";

    path += wiiPath;

    return path;
}


int FSDevice::Open(const char* path)
{
    std::string real = BuildPath(path);

    FILE* f = fopen(real.c_str(), "rb");

    if (!f)
        return -1;

    int fd = m_nextFd++;

    m_handles[fd] = { f, 0 };

    return fd;
}


int FSDevice::Read(int fd, void* buffer, uint32_t size)
{
    auto it = m_handles.find(fd);
    if (it == m_handles.end())
        return -1;

    FSHandle& h = it->second;

    int read = fread(buffer, 1, size, h.file);
    h.offset += read;

    return read;
}




int FSDevice::Seek(int fd, uint32_t offset)
{
    auto it = m_handles.find(fd);
    if (it == m_handles.end())
        return -1;

    FSHandle& h = it->second;

    fseek(h.file, offset, SEEK_SET);
    h.offset = offset;

    return 0;
}


int FSDevice::Close(int fd)
{
    auto it = m_handles.find(fd);
    if (it == m_handles.end())
        return -1;

    fclose(it->second.file);
    m_handles.erase(it);

    return 0;
}



int FSDevice::Ioctl(int cmd, void* in, void* out)
{
    switch (cmd)
    {
    case 1: // Open
        return Open((const char*)in);

    case 2: // Read
    {
        int* p = (int*)in;
        return Read(p[0], out, p[1]);
    }

    case 3: // Close
        return Close(*(int*)in);

    case 4: // Seek
    {
        int* p = (int*)in;
        return Seek(p[0], p[1]);
    }

    default:
        return -1;
    }
}



int FSDevice::Ioctlv(int cmd, IPCVector* vec, int count)
{
    if (cmd == 2 && count >= 2) // Readv
    {
        int fd = *(int*)vec[0].data;
        void* buffer = vec[1].data;
        uint32_t size = vec[1].size;

        return Read(fd, buffer, size);
    }

    return -1;
}



