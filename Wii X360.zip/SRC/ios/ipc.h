#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

enum IPCCommand {
    IPC_OPEN  = 1,
    IPC_CLOSE = 2,
    IPC_READ  = 3,
    IPC_WRITE = 4,
    IPC_IOCTL = 6
};

struct IPCMessage {
    uint32_t cmd;
    uint32_t fd;
    uint32_t arg0;
    uint32_t arg1;
    uint32_t arg2;
    int32_t  result;
};

namespace IPC {
    void Init();
    void Send(const IPCMessage& msg);
    bool HasMessage();
    IPCMessage Pop();
}