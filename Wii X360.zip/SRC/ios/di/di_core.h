#pragma once
#include <stdint.h>
#include <stdio.h>
#include <cstdint>
#include <string>
#include <fstream>


class DICore {
public:
    void Init(const char* isoPath);

    int Ioctl(int cmd, void* in, void* out);

private:
    FILE* iso = nullptr;

    int Read(uint32_t offset, void* buffer, uint32_t size);
};

extern DICore g_DI;







class DIDevice
{
public:

    DIDevice();

    bool MountISO(const std::string& path);

    bool Read(void* out_buffer, uint32_t offset, uint32_t size);

    bool GetDiskID(void* out_buffer);

    bool IsDiscInserted() const;

    void OpenPartition(uint32_t offset);
    void ClosePartition();

private:

    std::ifstream m_iso;

    bool m_disc_inserted = false;
    uint32_t m_partition_offset = 0;
};