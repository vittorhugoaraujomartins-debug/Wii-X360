#include "DIDevice.h"

DIDevice g_DI;

bool DIDevice::Mount(const char* isoPath)
{
    return image.Open(isoPath);
}

int DIDevice::Read(void* buffer, uint32_t size, uint64_t offset)
{
    return image.Read(offset, buffer, size);
}

uint32_t DIDevice::GetDolOffset()
{
    return image.GetDolOffset();
}

uint32_t DIDevice::GetApploaderOffset()
{
    return image.GetApploaderOffset();
}



#include "DIDevice.h"
#include "WBFSImage.h"

static WBFSImage g_wbfs;

bool DIDevice::Mount(const char* path)
{
    const char* ext = strrchr(path, '.');

    if (ext && strcmp(ext, ".wbfs") == 0)
        return g_wbfs.Open(path);

    return image.Open(path); // ISO normal
}

int DIDevice::Read(void* buffer, uint32_t size, uint64_t offset)
{
    if (g_wbfs.Read(offset, buffer, size) > 0)
        return size;

    return image.Read(offset, buffer, size);
}

uint32_t DIDevice::GetDolOffset()
{
    return g_wbfs.GetDolOffset();
}

uint32_t DIDevice::GetApploaderOffset()
{
    return g_wbfs.GetApploaderOffset();
}


#include "DIDEVICE.h"
#include <fstream>
#include <cstring>

bool DIDevice::Init(const std::string& isoPath)
{
    return LoadISO(isoPath);
}

bool DIDevice::LoadISO(const std::string& path)
{
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;

    m_disc.assign(
        std::istreambuf_iterator<char>(f),
        std::istreambuf_iterator<char>());

    m_inserted = true;
    return true;
}


int DIDevice::ReadDiscID(void* out)
{
    if (!m_inserted) return -1;

    memcpy(out, m_disc.data(), 0x20);
    return 0;
}

int DIDevice::OpenPartition(void* in)
{
    uint64_t offset = *(uint64_t*)in;

    m_partitionOffset = offset;

    return 0;
}



int DIDevice::Read(void* in, void* out)
{
    struct
    {
        uint32_t offset;
        uint32_t size;
    }* params = (decltype(params))in;

    uint64_t realOffset = m_partitionOffset + params->offset;

    if (realOffset + params->size > m_disc.size())
        return -1;

    memcpy(out,
           &m_disc[realOffset],
           params->size);

    return params->size;
}



#define DI_READ_DISCID   0x70
#define DI_READ          0x71
#define DI_OPEN_PART     0x8B



int DIDevice::Ioctl(uint32_t cmd, void* in, void* out)
{
    switch (cmd)
    {
        case DI_READ_DISCID:
            return ReadDiscID(out);

        case DI_OPEN_PART:
            return OpenPartition(in);

        case DI_READ:
            return Read(in, out);
    }

    return -1;
}



