#pragma once
#include <stdint.h>

namespace DI {

bool Init(const char* isoPath);

uint32_t Ioctl(uint32_t cmd,
               uint32_t inBuf,
               uint32_t inSize,
               uint32_t outBuf,
               uint32_t outSize);

}