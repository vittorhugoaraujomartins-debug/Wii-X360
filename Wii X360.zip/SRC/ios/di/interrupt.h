#pragma once
#include <stdint.h>

namespace Interrupts {

void Init();

void RaiseIPC();
bool CheckIPC();

}