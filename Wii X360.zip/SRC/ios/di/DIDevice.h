#pragma once
#include "DIImage.h"

class DIDevice
{
public:
    bool Mount(const char* isoPath);

    int Read(void* buffer, uint32_t size, uint64_t offset);

    uint32_t GetDolOffset();
    uint32_t GetApploaderOffset();

private:
    DIImage image;
};

extern DIDevice g_DI;


#include <cstdint>
#include <string>
#include <vector>

class DIDevice
{
public:
    bool Init(const std::string& isoPath);

    int Ioctl(uint32_t cmd, void* in, void* out);
    int Ioctlv(uint32_t cmd, void* in, void* out);

private:
    std::vector<uint8_t> m_disc;
    bool m_inserted = false;

    uint64_t m_partitionOffset = 0;

    bool LoadISO(const std::string& path);

    int ReadDiscID(void* out);
    int Read(void* in, void* out);
    int OpenPartition(void* in);
};