static int seekSpeed;

void DI_Init(bool fast)
{
    seekSpeed = fast ? 1 : 2;
}

int DI_ReadSector(unsigned int sector, void* buffer)
{
    return Disc_Read(sector, buffer);
}


int DI_Ioctl(int cmd, void* in, void* out)
{
    switch(cmd)
    {
        case 0x20: // Read sector
            return DI_ReadSector(*(unsigned int*)in, out);
    }

    return -1;
}


static unsigned int currentSector;
static bool streaming;

void DI_StartStream(unsigned int sector)
{
    currentSector = sector;
    streaming = true;
}

void DI_Update()
{
    if (!streaming)
        return;

    char buffer[2048];

    Disc_Read(currentSector, buffer);

    currentSector++;
}



static unsigned char g_DiscCache[4 * 1024 * 1024]; // 4MB cache
static unsigned int g_LastSector = 0xFFFFFFFF;

int DI_ReadSector(unsigned int sector, void* buffer)
{
    if (sector != g_LastSector)
    {
        Disc_ReadBulk(sector, g_DiscCache, 4 * 1024 * 1024);
        g_LastSector = sector;
    }

    memcpy(buffer, g_DiscCache, 2048);
    return 0;
}


#include "di.h"
#include "mmu.h"
#include <stdio.h>

namespace DI {

static FILE* iso = nullptr;

bool Init(const char* path)
{
    iso = fopen(path, "rb");
    return iso != nullptr;
}

uint32_t Ioctl(uint32_t cmd,
               uint32_t inBuf,
               uint32_t inSize,
               uint32_t outBuf,
               uint32_t outSize)
{
    if (!iso) return -1;

    switch (cmd)
    {
        // READ
        case 0x71:
        {
            uint32_t offset = MMU_Read32(inBuf);
            uint32_t length = MMU_Read32(inBuf + 4);

            uint8_t* dst = MMU::GetPointer(outBuf);
            if (!dst) return -1;

            fseek(iso, offset, SEEK_SET);
            fread(dst, 1, length, iso);

            return 0;
        }

        // GET_STATUS
        case 0x70:
            return 0;

        default:
            return -1;
    }
}

}