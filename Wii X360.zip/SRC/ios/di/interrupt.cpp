#include "interrupts.h"

namespace Interrupts {

static bool ipcPending = false;

void Init()
{
    ipcPending = false;
}

void RaiseIPC()
{
    ipcPending = true;
}

bool CheckIPC()
{
    if (ipcPending)
    {
        ipcPending = false;
        return true;
    }
    return false;
}

}