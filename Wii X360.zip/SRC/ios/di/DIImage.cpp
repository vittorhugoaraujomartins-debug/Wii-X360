#include "DIImage.h"

bool DIImage::Open(const char* path)
{
    file = fopen(path, "rb");
    return file != nullptr;
}

int DIImage::Read(uint64_t offset, void* buffer, uint32_t size)
{
    if (!file) return -1;

    fseek(file, offset, SEEK_SET);
    return fread(buffer, 1, size, file);
}


// ⚠️ HLE: offsets aproximados usados por vários jogos
uint32_t DIImage::GetApploaderOffset()
{
    return 0x2440; 
}

uint32_t DIImage::GetDolOffset()
{
    uint32_t dolOffset;

    // offset 0x420 aponta para o DOL na partição
    fseek(file, 0x420, SEEK_SET);
    fread(&dolOffset, 4, 1, file);

    return dolOffset;
}