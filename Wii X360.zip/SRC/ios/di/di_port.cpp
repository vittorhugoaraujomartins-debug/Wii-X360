int DI_ReadFile(const char* path, void* buffer, int size)
{
    return Host_ReadFile(path, buffer, size);
}