#include "di_core.h"

DICore g_DI;

void DICore::Init(const char* isoPath) {
    iso = fopen(isoPath, "rb");
}


int DICore::Ioctl(int cmd, void* in, void* out) {

    switch (cmd) {

    case 0x01: { // Read sector
        uint32_t* p = (uint32_t*)in;
        uint32_t offset = p[0];
        uint32_t size = p[1];
        return Read(offset, out, size);
    }

    default:
        return -1;
    }
}


int DICore::Read(uint32_t offset, void* buffer, uint32_t size) {

    if (!iso) return -1;

    fseek(iso, offset, SEEK_SET);
    return fread(buffer, 1, size, iso);
}



#include "di.h"
#include <cstring>

DIDevice::DIDevice()
{
}




bool DIDevice::MountISO(const std::string& path)
{
    m_iso.open(path, std::ios::binary);

    if (!m_iso.is_open())
        return false;

    m_disc_inserted = true;
    m_partition_offset = 0;

    return true;
}


bool DIDevice::IsDiscInserted() const
{
    return m_disc_inserted;
}



bool DIDevice::Read(void* out_buffer, uint32_t offset, uint32_t size)
{
    if (!m_disc_inserted)
        return false;

    m_iso.seekg(m_partition_offset + offset, std::ios::beg);

    if (!m_iso.good())
        return false;

    m_iso.read(reinterpret_cast<char*>(out_buffer), size);

    return true;
}



void DIDevice::OpenPartition(uint32_t offset)
{
    m_partition_offset = offset;
}



void DIDevice::ClosePartition()
{
    m_partition_offset = 0;
}



bool DIDevice::GetDiskID(void* out_buffer)
{
    if (!m_disc_inserted)
        return false;

    m_iso.seekg(0, std::ios::beg);
    m_iso.read(reinterpret_cast<char*>(out_buffer), 0x20);

    return true;
}




