#pragma once
#include <stdint.h>
#include <stdio.h>

class DIImage
{
public:
    bool Open(const char* path);
    int  Read(uint64_t offset, void* buffer, uint32_t size);

    uint32_t GetDolOffset();
    uint32_t GetApploaderOffset();

private:
    FILE* file = nullptr;
};