#include "IOS_FS.h"
#include <cstring>

namespace IOSFS {

void Init() {}

int Open(const char*) {
    return 1; // fake FD
}

int Read(int, void* buffer, int size) {
    memset(buffer, 0, size);
    return size;
}

int Close(int) {
    return 0;
}

}


#include <cstring>

static int fakeFd = 1;

namespace IOSFS {

void Init() {
    fakeFd = 1;
}

int Open(const char*, int) {
    return fakeFd++;
}

int Read(int, void* buffer, uint32_t size) {
    memset(buffer, 0, size);
    return size;
}

int Close(int) {
    return 0;
}

int Stat(const char*, void* out) {
    if (!out)
        return -1;

    // Estrutura fake
    memset(out, 0, 64);
    return 0;
}

}