#include "ios_core.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):
// FIXME: include not found in project (left original below):
// FIXME: include not found in project (left original below):

namespace IOS {

void Init() {
    IOSDevice::RegisterDevices();
    FS::Init();
    ES::Init();
}

void Shutdown() {
    FS::Shutdown();
    ES::Shutdown();
}

void Update() {
    // Stub — futuramente scheduler / IRQ
}

// ================================
// IPC entrypoint
// ================================
int HandleIPC(uint32_t command, void* buffer) {

    switch (command) {

        case IOS_OPEN:
            return Open(reinterpret_cast<const char*>(buffer));

        case IOS_IOCTL:
            // buffer já vem estruturado pelo PPC
            return 0;

        default:
            // IOS permissivo = não quebra jogo
            return 0;
    }
}

// ================================
// Device routing
// ================================
int Open(const char* device) {

    if (FS::Handles(device))
        return FS::Open(device);

    if (ES::Handles(device))
        return ES::Open(device);

    IOSDevice* dev = IOSDevice::OpenDevice(device);
    if (dev)
        return reinterpret_cast<intptr_t>(dev);

    return -1;
}

int Close(int fd) {
    if (FS::Owns(fd)) FS::Close(fd);
    if (ES::Owns(fd)) ES::Close(fd);
    return 0;
}

int Ioctl(int fd, uint32_t cmd,
          void* in, uint32_t inSize,
          void* out, uint32_t outSize) {

    if (FS::Owns(fd))
        return FS::Ioctl(fd, cmd, in, inSize, out, outSize);

    if (ES::Owns(fd))
        return ES::Ioctl(fd, cmd, in, inSize, out, outSize);

    IOSDevice* dev = reinterpret_cast<IOSDevice*>(fd);
    if (dev)
        return dev->Ioctl(cmd, in, inSize, out, outSize);

    return 0;
}

int Read(int fd, void* buffer, uint32_t size) {
    if (FS::Owns(fd))
        return FS::Read(fd, buffer, size);

    return 0;
}

int Write(int, const void*, uint32_t size) {
    return size; // Wii ignora retorno real
}

}