// ios_fs.cpp
#include "ios.h"

namespace IOS {

// Nada é realmente lido — só finge que existe
// Jogos só querem resposta válida

}

// --- Build/XEX compatibility stub ---

// HLE default success
