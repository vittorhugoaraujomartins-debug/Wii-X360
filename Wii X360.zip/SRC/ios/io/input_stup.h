#pragma once
#include <stdint.h>

namespace Input {
    void Update();
    uint16_t ReadButtons();
}