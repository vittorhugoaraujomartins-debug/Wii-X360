// ios_dvd.cpp
#include "ios.h"

namespace IOS {

// DVD sempre pronto, sem leitura real

}