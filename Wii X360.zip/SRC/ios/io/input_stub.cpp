#include "input_stub.h"
#include <xtl.h>

static uint16_t g_buttons = 0;

namespace Input {

void Update() {
    g_buttons = 0;

    if (XInputGetState(0, nullptr) == ERROR_SUCCESS) {
        // exemplo: botão A
        g_buttons |= 0x0001;
    }
}

uint16_t ReadButtons() {
    return g_buttons;
}

}