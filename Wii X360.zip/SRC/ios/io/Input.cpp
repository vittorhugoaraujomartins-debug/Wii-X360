#include <xtl.h>

// FIXME: include not found in project (left original below):
#include "input.h"

namespace IO
{
    static WiiInputState g_state;

#ifdef _XBOX
    static XINPUT_STATE g_xinput;
#endif

    bool Init()
    {
        g_state.buttons = 0;
        g_state.analogX = 0.0f;
        g_state.analogY = 0.0f;

#ifdef _XBOX
        ZeroMemory(&g_xinput, sizeof(XINPUT_STATE));
#endif
        return true;
    }

    static void MapXboxToWii(const XINPUT_GAMEPAD& pad)
    {
        g_state.buttons = 0;

        // Botões principais
        if (pad.wButtons & XINPUT_GAMEPAD_A) g_state.buttons |= WII_A;
        if (pad.wButtons & XINPUT_GAMEPAD_B) g_state.buttons |= WII_B;
        if (pad.wButtons & XINPUT_GAMEPAD_START) g_state.buttons |= WII_PLUS;
        if (pad.wButtons & XINPUT_GAMEPAD_BACK) g_state.buttons |= WII_MINUS;
        if (pad.wButtons & XINPUT_GAMEPAD_Y) g_state.buttons |= WII_HOME;

        // Direcional
        if (pad.wButtons & XINPUT_GAMEPAD_DPAD_UP)    g_state.buttons |= WII_UP;
        if (pad.wButtons & XINPUT_GAMEPAD_DPAD_DOWN)  g_state.buttons |= WII_DOWN;
        if (pad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT)  g_state.buttons |= WII_LEFT;
        if (pad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT) g_state.buttons |= WII_RIGHT;

        // Mapeamento 1 e 2
        if (pad.wButtons & XINPUT_GAMEPAD_X) g_state.buttons |= WII_1;
        if (pad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) g_state.buttons |= WII_2;

        // Analógico esquerdo → movimento
        g_state.analogX = pad.sThumbLX / 32767.0f;
        g_state.analogY = pad.sThumbLY / 32767.0f;
    }

    void Update()
    {
#ifdef _XBOX
        if (XInputGetState(0, &g_xinput) == ERROR_SUCCESS)
        {
            MapXboxToWii(g_xinput.Gamepad);
        }
        else
        {
            g_state.buttons = 0;
            g_state.analogX = 0.0f;
            g_state.analogY = 0.0f;
        }
#endif
    }

    const WiiInputState& GetState()
    {
        return g_state;
    }
}