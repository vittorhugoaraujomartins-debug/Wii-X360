#pragma once

int UID_GetCurrent();
void UID_SetCurrent(int uid);