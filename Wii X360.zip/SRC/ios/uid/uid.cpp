static int g_UID = 1000;

int UID_GetCurrent()
{
    return g_UID;
}

void UID_SetCurrent(int uid)
{
    g_UID = uid;
}