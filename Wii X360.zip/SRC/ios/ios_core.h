#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace IOS {

// Comandos IPC principais do Wii
enum Command : uint32_t {
    IOS_OPEN  = 0x01,
    IOS_CLOSE = 0x02,
    IOS_READ  = 0x03,
    IOS_WRITE = 0x04,
    IOS_IOCTL = 0x06
};

// Vida útil
void Init();
void Shutdown();
void Update();

// Entrada principal PPC → IOS
int HandleIPC(uint32_t command, void* buffer);

// API interna (devices)
int Open(const char* device);
int Close(int fd);

int Ioctl(int fd, uint32_t cmd,
          void* in,  uint32_t inSize,
          void* out, uint32_t outSize);

int Read(int fd, void* buffer, uint32_t size);
int Write(int fd, const void* buffer, uint32_t size);

}