#pragma once
#include <cstdint>

struct IPCMessage {
    uint32_t command;
    uint32_t fd;

    void*    inBuffer;
    uint32_t inSize;

    void*    outBuffer;
    uint32_t outSize;
};

namespace IPC {

    void Init();

    // Envia mensagem PPC → IOS
    int Send(const IPCMessage& msg);

    // Atualização IOS (background)
    void Update();
}


#include <cstdint>

struct IPCRequest {
    uint32_t command;
    uint32_t result;
    void* buffer;
};

namespace IPC {
    void Init();
    int Handle(IPCRequest* req);
}