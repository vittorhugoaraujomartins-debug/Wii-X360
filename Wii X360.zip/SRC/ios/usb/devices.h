#pragma once
#include "ipc_core.h"

int Device_Open(int device, void* path);
int Device_Close(int handle);

int Device_Read(int handle, void* out);
int Device_Write(int handle, void* in);

int Device_Ioctl(int handle, int cmd, void* in, void* out);
int Device_Ioctlv(int handle, int cmd, IPCVector* vec, int count);