#include "devices.h"
#include "handles_ex.h"
#include "es_core.h"
#include "fs_core.h"
#include "di_core.h"

int Device_Open(int device, void* path)
{
    return HandleEx_Open(device);
}

int Device_Close(int handle)
{
    HandleEx_Close(handle);
    return 0;
}

int Device_Read(int handle, void* out)
{
    IOSHandleEx* h = HandleEx_Get(handle);
    if (!h) return -1;

    switch (h->device)
    {
    case DEV_FS: return FS_Read(handle, out);
    case DEV_DI: return DI_Read(handle, out);
    }

    return -1;
}

int Device_Write(int handle, void* in)
{
    IOSHandleEx* h = HandleEx_Get(handle);
    if (!h) return -1;

    switch (h->device)
    {
    case DEV_FS: return FS_Write(handle, in);
    }

    return -1;
}

int Device_Ioctl(int handle, int cmd, void* in, void* out)
{
    IOSHandleEx* h = HandleEx_Get(handle);
    if (!h) return -1;

    switch (h->device)
    {
    case DEV_ES: return g_ES.Ioctl(cmd, in, out);
    case DEV_FS: return FS_Ioctl(cmd, in, out);
    case DEV_DI: return DI_Ioctl(cmd, in, out);
    }

    return -1;
}

int Device_Ioctlv(int handle, int cmd, IPCVector* vec, int count)
{
    IOSHandleEx* h = HandleEx_Get(handle);
    if (!h) return -1;

    switch (h->device)
    {
    case DEV_ES: return g_ES.Ioctlv(cmd, vec, count);
    case DEV_FS: return FS_Ioctlv(cmd, vec, count);
    case DEV_DI: return DI_Ioctlv(cmd, vec, count);
    }

    return -1;
}