#include "ios.h"

static bool usbEnabled;

void USB_Init(bool enabled)
{
    usbEnabled = enabled;
}

int USB_Ioctl(int cmd, void* in, void* out)
{
    if (!usbEnabled) return -1;

    switch(cmd)
    {
        case 0x30: // Get device count
            *(int*)out = 1;
            return 0;
    }

    return -1;
}