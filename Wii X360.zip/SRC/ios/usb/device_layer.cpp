int IOS_Ioctl(int device, int cmd, void* in, void* out)
{
    switch(device)
    {
        case DEV_ES:
            return ES_Ioctl(cmd, in, out);

        case DEV_FS:
            return FS_Ioctl(cmd, in, out);

        case DEV_DI:
            return DI_Ioctl(cmd, in, out);

        case DEV_INPUT:
            return INPUT_Ioctl(cmd, in, out);

        case DEV_NET:
            return NET_Ioctl(cmd, in, out);
    }

    return -1;
}