#include "ios.h"

static bool netEnabled;

void NET_Init(bool enabled)
{
    netEnabled = enabled;
}

int NET_Ioctl(int cmd, void* in, void* out)
{
    if (!netEnabled) return -1;

    switch(cmd)
    {
        case 0x40: // Get status
            *(int*)out = 1;
            return 0;
    }

    return -1;
}