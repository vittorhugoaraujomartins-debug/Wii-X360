#pragma once
#include <cstdint>

namespace ES {

    void Init();
    void Shutdown();

    bool Handles(const char* dev);

    int  Open(const char* dev);
    int  Close(int fd);

    bool Owns(int fd);

    int  Ioctl(int fd,
               uint32_t cmd,
               void* in, uint32_t inSize,
               void* out, uint32_t outSize);
}