static WiiInput g_Input;

void Input_Update()
{
    // Mapear controle do Xbox 360 para Wii
    g_Input.buttons = X360_GetButtons();

    g_Input.accelX = 0.0f;
    g_Input.accelY = 0.0f;
    g_Input.accelZ = 1.0f;
}

WiiInput Input_GetState()
{
    return g_Input;
}

WiiInput Input_GetState()
{
    WiiInput in;

    in.buttons = X360_GetButtons();
    in.accelX = 0.0f;
    in.accelY = 0.0f;
    in.accelZ = 1.0f;

    return in;
}