#pragma once

struct WiiInput
{
    int buttons;
    float accelX;
    float accelY;
    float accelZ;
};

void Input_Update();
WiiInput Input_GetState();