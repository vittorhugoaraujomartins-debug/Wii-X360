// IOSFastScheduler.cpp

#include <queue>

struct IOSEvent
{
    uint32_t type;
    uint32_t param;
};

static std::queue<IOSEvent> eventQueue;

void IOS_PushEvent(uint32_t t, uint32_t p)
{
    eventQueue.push({t, p});
}

void IOS_ProcessEvents()
{
    int limit = 16; // evita travar CPU

    while (!eventQueue.empty() && limit--)
    {
        auto e = eventQueue.front();
        eventQueue.pop();

        // HandleEvent(e);
    }
}