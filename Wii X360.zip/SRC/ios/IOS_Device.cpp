#include "IOS_Device.h"
#include "IOS_DVD.h"

std::unordered_map<std::string, IOSDevice*> IOSDevice::deviceRegistry;

void IOSDevice::RegisterDevices() {
    // Evita registrar duas vezes
    if (!deviceRegistry.empty())
        return;

    // Wii real usa /dev/*
    deviceRegistry["/dev/dvd"] = new IOS_DVD();

    // Futuro:
    // deviceRegistry["/dev/fs"]  = new IOS_FS();
    // deviceRegistry["/dev/es"]  = new IOS_ES();
}

IOSDevice* IOSDevice::OpenDevice(const std::string& path) {
    auto it = deviceRegistry.find(path);
    if (it == deviceRegistry.end())
        return nullptr;

    return it->second;
}

#include "IOS_Device.h"
#include "IOS_DVD.h"
#include "IOS_FS.h"
#include "IOS_ES.h"
#include "IOS_Null.h"

std::unordered_map<std::string, IOSDevice*> IOSDevice::deviceRegistry;

void IOSDevice::RegisterDevices() {
    if (!deviceRegistry.empty())
        return;

    deviceRegistry["/dev/dvd"]  = new IOS_DVD();
    deviceRegistry["/dev/fs"]   = new IOS_FS();
    deviceRegistry["/dev/es"]   = new IOS_ES();
    deviceRegistry["/dev/null"] = new IOS_Null();
}