// ios_input.cpp
#include "ios.h"

namespace IOS {

// Sempre retorna "nenhum input"

}