#include "ios_hle.h"
#include <string.h>

namespace IOS {

bool Init()
{
    return true;
}

int Open(const char* path)
{
    // ES
    if (strcmp(path, "/dev/es") == 0)
        return 1;

    // FS
    if (strcmp(path, "/dev/fs") == 0)
        return 2;

    // DI
    if (strcmp(path, "/dev/di") == 0)
        return 3;

    return -1;
}

int Ioctl(int fd, uint32_t cmd, void* in, void* out)
{
    switch (fd)
    {
        case 1: // ES
            return 0;

        case 2: // FS
            return 0;

        case 3: // DI
            return 0;
    }

    return -1;
}

}