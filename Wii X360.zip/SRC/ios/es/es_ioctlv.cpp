#include "ipc_iov.h"
#include "es_content.h"

int ES_Ioctlv(
    int cmd,
    int inCount,
    int outCount,
    IOSVec* vec)
{
    switch (cmd)
    {
    case 0x20: // OpenContent
    {
        uint32_t contentId =
            *(uint32_t*)vec[0].data;

        int h = ES_OpenContent(contentId);

        *(int*)vec[1].data = h;
        return 0;
    }

    case 0x21: // ReadContent
    {
        int h = *(int*)vec[0].data;

        return ES_ReadContent(
            h,
            vec[1].data,
            vec[1].size);
    }

    case 0x22: // CloseContent
    {
        int h = *(int*)vec[0].data;
        return ES_CloseContent(h);
    }
    }

    return -1;
}


int FS_Ioctlv(
    int cmd,
    int inCount,
    int outCount,
    IOSVec* vec)
{
    switch (cmd)
    {
    case 0x30: // Open file
    {
        const char* path = (char*)vec[0].data;
        int fd = FS_Open(path);

        *(int*)vec[1].data = fd;
        return 0;
    }
    }

    return -1;
}


