#include "es_content.h"
#include "es_core.h"
#include <stdio.h>
#include <map>

struct ContentHandle
{
    FILE* file;
};

static std::map<int, ContentHandle> g_content;
static int g_nextHandle = 1;

int ES_OpenContent(uint32_t contentId)
{
    char path[256];

    uint64_t tid = ES_GetTitleID();

    sprintf(path,
        "nand/title/%08X/%08X/content/%08X.app",
        (uint32_t)(tid >> 32),
        (uint32_t)(tid & 0xFFFFFFFF),
        contentId);

    FILE* f = fopen(path, "rb");
    if (!f)
        return -1;

    int h = g_nextHandle++;
    g_content[h] = { f };

    return h;
}

int ES_ReadContent(int handle, void* buffer, uint32_t size)
{
    auto it = g_content.find(handle);
    if (it == g_content.end())
        return -1;

    return fread(buffer, 1, size, it->second.file);
}

int ES_CloseContent(int handle)
{
    auto it = g_content.find(handle);
    if (it == g_content.end())
        return -1;

    fclose(it->second.file);
    g_content.erase(it);

    return 0;
}