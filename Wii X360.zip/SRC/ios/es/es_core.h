#pragma once
#include <stdint.h>

typedef uint64_t TitleID;

struct ESTitleContext {
    TitleID title;
    uint32_t uid;
    uint32_t gid;
};

class ESCore {
public:
    void Init();

    int Ioctl(int cmd, void* in, void* out);

    TitleID GetCurrentTitle() const { return current.title; }

private:
    ESTitleContext current;

    int Identify(void* in, void* out);
    int LaunchTitle(void* in);
    int GetTicketViews(void* in, void* out);
    int GetNumTicketViews(void* in, void* out);
    int GetTMD(void* in, void* out);
    int GetDeviceID(void* out);
};

extern ESCore g_ES;