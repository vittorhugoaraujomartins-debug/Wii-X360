#include "handles.h"

static IOSHandle g_Handles[MAX_HANDLES];

int Handle_Open(int device)
{
    for (int i = 0; i < MAX_HANDLES; i++)
    {
        if (!g_Handles[i].used)
        {
            g_Handles[i].used = true;
            g_Handles[i].device = device;
            return i;
        }
    }
    return -1;
}

void Handle_Close(int h)
{
    if (h >= 0 && h < MAX_HANDLES)
        g_Handles[h].used = false;
}

int Handle_GetDevice(int h)
{
    if (h >= 0 && h < MAX_HANDLES && g_Handles[h].used)
        return g_Handles[h].device;

    return -1;
}




static IOSHandleEx g_Handles[MAX_HANDLES];

int HandleEx_Open(int device)
{
    for (int i = 0; i < MAX_HANDLES; i++)
    {
        if (!g_Handles[i].used)
        {
            g_Handles[i].used = true;
            g_Handles[i].device = device;
            g_Handles[i].offset = 0;
            g_Handles[i].internalData = nullptr;
            return i;
        }
    }
    return -1;
}

void HandleEx_Close(int h)
{
    if (h >= 0 && h < MAX_HANDLES)
        g_Handles[h] = {};
}

IOSHandleEx* HandleEx_Get(int h)
{
    if (h >= 0 && h < MAX_HANDLES && g_Handles[h].used)
        return &g_Handles[h];

    return nullptr;
}