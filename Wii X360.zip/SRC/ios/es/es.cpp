#include "es.h"
#include "PPC.h"
#include "DOLLoader.h"

ESDevice::ESDevice(PPC* cpu, DOLLoader* loader, ESCore* core)
    : m_cpu(cpu), m_loader(loader), m_core(core)
{
}

bool ESDevice::LaunchTitle(uint64_t title_id, const std::string& dol_path)
{
    // registrar título
    m_core->SetTitle(title_id);

    // carregar executável
    if (!m_loader->Load(dol_path))
        return false;

    // iniciar CPU
    uint32_t entry = m_loader->GetEntryPoint();

    m_cpu->Reset();
    m_cpu->SetPC(entry);

    return true;
}

uint64_t ESDevice::GetTitleId() const
{
    return m_core->GetTitleId();
}



#include "handles.h"

TitleContext g_TitleContext;

void Title_Set(uint64_t tid)
{
    g_TitleContext.titleID = tid;
    g_TitleContext.uid = 0x1000;
    g_TitleContext.gid = 0x1000;

    Title_ResetResources();
}

void Title_ResetResources()
{
    // Fecha todos os handles
    for (int i = 0; i < MAX_HANDLES; i++)
        HandleEx_Close(i);
}