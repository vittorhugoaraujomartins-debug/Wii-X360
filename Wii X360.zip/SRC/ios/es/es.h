#pragma once
#include <stdint.h>

extern uint64_t g_CurrentTitleID;

void ES_SetTitle(uint64_t titleID);
uint64_t ES_GetTitleID();



class PPC;
class DOLLoader;
class ESCore;

class ESDevice
{
public:

    ESDevice(PPC* cpu, DOLLoader* loader, ESCore* core)
        : m_cpu(cpu), m_loader(loader), m_core(core)
    {}

    bool LaunchTitle(uint64_t title_id, const std::string& dol_path)
    {
        // 1) registrar título ativo
        m_core->SetTitle(title_id);

        // 2) carregar DOL principal
        if (!m_loader->Load(dol_path))
            return false;

        // 3) iniciar CPU no entry point
        uint32_t entry = m_loader->GetEntryPoint();

        m_cpu->Reset();
        m_cpu->SetPC(entry);

        return true;
    }

    uint64_t GetTitleId() const
    {
        return m_core->GetTitleId();
    }

private:
    PPC* m_cpu;
    DOLLoader* m_loader;
    ESCore* m_core;
};





struct TitleContext
{
    uint64_t titleID;
    uint32_t uid;
    uint32_t gid;
};

extern TitleContext g_TitleContext;

void Title_Set(uint64_t tid);
void Title_ResetResources();