#include "es_core.h"
#include <string.h>

ESCore g_ES;

void ESCore::Init() {
    current.title = 0x0000000100000002ULL; // System Menu default
    current.uid = 0;
    current.gid = 0;
}

int ESCore::Ioctl(int cmd, void* in, void* out) {

    switch (cmd) {

    case 0x01: // Identify
        return Identify(in, out);

    case 0x02: // LaunchTitle
        return LaunchTitle(in);

    case 0x03: // GetNumTicketViews
        return GetNumTicketViews(in, out);

    case 0x04: // GetTicketViews
        return GetTicketViews(in, out);

    case 0x05: // GetTMD
        return GetTMD(in, out);

    case 0x06: // GetDeviceID
        return GetDeviceID(out);

    default:
        return 0;
    }
}


int ESCore::Identify(void* in, void* out) {

    // Ignora assinatura por enquanto
    // Apenas aceita e define contexto

    current.uid = 0x1000;
    current.gid = 0x1000;

    return 0;
}



int ESCore::LaunchTitle(void* in) {

    TitleID* tid = (TitleID*)in;

    current.title = *tid;

    // Aqui normalmente:
    // - carrega conteúdo do título
    // - reseta FS context
    // - prepara memória

    return 0;
}


int ESCore::GetNumTicketViews(void* in, void* out) {

    uint32_t* count = (uint32_t*)out;
    *count = 1; // sempre 1 ticket válido

    return 0;
}


struct TicketView {
    uint64_t titleID;
    uint32_t accessMask;
};

int ESCore::GetTicketViews(void* in, void* out) {

    TicketView* tv = (TicketView*)out;

    tv->titleID = current.title;
    tv->accessMask = 0xFFFFFFFF;

    return 0;
}


struct TMDStub {
    uint64_t titleID;
    uint16_t numContents;
};

int ESCore::GetTMD(void* in, void* out) {

    TMDStub* tmd = (TMDStub*)out;

    tmd->titleID = current.title;
    tmd->numContents = 1;

    return 0;
}



int ESCore::GetDeviceID(void* out) {

    uint32_t* id = (uint32_t*)out;
    *id = 0x12345678;

    return 0;
}