#pragma once

#define MAX_HANDLES 64

struct IOSHandle
{
    int device;
    bool used;
};

int Handle_Open(int device);
void Handle_Close(int h);
int Handle_GetDevice(int h);



#define MAX_HANDLES 64

struct IOSHandleEx
{
    bool used;

    int device;

    uint32_t offset;

    void* internalData;   // ponteiro específico do device
};

int HandleEx_Open(int device);
void HandleEx_Close(int h);

IOSHandleEx* HandleEx_Get(int h);