#pragma once
#include <stdint.h>

int ES_OpenContent(uint32_t contentId);
int ES_ReadContent(int handle, void* buffer, uint32_t size);
int ES_CloseContent(int handle);