#pragma once
#include <string>
#include <unordered_map>
#include <cstdint>

class IOSDevice {
public:
    virtual ~IOSDevice() = default;

    // IOCTL principal
    virtual int Ioctl(uint32_t cmd,
                      void* in, uint32_t inSize,
                      void* out, uint32_t outSize) = 0;

    // Registro / abertura
    static void RegisterDevices();
    static IOSDevice* OpenDevice(const std::string& path);

protected:
    static std::unordered_map<std::string, IOSDevice*> deviceRegistry;
};
