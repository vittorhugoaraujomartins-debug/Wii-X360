#pragma once
#include <stdint.h>
#include <queue>

struct IPCMessage {
    int device;
    int cmd;
    void* in;
    void* out;

    int result;

    bool completed;
    bool blocking;
};

class IOSAsync {
public:
    void Init();

    // PPC envia request
    void SendIPC(IPCMessage* msg);

    // Loop do IOS (roda em outro core/thread)
    void Tick();

    // Verifica conclusão (PPC usa)
    bool IsCompleted(IPCMessage* msg);

private:
    std::queue<IPCMessage*> ipcQueue;

    void ProcessMessage(IPCMessage* msg);
};

extern IOSAsync g_IOS;