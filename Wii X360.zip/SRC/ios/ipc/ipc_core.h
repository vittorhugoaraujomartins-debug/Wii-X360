#pragma once
#include <stdint.h>

enum IPCCommand
{
    IPC_OPEN,
    IPC_CLOSE,
    IPC_READ,
    IPC_WRITE,
    IPC_IOCTL,
    IPC_IOCTLV
};

struct IPCVector
{
    void* data;
    uint32_t size;
};

struct IPCMessage
{
    IPCCommand command;

    int device;
    int handle;

    int cmd;        // IOCTL command

    void* in;
    void* out;

    IPCVector* vec;
    int vecCount;

    int result;
    bool completed;
};