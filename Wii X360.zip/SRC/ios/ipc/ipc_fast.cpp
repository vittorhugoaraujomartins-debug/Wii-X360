int IOS_Ioctl_Handle(int handle, int cmd, void* in, void* out)
{
    int device = Handle_GetDevice(handle);
    if (device == -1)
        return -1;

    // Execução direta (HLE agressiva)
    return IOS_Ioctl(device, cmd, in, out);
}