#include "di_device.h"

static DIDevice g_DI;

g_DI.Init("game.iso");


if (strcmp(path, "/dev/di") == 0)
{
    return Handle_Open(DEVICE_DI);
}


int IPC_HandleIoctl(int handle, uint32_t cmd,
                    void* in, void* out)
{
    int dev = Handle_GetDevice(handle);

    switch (dev)
    {
        case DEVICE_DI:
            return g_DI.Ioctl(cmd, in, out);
    }

    return -1;
}

