#pragma once
#include <stdint.h>

struct IOSVec
{
    void* data;
    uint32_t size;
};


int IPC_HandleIoctlv(
    int fd,
    int cmd,
    int inCount,
    int outCount,
    IOSVec* vec)
{
    int device = Handle_GetDevice(fd);

    if (device < 0)
        return -1;

    // Exemplo: encaminhar para ES
    if (device == DEVICE_ES)
        return ES_Ioctlv(cmd, inCount, outCount, vec);

    if (device == DEVICE_FS)
        return FS_Ioctlv(cmd, inCount, outCount, vec);

    if (device == DEVICE_DI)
        return DI_Ioctlv(cmd, inCount, outCount, vec);

    return -1;
}