#pragma once
#include <queue>
#include <cstdint>

struct IPCMessage
{
    int device;
    int cmd;

    void* in;
    void* out;

    int result;

    bool completed;
    int delay;      // ⭐ latência simulada
    int handle;     // ⭐ fd do IOS
};

void IPC_Send(IPCMessage* msg);
void IPC_Process();
bool IPC_IsCompleted(IPCMessage* msg);