#include "ipc_core.h"
#include "handles_ex.h"
#include "devices.h"
#include <queue>

static std::queue<IPCMessage*> g_IPCQueue;

void IPC_Send(IPCMessage* msg)
{
    msg->completed = false;
    g_IPCQueue.push(msg);
}

void IPC_Process()
{
    while (!g_IPCQueue.empty())
    {
        IPCMessage* m = g_IPCQueue.front();
        g_IPCQueue.pop();

        switch (m->command)
        {
        case IPC_OPEN:
            m->result = Device_Open(m->device, m->in);
            break;

        case IPC_CLOSE:
            m->result = Device_Close(m->handle);
            break;

        case IPC_READ:
            m->result = Device_Read(m->handle, m->out);
            break;

        case IPC_WRITE:
            m->result = Device_Write(m->handle, m->in);
            break;

        case IPC_IOCTL:
            m->result = Device_Ioctl(m->handle, m->cmd, m->in, m->out);
            break;

        case IPC_IOCTLV:
            m->result = Device_Ioctlv(m->handle, m->cmd, m->vec, m->vecCount);
            break;
        }

        m->completed = true;
    }
}