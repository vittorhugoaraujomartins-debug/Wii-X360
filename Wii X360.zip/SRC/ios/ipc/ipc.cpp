#include "ipc.h"
#include "devices.h"
#include "irq.h"

static std::queue<IPCMessage*> g_IPCQueue;

void IPC_Send(IPCMessage* msg)
{
    msg->completed = false;

    // ⭐ latência mínima realista
    msg->delay = 3 + (msg->cmd & 3);

    g_IPCQueue.push(msg);
}

bool IPC_IsCompleted(IPCMessage* msg)
{
    return msg->completed;
}

void IPC_Process()
{
    int budget = 8;

    while (budget-- > 0 && !g_IPCQueue.empty())
    {
        IPCMessage* msg = g_IPCQueue.front();

        // ⭐ ainda aguardando latência
        if (msg->delay > 0)
        {
            msg->delay--;
            break;
        }

        g_IPCQueue.pop();

        switch (msg->device)
        {
            case DEV_ES:
                msg->result = ES_Ioctl(msg->cmd, msg->in, msg->out);
                break;

            case DEV_FS:
                msg->result = FS_Ioctl(msg->cmd, msg->in, msg->out);
                break;

            case DEV_DI:
                msg->result = DI_Ioctl(msg->cmd, msg->in, msg->out);
                break;

            case DEV_USB:
                msg->result = USB_Ioctl(msg->cmd, msg->in, msg->out);
                break;

            case DEV_NET:
                msg->result = NET_Ioctl(msg->cmd, msg->in, msg->out);
                break;

            default:
                msg->result = -6; // invalid
                break;
        }

        msg->completed = true;

        // ⭐ IRQ IPC real
        RaiseIRQ(IRQ_IPC);
    }
}