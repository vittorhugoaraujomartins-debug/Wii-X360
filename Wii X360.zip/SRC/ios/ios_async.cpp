#include "ios_async.h"
#include "devices.h"   // ES, FS, DI etc
#include "irq.h"

IOSAsync g_IOS;

void IOSAsync::Init() {
    while (!ipcQueue.empty())
        ipcQueue.pop();
}

void IOSAsync::SendIPC(IPCMessage* msg) {
    msg->completed = false;
    ipcQueue.push(msg);
}

bool IOSAsync::IsCompleted(IPCMessage* msg) {
    return msg->completed;
}

void IOSAsync::Tick() {

    // Processa poucos por tick para simular latência real
    int budget = 4;

    while (budget-- > 0 && !ipcQueue.empty()) {
        IPCMessage* msg = ipcQueue.front();
        ipcQueue.pop();

        ProcessMessage(msg);

        msg->completed = true;

        // ⭐ Dispara IRQ IPC para PPC
        RaiseIRQ(IRQ_IPC);
    }
}

void IOSAsync::ProcessMessage(IPCMessage* msg) {

    switch (msg->device) {

    case DEV_ES:
        msg->result = ES_Ioctl(msg->cmd, msg->in, msg->out);
        break;

    case DEV_FS:
        msg->result = FS_Ioctl(msg->cmd, msg->in, msg->out);
        break;

    case DEV_DI:
        msg->result = DI_Ioctl(msg->cmd, msg->in, msg->out);
        break;

    default:
        msg->result = -1;
        break;
    }
}



case DEV_ES:
    msg->result = g_ES.Ioctl(msg->cmd, msg->in, msg->out);
    break;

case DEV_FS:
    msg->result = g_FS.Ioctl(msg->cmd, msg->in, msg->out);
    break;

case DEV_DI:
    msg->result = g_DI.Ioctl(msg->cmd, msg->in, msg->out);
    break;