#pragma once
#include <functional>
#include <cstdint>

enum class ThreadState
{
    READY,
    RUNNING,
    WAITING,
    SLEEPING,
    DEAD
};

struct IOSThread
{
    uint32_t id;
    int priority;

    ThreadState state = ThreadState::READY;

    std::function<void()> entry;

    uint64_t wakeTime = 0;   // para sleep
    uint32_t waitEvent = 0;  // evento IPC etc
};