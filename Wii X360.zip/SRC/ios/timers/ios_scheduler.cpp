bool g_IOSRunning = true;

void IOS_RunFrame()
{
    // Processa IPC pendente
    ProcessIPCQueue();

    // Atualiza dispositivos
    DI_Update();
    USB_Update();
}


#include "ipc.h"

void IOS_RunFrame()
{
    IPC_Process();

    DI_Update();
    USB_Update();
    NET_Update();
}


#include "ios_scheduler.h"

void IOSScheduler::Init()
{
    threads.clear();
    nextID = 1;
}


uint32_t IOSScheduler::CreateThread(
    std::function<void()> entry,
    int priority)
{
    IOSThread t;

    t.id = nextID++;
    t.priority = priority;
    t.entry = entry;
    t.state = ThreadState::READY;

    threads.push_back(t);

    return t.id;
}


void IOSScheduler::Sleep(uint32_t ms)
{
    if (currentIndex < 0) return;

    threads[currentIndex].state = ThreadState::SLEEPING;
    threads[currentIndex].wakeTime += ms;
}



void IOSScheduler::WaitEvent(uint32_t event)
{
    if (currentIndex < 0) return;

    threads[currentIndex].state = ThreadState::WAITING;
    threads[currentIndex].waitEvent = event;
}



void IOSScheduler::SignalEvent(uint32_t event)
{
    for (auto& t : threads)
    {
        if (t.state == ThreadState::WAITING &&
            t.waitEvent == event)
        {
            t.state = ThreadState::READY;
        }
    }
}



void IOSScheduler::Run(uint64_t time)
{
    for (size_t i = 0; i < threads.size(); i++)
    {
        auto& t = threads[i];

        // acordar sleep
        if (t.state == ThreadState::SLEEPING &&
            time >= t.wakeTime)
        {
            t.state = ThreadState::READY;
        }

        if (t.state != ThreadState::READY)
            continue;

        currentIndex = i;

        t.state = ThreadState::RUNNING;

        t.entry();   // executa thread

        if (t.state == ThreadState::RUNNING)
            t.state = ThreadState::READY;
    }

    currentIndex = -1;
}



