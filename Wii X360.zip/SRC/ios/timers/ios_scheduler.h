#pragma once
#include "ios_thread.h"
#include <vector>

class IOSScheduler
{
public:
    void Init();

    uint32_t CreateThread(std::function<void()> entry,
                          int priority);

    void Sleep(uint32_t ms);
    void WaitEvent(uint32_t event);

    void SignalEvent(uint32_t event);

    void Run(uint64_t currentTime);

private:
    std::vector<IOSThread> threads;

    uint32_t nextID = 1;
    int currentIndex = -1;
};