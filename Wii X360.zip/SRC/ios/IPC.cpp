#include "IPC.h"
#include "IOS.h"

namespace IOSIPC {

void Init() {
    // Nada ainda
}

int Send(const IPCMessage& msg) {
    // Encaminha para IOS
    return IOS::HandleIPC(msg.command, (void*)&msg);
}

void Update() {
    IOS::Update();
}

}

#include "IPC.h"

namespace IPC {

void Init() {
    // Nada ainda, mas evita null calls
}

int SendRequest(int, int, void*) {
    // Retorno de sucesso genérico
    return 0;
}

}


#include "IPC.h"

namespace IPC {

void Init() {}

int Handle(IPCRequest* req) {
    if (!req)
        return -1;

    // Por padrão, sucesso
    req->result = 0;
    return 0;
}

}

irqController.Raise(WiiInterrupt::IPC);