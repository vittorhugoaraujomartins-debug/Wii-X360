#pragma once
#include <string>

bool NAND_Init(const std::string& root);
std::string NAND_Path(const std::string& wii_path);
bool NAND_FileExists(const std::string& wii_path);