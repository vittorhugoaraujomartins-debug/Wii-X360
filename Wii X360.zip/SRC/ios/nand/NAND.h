#pragma once
class NAND{public: static bool Init();};