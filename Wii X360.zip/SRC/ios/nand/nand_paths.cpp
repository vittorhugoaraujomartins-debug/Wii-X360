#include "es.h"
#include <stdio.h>

void NAND_GetSavePath(char* out)
{
    uint64_t tid = ES_GetTitleID();

    sprintf(out,
        "nand/title/%08X/%08X/data/",
        (unsigned int)(tid >> 32),
        (unsigned int)(tid & 0xFFFFFFFF));
}
static unsigned char g_NANDMemory[64 * 1024 * 1024];