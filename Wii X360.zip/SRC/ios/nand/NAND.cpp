#include "NAND.h"
bool NAND::Init(){return true;}

// --- Build/XEX compatibility stub ---

// HLE default success
