
#include "NAND.h"
bool NAND::Init() { return true; }
