#include "nand.h"
#include <filesystem>

static std::string g_root;

bool NAND_Init(const std::string& root)
{
    g_root = root;

    std::filesystem::create_directories(root + "/title");
    std::filesystem::create_directories(root + "/shared1");
    std::filesystem::create_directories(root + "/shared2");
    std::filesystem::create_directories(root + "/sys");
    std::filesystem::create_directories(root + "/tmp");

    return true;
}

std::string NAND_Path(const std::string& wii_path)
{
    return g_root + "/" + wii_path;
}

bool NAND_FileExists(const std::string& wii_path)
{
    return std::filesystem::exists(NAND_Path(wii_path));
}