#pragma once
#include <stdint.h>

namespace IOS {

bool Init();

int Open(const char* path);
int Ioctl(int fd, uint32_t cmd, void* in, void* out);

}