#pragma once
#include "IOS_Device.h"
#include <cstdint>

class IOS_DVD : public IOSDevice {
public:
    IOS_DVD();

    int Ioctl(uint32_t cmd,
              void* in, uint32_t inSize,
              void* out, uint32_t outSize) override;

private:
    uint32_t currentOffset;
};
