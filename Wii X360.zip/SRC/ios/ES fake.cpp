// ios_es.cpp
#include "ios.h"

namespace IOS {

// ES responde OK para tudo
// Verificação de título ignorada

}