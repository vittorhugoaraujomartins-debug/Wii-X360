#include "sd.h"

void SD_Init()
{
    // Monta pasta sd/
}

int SD_Open(const char* path)
{
    return Host_OpenFile(path);
}

int SD_Read(int fd, void* buffer, int size)
{
    return Host_ReadFile(fd, buffer, size);
}