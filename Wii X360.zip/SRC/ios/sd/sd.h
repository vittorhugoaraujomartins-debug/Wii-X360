#pragma once

void SD_Init();
int SD_Open(const char* path);
int SD_Read(int fd, void* buffer, int size);