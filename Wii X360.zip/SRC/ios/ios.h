#pragma once
#include <map>
#include <memory>
#include <array>
#include <string>

class Device;

class IOSKernel
{
public:
    IOSKernel();

    int Open(const std::string& path);
    int Close(int fd);
    int Read(int fd, void* buffer, uint32_t size);
    int Ioctl(int fd, uint32_t cmd, void* in, void* out);

    void RegisterDevice(std::shared_ptr<Device> device);

private:
    std::map<std::string, std::shared_ptr<Device>> m_devices;
    std::array<std::shared_ptr<Device>, 32> m_fd_table;
};