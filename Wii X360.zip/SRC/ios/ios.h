#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once

namespace IOS {

// lifecycle
void Init();
void Shutdown();
void Update();

// IPC entry (CPU → IOS)
int HandleIPC(uint32_t command, void* buffer);

// Devices
int Open(const char* path);
int Close(int fd);
int Read(int fd, void* buffer, uint32_t size);
int Write(int fd, const void* buffer, uint32_t size);

int Ioctl(int fd,
          uint32_t cmd,
          void* in, uint32_t inSize,
          void* out, uint32_t outSize);

}

#pragma once

namespace IOS {

    void Init();
    void Shutdown();
    void Update();

    // chamada direta pelo PPC (sc)
    void HandleIPC(uint32_t msgAddr);
}