#include "ios_device.h"
#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):

std::unordered_map<std::string, IOSDevice*> IOSDevice::registry;

void IOSDevice::RegisterDevices() {
    if (!registry.empty())
        return;

    // Devices mínimos do Wii
    registry["/dev/dvd"] = new IOS_DVD();
    registry["/dev/null"] = NULL; // sempre sucesso
}

IOSDevice* IOSDevice::OpenDevice(const std::string& path) {
    /*auto*/ it = registry.find(path);
    if (it == registry.end())
        return NULL;

    return it->second;
}

// --- Build/XEX compatibility stub ---

// HLE default success
