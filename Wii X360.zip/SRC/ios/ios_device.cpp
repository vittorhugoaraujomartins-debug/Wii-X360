#include "ios_device.h"
#include "dvd_core.h"

std::unordered_map<std::string, IOSDevice*> IOSDevice::registry;

void IOSDevice::RegisterDevices() {
    if (!registry.empty())
        return;

    // Devices mínimos do Wii
    registry["/dev/dvd"] = new IOS_DVD();
    registry["/dev/null"] = nullptr; // sempre sucesso
}

IOSDevice* IOSDevice::OpenDevice(const std::string& path) {
    auto it = registry.find(path);
    if (it == registry.end())
        return nullptr;

    return it->second;
}