#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


#pragma once
// FIXME: include not found in project (left original below):

class IOSDevice {
public:
    virtual ~IOSDevice() = default;

    virtual int Ioctl(uint32_t cmd,
                      void* in,  uint32_t inSize,
                      void* out, uint32_t outSize) = 0;

    // Registry
    static void RegisterDevices();
    static IOSDevice* OpenDevice(const std::string& path);

protected:
    static std::unordered_map<std::string, IOSDevice*> registry;
};