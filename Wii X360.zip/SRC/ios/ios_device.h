#pragma once
#include <unordered_map>
#include <string>
#include <cstdint>

class IOSDevice {
public:
    virtual ~IOSDevice() = default;

    virtual int Ioctl(uint32_t cmd,
                      void* in,  uint32_t inSize,
                      void* out, uint32_t outSize) = 0;

    // Registry
    static void RegisterDevices();
    static IOSDevice* OpenDevice(const std::string& path);

protected:
    static std::unordered_map<std::string, IOSDevice*> registry;
};