#include "ipc.h"
#include <queue>
#include <mutex>

static std::queue<IPCMessage> ipcQueue;
static std::mutex ipcMutex;

namespace IPC {

void Init() {
    while (!ipcQueue.empty())
        ipcQueue.pop();
}

void Send(const IPCMessage& msg) {
    std::lock_guard<std::mutex> lock(ipcMutex);
    ipcQueue.push(msg);
}

bool HasMessage() {
    std::lock_guard<std::mutex> lock(ipcMutex);
    return !ipcQueue.empty();
}

IPCMessage Pop() {
    std::lock_guard<std::mutex> lock(ipcMutex);
    IPCMessage m = ipcQueue.front();
    ipcQueue.pop();
    return m;
}

}