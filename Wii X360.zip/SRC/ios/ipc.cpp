#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>

// FIXME: include not found in project (left original below):
static std::queue<IPCMessage> ipcQueue;
static std::mutex ipcMutex;

namespace IPC {

void Init() {
    while (!ipcQueue.empty())
        ipcQueue.pop();
}

void Send(const IPCMessage& msg) {
    std::lock_guard<std::mutex> lock(ipcMutex);
    ipcQueue.push(msg);
}

bool HasMessage() {
    std::lock_guard<std::mutex> lock(ipcMutex);
    return !ipcQueue.empty();
}

IPCMessage Pop() {
    std::lock_guard<std::mutex> lock(ipcMutex);
    IPCMessage m = ipcQueue.front();
    ipcQueue.pop();
    return m;
}

}

#include "ios_ipc.h"
#include "../cpu/cpu_state.h"
#include "../cpu/cpu_interrupts.h"
#include "../mmu/mmu.h"

namespace IOS {

void Init() {}

int HandleIPC(uint32_t cmdAddr) {

    // Estrutura simplificada
    IPCRequest req{};
    req.command = MMU::Read32(cmdAddr);

    int result = 0;

    switch (req.command) {

    case IPC_OPEN:
        result = 1; // fd fake
        break;

    case IPC_CLOSE:
        result = 0;
        break;

    case IPC_READ:
    case IPC_WRITE:
        result = 0;
        break;

    case IPC_IOCTL:
        result = 0;
        break;

    default:
        result = -1;
        break;
    }

    // Retorno padrão IOS
    gCPU.GPR[3] = result;

    // Gera interrupção IPC
    CPUInterrupts::Raise(INT_SYSTEM_CALL);

    return result;
}

}