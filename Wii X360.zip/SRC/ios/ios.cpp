#include "ios.h"
#include "FS.h"
#include "ES.h"
#include "ios_device.h"
#include "cpu_interrupts.h"

namespace IOS {

void Init() {
    FS::Init();
    ES::Init();
    IOSDevice::RegisterDevices();
}

void Shutdown() {
    FS::Shutdown();
    ES::Shutdown();
}

void Update() {
    // IOS roda em background no Wii real
    // aqui é cooperativo
}

int HandleIPC(uint32_t command, void* buffer) {

    switch (command) {

    case 0x01: // IOS_OPEN
        return Open(reinterpret_cast<const char*>(buffer));

    case 0x02: // IOS_CLOSE
        return Close(reinterpret_cast<intptr_t>(buffer));

    default:
        return 0;
    }
}

int Open(const char* path) {

    if (FS::Handles(path))
        return FS::Open(path);

    if (ES::Handles(path))
        return ES::Open(path);

    IOSDevice* dev = IOSDevice::OpenDevice(path);
    if (dev)
        return reinterpret_cast<int>(dev);

    return -1;
}

int Close(int fd) {
    if (FS::Owns(fd)) return FS::Close(fd);
    if (ES::Owns(fd)) return ES::Close(fd);
    return 0;
}

int Read(int fd, void* buffer, uint32_t size) {
    if (FS::Owns(fd))
        return FS::Read(fd, buffer, size);

    return 0;
}

int Write(int, const void*, uint32_t size) {
    return size;
}

int Ioctl(int fd,
          uint32_t cmd,
          void* in, uint32_t inSize,
          void* out, uint32_t outSize) {

    if (FS::Owns(fd))
        return FS::Ioctl(fd, cmd, in, inSize, out, outSize);

    if (ES::Owns(fd))
        return ES::Ioctl(fd, cmd, in, inSize, out, outSize);

    IOSDevice* dev = reinterpret_cast<IOSDevice*>(fd);
    if (dev)
        return dev->Ioctl(cmd, in, inSize, out, outSize);

    return 0;
}

}