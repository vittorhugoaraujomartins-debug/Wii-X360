#include "ios.h"

IOSState g_IOS;

void IOS_Init(int requestedVersion)
{
    g_IOS.version = requestedVersion;

    // Recursos simulados por versão
    g_IOS.fastDI  = (requestedVersion >= 56);
    g_IOS.usb2    = (requestedVersion >= 58);
    g_IOS.network = (requestedVersion >= 36);

    ES_Init();
    FS_Init();
    DI_Init(g_IOS.fastDI);
}



int IOS_HandleSyscall(int id)
{
    switch(id)
    {
        case IOS_OPEN:
            return FS_Open(...);

        case IOS_READ:
            return FS_Read(...);

        case IOS_IOCTL:
            return HandleIoctl(...);

        default:
            return 0;
    }
}

int IOS_HandleSyscall(int id)
{
    switch(id)
    {
        case IOS_IOCTL:
        {
            IPCMessage* msg = GetCurrentIPC();
            IPC_Send(msg);

            // PPC deve aguardar IRQ
            return IOS_PENDING;
        }

        default:
            return -6;
    }
}




int IOSKernel::Open(const std::string& path)
{
    if (m_devices.count(path) == 0)
        return -1;

    for (int i = 0; i < m_fd_table.size(); i++)
    {
        if (!m_fd_table[i])
        {
            m_fd_table[i] = m_devices[path];
            return i;
        }
    }

    return -1;
}