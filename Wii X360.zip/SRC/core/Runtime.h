#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>


#pragma once
namespace Runtime {
    bool Init();
    void Tick();
}
