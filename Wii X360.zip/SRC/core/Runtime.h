#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>



#pragma once
namespace Runtime {
    bool Init();
    void Tick();
}