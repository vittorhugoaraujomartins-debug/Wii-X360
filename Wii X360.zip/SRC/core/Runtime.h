#pragma once
namespace Runtime {
    bool Init();
    void Tick();
    void Shutdown();
}
