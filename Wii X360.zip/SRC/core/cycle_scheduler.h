#pragma once
#include <cstdint>
#include <queue>
#include <functional>

struct ScheduledEvent
{
    uint64_t targetCycles;
    std::function<void()> callback;

    bool operator<(const ScheduledEvent& other) const
    {
        return targetCycles > other.targetCycles; // min-heap
    }
};

class CycleScheduler
{
public:
    void Schedule(uint64_t cyclesFromNow, std::function<void()> cb);
    void Advance(uint64_t cycles);
    uint64_t GetCurrentCycles() const;

private:
    uint64_t currentCycles = 0;
    std::priority_queue<ScheduledEvent> events;
};