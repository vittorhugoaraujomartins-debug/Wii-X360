#include "vi.h"
#include "wii_interrupts.h"

static uint32_t viCounter = 0;

namespace VI {

void Init() {
    viCounter = 0;
}

void Tick() {
    // chamado 60x por segundo
    viCounter++;
    WiiInterruptController::Raise(WiiInterrupt::VI);
}

}