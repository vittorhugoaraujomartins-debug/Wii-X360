#pragma once
#include <stdint.h>
#include "../cpu/cpu.h"
#include "../jit/jit.h"
#include "../gpu/gpu.h"
#include "../memory/mmu.h"
#include "../audio/audio.h"

class Emulator {
public:
    bool Init();
    void RunFrame();
    bool IsRunning() const;
    void Shutdown();

private:
    CPU cpu;
    JIT jit;
    GPU gpu;
    MMU mmu;
    Audio audio;
    bool running = true;
};
