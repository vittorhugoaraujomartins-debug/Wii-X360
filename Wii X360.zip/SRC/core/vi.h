#pragma once
#include <stdint.h>

namespace VI {
    void Init();
    void Tick();
}