#pragma once

void Emulator_Init();
void Emulator_LoadGame(const char* path);
void Emulator_RunFrame();
void Emulator_Shutdown();