#include "ax_engine.h"

void AXEngine::ProcessFrame()
{
    float buffer[512] = {};
    MixVoices(buffer, 512);

    // Send buffer to XAudio / Xbox 360 backend
}

void AXEngine::AddVoice()
{
    voices.push_back({ true, 1.0f, 0 });
}

void AXEngine::StopVoice(int index)
{
    if (index >= 0 && index < voices.size())
        voices[index].active = false;
}

void AXEngine::MixVoices(float* outputBuffer, int samples)
{
    for (auto& v : voices)
    {
        if (!v.active) continue;

        for (int i = 0; i < samples; i++)
        {
            outputBuffer[i] += 0.1f * v.volume; // placeholder
        }
    }
}