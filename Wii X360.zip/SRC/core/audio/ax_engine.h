#pragma once
#include <vector>

struct Voice
{
    bool active;
    float volume;
    uint32_t samplePos;
};

class AXEngine
{
public:
    void ProcessFrame();
    void AddVoice();
    void StopVoice(int index);

private:
    std::vector<Voice> voices;
    void MixVoices(float* outputBuffer, int samples);
};