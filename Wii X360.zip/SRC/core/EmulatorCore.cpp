#include "CPU/PPC/PPC.h"
#include "IOS/IOS.h"
#include "GPU/GXCore.h"
#include "gpu_hle/GXTranslator.h"

void Emulator_Init()
{
    PPC_Init();
    IOS_Init();
    GXCore_Init();
}

void Emulator_LoadGame(const char* path)
{
    LoadDOL(path);
}

void Emulator_RunFrame()
{
    // Executa CPU até gerar comandos gráficos
    PPC_RunCycles(500000);

    // Processa GPU
    GXCore_Process();

    // Renderiza frame
    GXHLE_EndFrame();
}

void Emulator_Shutdown()
{
}