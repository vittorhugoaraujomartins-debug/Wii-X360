#pragma once

#include <xtl.h>
#include <stdint.h>
#include <vector>
#include <algorithm>

typedef void (*EventCallback)(void* userdata);

struct SchedulerEvent {
    uint64_t cycle;
    EventCallback callback;
    void* userdata;

    bool operator<(const SchedulerEvent& other) const {
        return cycle < other.cycle;
    }
};

class EventScheduler {
public:
    void Init();

    // Avança o relógio global
    void Advance(uint64_t cycles);

    // Agenda evento absoluto
    void Schedule(uint64_t cycle, EventCallback cb, void* userdata);

    // Agenda evento relativo
    void ScheduleAfter(uint64_t cycles, EventCallback cb, void* userdata);

    // Executa eventos prontos
    void Dispatch();

    // Próximo evento
    uint64_t GetNextEventCycle() const;

    uint64_t GetGlobalCycle() const { return global_cycle; }

private:
    uint64_t global_cycle = 0;
    std::vector<SchedulerEvent> events;
};