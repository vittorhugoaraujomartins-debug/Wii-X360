#include "event_scheduler.h"

void EventScheduler::Init() {
    global_cycle = 0;
    events.clear();
}

void EventScheduler::Advance(uint64_t cycles) {
    global_cycle += cycles;
}

void EventScheduler::Schedule(uint64_t cycle, EventCallback cb, void* userdata) {
    SchedulerEvent ev;
    ev.cycle = cycle;
    ev.callback = cb;
    ev.userdata = userdata;

    events.push_back(ev);

    // Mantém ordenado por ciclo
    std::sort(events.begin(), events.end());
}

void EventScheduler::ScheduleAfter(uint64_t cycles, EventCallback cb, void* userdata) {
    Schedule(global_cycle + cycles, cb, userdata);
}

void EventScheduler::Dispatch() {
    while (!events.empty()) {
        SchedulerEvent& ev = events.front();

        if (ev.cycle > global_cycle)
            break;

        if (ev.callback)
            ev.callback(ev.userdata);

        events.erase(events.begin());
    }
}

uint64_t EventScheduler::GetNextEventCycle() const {
    if (events.empty())
        return UINT64_MAX;

    return events.front().cycle;
}