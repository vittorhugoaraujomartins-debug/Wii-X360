#include <xtl.h>

#include "Runtime.h"
static bool g_init = false;

bool Runtime::Init()
{
    g_init = true;
    return true;
}

void Runtime::Tick()
{
    if (!g_init)
        return;
}
