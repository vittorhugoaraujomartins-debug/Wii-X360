#include "emulator.h"

bool Emulator::Init() {
    cpu.Init();
    jit.Init(&cpu);
    mmu.Init();
    gpu.Init();
    audio.Init();
    return true;
}

void Emulator::RunFrame() {
    const int cyclesPerFrame = 486000;
    int cycles = 0;

    while (cycles < cyclesPerFrame) {
        int executed = cpu.Step();
        cycles += executed;

        jit.Sync(cpu.GetPC());
        mmu.Tick(executed);
        cpu.CheckInterrupts();
        gpu.Tick(executed);
        audio.Tick(executed);
    }

    gpu.RenderFrame();
}

bool Emulator::IsRunning() const {
    return running;
}

void Emulator::Shutdown() {
    audio.Shutdown();
    gpu.Shutdown();
}
