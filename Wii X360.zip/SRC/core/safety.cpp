#include <xtl.h>
static inline int ClampCycles(int c){ return (c<=0)?1:c; }
