#include "cpu_state.h"
#include <cstring>

CPUState gCPU;

void CPU_Reset() {
    memset(&gCPU, 0, sizeof(gCPU));

    gCPU.PC = 0x80000000; // entry padrão Wii
}