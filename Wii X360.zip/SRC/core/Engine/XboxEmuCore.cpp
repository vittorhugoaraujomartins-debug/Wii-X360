#include "XboxEmuCore.h"

#include "cpu/PowerPC.h"
#include "cpu/PPCJIT.h"
#include "scheduler/scheduler.h"
#include "scheduler/event_scheduler.h"
#include "gpu/xenos/XenosGPU.h"
#include "gpu/gx/GXState.h"
#include "gpu/gx/GXFIFO.h"
#include "gpu/gx/GXTEV.h"
#include "memory/MemoryManager.h"

static WiiCPU::PowerPC g_cpu;
static PPCJIT          g_jit;
static PPCScheduler    g_scheduler;
static EventScheduler  g_events;

static GX::GXState     g_gxState;
static GXFIFO          g_fifo;

bool XboxEmuCore::Init() {

    WiiX360::MemoryManager::Init();

    g_cpu.Reset();
    g_jit.Init(&g_cpu);

    g_events.Init();
    g_scheduler.Init(&g_cpu, &g_jit, &g_events);

    GXTEV::Init();
    XenosGPU::Init();

    return true;
}

void XboxEmuCore::Shutdown() {
    XenosGPU::Shutdown();
}

void XboxEmuCore::LoadROM(const char* path) {
    WiiX360::MemoryManager::LoadROM(path);
}

void XboxEmuCore::RunFrame() {

    // 1️⃣ CPU + eventos
    g_scheduler.StepFrame(frameCycles);

    // 2️⃣ Processa FIFO GX
    StepGPU();

    // 3️⃣ Sincroniza vídeo
    SyncVideo();
}

void XboxEmuCore::StepCPU() {
    g_scheduler.StepFrame(frameCycles);
}

void XboxEmuCore::StepGPU() {

    while (!g_fifo.Empty()) {
        uint32_t cmd = g_fifo.Pop();
        GX::ExecuteCommand(cmd, g_gxState);
    }

    XenosGPU::ApplyGXState(g_gxState);
}

void XboxEmuCore::SyncVideo() {
    // VBlank fake por enquanto
}