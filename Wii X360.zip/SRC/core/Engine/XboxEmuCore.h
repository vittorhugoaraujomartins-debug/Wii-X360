#pragma once
#include <stdint.h>

class XboxEmuCore {
public:
    bool Init();
    void Shutdown();

    void LoadROM(const char* path);
    void RunFrame();

private:
    void StepCPU();
    void StepGPU();
    void SyncVideo();

    uint64_t frameCycles = 486000; // ~60Hz
};