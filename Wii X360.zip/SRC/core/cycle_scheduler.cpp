#include "cycle_scheduler.h"

void CycleScheduler::Schedule(uint64_t cyclesFromNow, std::function<void()> cb)
{
    events.push({ currentCycles + cyclesFromNow, cb });
}

void CycleScheduler::Advance(uint64_t cycles)
{
    currentCycles += cycles;

    while (!events.empty() && events.top().targetCycles <= currentCycles)
    {
        auto ev = events.top();
        events.pop();
        ev.callback();
    }
}

uint64_t CycleScheduler::GetCurrentCycles() const
{
    return currentCycles;
}