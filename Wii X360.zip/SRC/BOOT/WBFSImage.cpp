#include "WBFSImage.h"

struct WBFSHeader
{
    char magic[4];   // "WBFS"
    uint32_t hdSectorSize;
    uint8_t  padding[0x18];
};

bool WBFSImage::Open(const char* path)
{
    file = fopen(path, "rb");
    if (!file) return false;

    WBFSHeader hdr;
    fread(&hdr, sizeof(hdr), 1, file);

    if (strncmp(hdr.magic, "WBFS", 4) != 0)
        return false;

    sectorSize = 1 << hdr.hdSectorSize;

    // Primeiro jogo começa após header
    partitionOffset = sectorSize;

    return true;
}

int WBFSImage::Read(uint64_t offset, void* buffer, uint32_t size)
{
    if (!file) return -1;

    fseek(file, partitionOffset + offset, SEEK_SET);
    return fread(buffer, 1, size, file);
}

// HLE — offsets típicos dentro da partição
uint32_t WBFSImage::GetApploaderOffset()
{
    return 0x2440;
}

uint32_t WBFSImage::GetDolOffset()
{
    uint32_t dolOffset;

    fseek(file, partitionOffset + 0x420, SEEK_SET);
    fread(&dolOffset, 4, 1, file);

    return dolOffset;
}