#pragma once

bool WiiBoot_Init();
void WiiBoot_RunFrame();