#include "wii_boot.h"
#include "mmu_memory.h"
#include "ios_hle.h"
#include "vi.h"
#include "gx_fifo.h"

bool WiiBoot_Init()
{
    if (!WiiMem::Init()) return false;
    if (!IOS::Init()) return false;
    if (!VI::Init()) return false;

    return true;
}

void WiiBoot_RunFrame()
{
    // CPU executaria aqui

    GXFIFO::Process();
    VI::Update();
}