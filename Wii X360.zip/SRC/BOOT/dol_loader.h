#pragma once
#include <stdint.h>

bool LoadDOL(const char* path, uint32_t& entryPoint);