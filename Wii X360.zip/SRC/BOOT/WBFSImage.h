#pragma once
#include <stdint.h>
#include <stdio.h>

class WBFSImage
{
public:
    bool Open(const char* path);

    int Read(uint64_t offset, void* buffer, uint32_t size);

    uint32_t GetDolOffset();
    uint32_t GetApploaderOffset();

private:
    FILE* file = nullptr;

    uint32_t sectorSize = 0x8000;
    uint32_t partitionOffset = 0;
};