#include "Boot.h"
#include "IOS.h"
#include "ES.h"
#include "Apploader.h"

WiiBoot g_Boot;

bool WiiBoot::Boot()
{
    if (!Boot1()) return false;
    if (!Boot2()) return false;

    return true;
}


bool WiiBoot::Boot1()
{
    // Verificação criptográfica ignorada
    // Apenas simula sucesso

    return true;
}


bool WiiBoot::Boot2()
{
    if (!LoadIOS())
        return false;

    // Após IOS pronto, carregar jogo
    return g_Apploader.Load();
}


bool WiiBoot::LoadIOS()
{
    // IOS padrão usado por jogos
    IOS_Init(58);   // USB2 + moderno

    return true;
}



