#include "Apploader.h"
#include "DIDevice.h"
#include "PPC.h"

Apploader g_Apploader;

extern PPC g_CPU;

bool Apploader::Load()
{
    uint32_t dolOffset = g_DI.GetDolOffset();

    if (!dolOffset)
        return false;

    return LoadDol(dolOffset);
}



struct DOLHeader
{
    uint32_t textOffset[7];
    uint32_t dataOffset[11];

    uint32_t textAddr[7];
    uint32_t dataAddr[11];

    uint32_t textSize[7];
    uint32_t dataSize[11];

    uint32_t bssAddr;
    uint32_t bssSize;

    uint32_t entryPoint;
};


bool Apploader::LoadDol(uint32_t dolOffset)
{
    DOLHeader dol;

    if (g_DI.Read(&dol, sizeof(dol), dolOffset) <= 0)
        return false;

    // TEXT
    for (int i = 0; i < 7; i++)
    {
        if (dol.textSize[i] == 0) continue;

        g_DI.Read(
            (void*)dol.textAddr[i],
            dol.textSize[i],
            dolOffset + dol.textOffset[i]
        );
    }

    // DATA
    for (int i = 0; i < 11; i++)
    {
        if (dol.dataSize[i] == 0) continue;

        g_DI.Read(
            (void*)dol.dataAddr[i],
            dol.dataSize[i],
            dolOffset + dol.dataOffset[i]
        );
    }

    // BSS
    memset((void*)dol.bssAddr, 0, dol.bssSize);

    // ENTRY
    g_CPU.SetPC(dol.entryPoint);

    return true;
}



#include "apploader.h"
#include "di.h"
#include "mmu.h"

namespace Apploader {

static uint32_t entryPoint = 0;

bool LoadFromDisc()
{
    // Apploader fica em offset fixo
    const uint32_t APPLOADER_OFFSET = 0x2440;

    uint8_t buffer[0x20];

    // Ler header
    DI::Ioctl(0x71,
               APPLOADER_OFFSET,
               sizeof(buffer),
               (uint32_t)buffer,
               sizeof(buffer));

    entryPoint = *(uint32_t*)(buffer + 0x10);

    // Simulação: carregar DOL direto
    // (versão mínima funcional)

    return true;
}

uint32_t GetEntryPoint()
{
    return entryPoint;
}

}