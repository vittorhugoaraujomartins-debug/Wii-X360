#pragma once
#include <stdint.h>

class WiiBoot
{
public:
    bool Boot();

private:
    bool Boot1();
    bool Boot2();
    bool LoadIOS();
};

extern WiiBoot g_Boot;