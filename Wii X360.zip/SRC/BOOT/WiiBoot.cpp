#include "WiiBoot.h"

#include <xtl.h>
#include <stdio.h>
#include <string.h>

#include "../IOS/IOS.h"
#include "../MEMORY/Memory.h"
#include "../CPU/CPU.h"

namespace WiiBoot {

static const char* kMainDol = "\\sys\\main.dol";

bool DetectGame(const char* path) {
    char dolPath[256];
    sprintf(dolPath, "%s%s", path, kMainDol);

    HANDLE h = CreateFileA(
        dolPath,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (h == INVALID_HANDLE_VALUE)
        return false;

    CloseHandle(h);
    return true;
}

bool BootGame(const char* path) {

    if (!DetectGame(path))
        return false;

    // Inicialização mínima do sistema Wii
    Memory_Init();
    IOS_Init();
    CPU_Reset();

    char dolPath[256];
    sprintf(dolPath, "%s%s", path, kMainDol);

    HANDLE h = CreateFileA(
        dolPath,
        GENERIC_READ,
        FILE_SHARE_READ,
        NULL,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        NULL
    );

    if (h == INVALID_HANDLE_VALUE)
        return false;

    DWORD size = GetFileSize(h, NULL);
    void* dolBuffer = XPhysicalAlloc(
        size,
        MAXULONG_PTR,
        0,
        PAGE_READWRITE
    );

    DWORD read;
    ReadFile(h, dolBuffer, size, &read, NULL);
    CloseHandle(h);

    // Carrega DOL na memória do emulador
    uint32_t entry = CPU_LoadDOL((uint8_t*)dolBuffer, size);

    XPhysicalFree(dolBuffer);

    if (!entry)
        return false;

    // Salta para o entrypoint do jogo
    CPU_SetPC(entry);
    CPU_Run();

    return true;
}

}