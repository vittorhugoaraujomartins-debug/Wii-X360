#pragma once
#include <stdint.h>

namespace WiiBoot {

bool DetectGame(const char* path);
bool BootGame(const char* path);

}