#pragma once
#include <stdint.h>

class Apploader
{
public:
    bool Load();

private:
    bool LoadDol(uint32_t dolOffset);
};

extern Apploader g_Apploader;



namespace Apploader {

bool LoadFromDisc();
uint32_t GetEntryPoint();

}