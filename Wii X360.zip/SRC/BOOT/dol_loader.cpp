#include "dol_loader.h"
#include "mmu_translate.h"
#include <stdio.h>
#include <string.h>

// ================================
// Estrutura do header DOL
// ================================

struct DOLHeader
{
    uint32_t textOffset[7];
    uint32_t dataOffset[11];

    uint32_t textAddr[7];
    uint32_t dataAddr[11];

    uint32_t textSize[7];
    uint32_t dataSize[11];

    uint32_t bssAddr;
    uint32_t bssSize;

    uint32_t entryPoint;
};

// ================================
// Função auxiliar: copiar para RAM
// ================================

static void CopyToMemory(uint32_t address, const void* src, uint32_t size)
{
    const uint8_t* s = (const uint8_t*)src;

    for (uint32_t i = 0; i < size; i++)
        MMU::Write8(address + i, s[i]);
}

// ================================
// Loader principal
// ================================

bool LoadDOL(const char* path, uint32_t& entryPoint)
{
    FILE* f = fopen(path, "rb");
    if (!f)
        return false;

    DOLHeader hdr;
    fread(&hdr, sizeof(hdr), 1, f);

    // ============================
    // TEXT sections (código)
    // ============================

    for (int i = 0; i < 7; i++)
    {
        if (hdr.textSize[i] == 0)
            continue;

        uint8_t* buffer = new uint8_t[hdr.textSize[i]];

        fseek(f, hdr.textOffset[i], SEEK_SET);
        fread(buffer, 1, hdr.textSize[i], f);

        CopyToMemory(hdr.textAddr[i], buffer, hdr.textSize[i]);

        delete[] buffer;
    }

    // ============================
    // DATA sections
    // ============================

    for (int i = 0; i < 11; i++)
    {
        if (hdr.dataSize[i] == 0)
            continue;

        uint8_t* buffer = new uint8_t[hdr.dataSize[i]];

        fseek(f, hdr.dataOffset[i], SEEK_SET);
        fread(buffer, 1, hdr.dataSize[i], f);

        CopyToMemory(hdr.dataAddr[i], buffer, hdr.dataSize[i]);

        delete[] buffer;
    }

    // ============================
    // BSS (zerar memória)
    // ============================

    for (uint32_t i = 0; i < hdr.bssSize; i++)
        MMU::Write8(hdr.bssAddr + i, 0);

    entryPoint = hdr.entryPoint;

    fclose(f);
    return true;
}