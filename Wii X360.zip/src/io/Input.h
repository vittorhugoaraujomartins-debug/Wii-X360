
#pragma once

class Input {
public:
    void Poll();
};
