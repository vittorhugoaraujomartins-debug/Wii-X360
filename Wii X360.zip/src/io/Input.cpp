
#include "io/Input.h"

void Input::Poll() {
}
