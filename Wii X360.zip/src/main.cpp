
#include "core/Emulator.h"

int main() {
    Emulator emu;
    if (!emu.Init())
        return -1;

    while (emu.IsRunning()) {
        emu.Step();
    }

    emu.Shutdown();
    return 0;

{
  