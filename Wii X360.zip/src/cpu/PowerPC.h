
#pragma once

class PowerPC {
public:
    void Reset();
    void Step();
};
