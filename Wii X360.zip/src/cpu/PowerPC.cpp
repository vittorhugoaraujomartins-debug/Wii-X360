
#include "cpu/PowerPC.h"

void PowerPC::Reset() {
}

void PowerPC::Step() {
}
