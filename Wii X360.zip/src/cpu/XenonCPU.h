
#pragma once

class XenonCPU {
public:
    void Init();
    void Execute();
};
