
#include "XenonCPU.h"

void XenonCPU::Init() {
    // Use native Xbox 360 threads
}

void XenonCPU::Execute() {
    // Execute translated Wii logic directly
}
