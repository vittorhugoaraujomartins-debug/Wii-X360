
#pragma once
#include <atomic>

namespace Threading {
    // Fixed threads:
    //  T0: Game/Logic (HLE)
    //  T1: Render (Xenos)
    //  T2: Audio/IO
    // Free:
    //  T3: Async worker (FS, decompression, shader prep)
    void Init();
    void Start(std::atomic<bool>& running);
    void TickMain();
    void Shutdown();
}
