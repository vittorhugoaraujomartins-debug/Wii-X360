
#include "gpu/GX.h"

void GX::Init() {
}

void GX::Render() {
}
