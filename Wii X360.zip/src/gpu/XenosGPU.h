
#pragma once

class XenosGPU {
public:
    void Init();
    void Draw();
};
