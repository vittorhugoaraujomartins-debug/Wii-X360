
#pragma once

class GX {
public:
    void Init();
    void Render();
};
