
#pragma once

class DSP {
public:
    void Init();
    void Process();
};
