#include <xtl.h>
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <assert.h>

// xtl.h - lightweight compatibility wrapper
#pragma once

// Standard types
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdlib>
#include <cstdio>

// Useful macros
#ifndef UNUSED
#define UNUSED(x) (void)(x)
#endif

// Placeholder for Xbox-specific XTL declarations if needed.
