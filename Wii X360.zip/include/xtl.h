#include <xtl.h>
#include <stdint.h>
#include <string.h>
#include <math.h>


// xtl.h - lightweight compatibility wrapper
#pragma once

// Standard types

// Useful macros
#ifndef UNUSED
#define UNUSED(x) (void)(x)
#endif

// Placeholder for Xbox-specific XTL declarations if needed.